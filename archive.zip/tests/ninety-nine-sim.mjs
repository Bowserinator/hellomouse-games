import assert from 'node:assert/strict';
import { Engine } from '../build/client/ninety_nine/js/engine.js';
import { decide } from '../build/client/ninety_nine/js/ai.js';
import { VARIANTS } from '../build/client/ninety_nine/js/variants/index.js';
const games = Number(process.env.GAMES ?? 2000);
for (const variant of VARIANTS) {
    let totalMoves = 0;
    let maxMoves = 0;
    let maxDecisionMs = 0;
    const start = performance.now();
    for (let seed = 1; seed <= games; seed++) {
        let value = seed;
        const rng = () => ((value = (Math.imul(value, 1664525) + 1013904223) >>> 0) / 4294967296);
        const seats = 2 + seed % 7;
        const tokens = 1 + seed % 10;
        const engine = new Engine({ variant, seats, tokens, rng });
        let moves = 0;
        while (engine.phase !== 'gameEnd' && moves < 50000) {
            const actor = engine.pending?.seat ?? engine.turn;
            const view = engine.view(actor, Infinity);
            const tick = performance.now();
            const move = decide(view, rng);
            maxDecisionMs = Math.max(maxDecisionMs, performance.now() - tick);
            const error = engine.dispatch(actor, move);
            assert.equal(error, null, `${variant.id} seed=${seed} move=${moves} ${JSON.stringify(move)}`);
            assert.ok(engine.total >= 0 && engine.total <= 99);
            moves++;
        }
        assert.equal(engine.phase, 'gameEnd', `${variant.id} seed=${seed} did not terminate`);
        assert.equal(engine.tokens.filter(n => n > 0).length, 1);
        assert.ok(engine.winner !== null && engine.tokens[engine.winner] > 0);
        const cards = [...engine.deck, ...engine.discard, ...engine.hands.flat()];
        assert.equal(cards.length, seats > 6 ? 104 : 52);
        assert.equal(new Set(cards.map(card => card.iid)).size, cards.length);
        totalMoves += moves; maxMoves = Math.max(maxMoves, moves);
    }
    console.log(`${variant.id}: ${games} games, ${totalMoves} moves, max ${maxMoves}/game, max decision ${maxDecisionMs.toFixed(1)}ms, ${(performance.now() - start).toFixed(0)}ms`);
}
