import { test } from 'node:test';
import assert from 'node:assert/strict';
import Client from '../../server/client.js';
import Connect6InfinityGame, { MAX_STONES } from '../../server/games/connect6_infinity.js';

function room(stoneCount: number) {
    const messages: Array<{ type: string; code?: string }> = [];
    const a = new Client({ sendUTF: (text: string) => messages.push(JSON.parse(text)) });
    const b = new Client({ sendUTF: () => {} });
    const game = new Connect6InfinityGame();
    game.onJoin(a);
    game.onJoin(b);
    game.round = 1;
    for (let key = 0; key < stoneCount; key++)
        game.stones.set(key, 1);
    messages.length = 0;
    return { game, a, b, messages };
}

test('Infinity config limits concurrent rooms to ten', () => {
    assert.equal(new Connect6InfinityGame().config.maxLobbies, 10);
    assert.equal(MAX_STONES, 81_920);
});

test('A turn that exactly fills the stone budget succeeds; further turns are rejected', () => {
    const { game, a, b, messages } = room(MAX_STONES - 2);
    game.onMove(a, { moves: [[0, 0], [0, 1]] });
    assert.equal(game.stones.size, MAX_STONES);
    assert.equal(game.round, 2);
    assert.equal(game.turn, 1);
    assert.equal(messages[0].type, 'STONES');
    messages.length = 0;

    for (let attempt = 0; attempt < 10; attempt++)
        game.onMove(b, { moves: [[10, 0], [10, 1]] });
    assert.equal(game.stones.size, MAX_STONES);
    assert.equal(game.stoneAt(10, 0), 0);
    assert.equal(game.round, 2);
    assert.equal(game.turn, 1);
    assert.deepEqual(game.lastMoves, [[0, 0], [0, 1]]);
    assert.equal(messages.length, 0);
    assert.ok(Buffer.byteLength(JSON.stringify(game.boardMessage())) < 20 * 1024 * 1024);
});

test('An oversized two-stone turn is rejected atomically, without clock bonuses', () => {
    const { game, a, messages } = room(MAX_STONES - 1);
    game.mode = 'blitz';
    const clocks = game.clocks.slice();
    game.onMove(a, { moves: [[0, 0], [0, 1]] });
    assert.equal(game.stones.size, MAX_STONES - 1);
    assert.equal(game.stoneAt(0, 0), 0);
    assert.equal(game.stoneAt(0, 1), 0);
    assert.equal(game.round, 1);
    assert.equal(game.turn, 0);
    assert.deepEqual(game.lastMoves, []);
    assert.deepEqual(game.clocks, clocks);
    assert.deepEqual(messages.map(m => [m.type, m.code]), [['ERROR', 'STATE_LIMIT']]);
});

test('The opening stone fits the final slot and a reset frees the entire budget', () => {
    const { game, a, messages } = room(MAX_STONES - 1);
    game.round = 0;
    game.onMove(a, { moves: [[0, 0]] });
    assert.equal(game.stones.size, MAX_STONES);
    assert.equal(game.round, 1);
    assert.equal(messages[0].type, 'STONES');

    game.onRoomCreate();
    assert.equal(game.stones.size, 0);
    game.onMove(a, { moves: [[0, 0]] });
    assert.equal(game.stones.size, 1);
    assert.equal(game.round, 1);
});
