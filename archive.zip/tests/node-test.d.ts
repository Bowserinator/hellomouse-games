// Minimal types for node:test. @types/node here predates the module.
declare module 'node:test' {
    interface TestContext {
        mock: { timers: {
            enable(options: { apis: Array<'setTimeout' | 'Date'>; now?: number }): void;
            tick(milliseconds: number): void;
        } };
    }
    export function test(name: string, fn: (context: TestContext) => void | Promise<void>): void;
}
