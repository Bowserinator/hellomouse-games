import { test } from 'node:test';
import assert from 'node:assert/strict';
import Client from '../../server/client.js';
import FuckYouGame from '../../server/games/fuck_you.js';
import type { Sync } from '../../server/games/fuck_you.js';

function client(username: string): Client & { messages: Array<Sync & { error?: string }> } {
    const messages: Array<Sync & { error?: string }> = [];
    const c = new Client({ sendUTF: (text: string) => messages.push(JSON.parse(text)) });
    c.username = username;
    return Object.assign(c, { messages });
}
function room(): { game: FuckYouGame; a: ReturnType<typeof client>; b: ReturnType<typeof client> } {
    const game = new FuckYouGame(); game.uuid = 'test-room';
    const a = client('A'), b = client('B');
    assert.ok(game.onJoin(a)); assert.ok(game.onJoin(b));
    return { game, a, b };
}

test('Lobby requires two ready players and only the host can start', () => {
    const { game, a, b } = room();
    assert.equal(game.config.allowChat, false);
    game.onMove(a, { action: 'START_GAME' }); assert.equal(game.engine, null);
    a.ready = b.ready = true;
    game.onMove(b, { action: 'START_GAME' }); assert.equal(game.engine, null);
    game.onMove(a, { action: 'START_GAME' }); assert.ok(game.engine);
    const first = game.globalStateSync(a), second = game.globalStateSync(b);
    assert.notEqual(first.token, second.token);
    assert.ok(first.view?.players[0].hand.every(c => c.defId));
    assert.ok(first.view?.players[1].hand.every(c => c.defId === null));
    assert.ok(second.view?.players[1].hand.every(c => c.defId));
});

test('Disconnect keeps seats stable; only the private token can resume a disconnected seat', () => {
    const { game, a, b } = room(); a.ready = b.ready = true;
    game.onMove(a, { action: 'START_GAME' });
    const token = game.globalStateSync(a).token;
    const ids = game.engine?.hands[0].map(c => c.iid);
    game.onDisconnect(a);
    assert.equal(game.players[0], null); assert.equal(game.players[1], b);
    const newcomer = client('New'); assert.ok(game.onJoin(newcomer));
    assert.equal(game.globalStateSync(newcomer).youAre, -1);
    assert.ok(game.globalStateSync(newcomer).view?.players.every(p => p.hand.every(c => c.defId === null)));
    game.onMove(newcomer, { action: 'RESUME', token: 'forged' }); assert.equal(game.players[0], null);
    game.onMove(newcomer, { action: 'DRAW' }); assert.equal(game.players[0], null);
    game.onMove(newcomer, { action: 'RESUME', token });
    assert.equal(game.players[0], newcomer); assert.equal(newcomer.username, 'A');
    assert.deepEqual(game.engine?.hands[0].map(c => c.iid), ids);
    assert.equal(game.playerCount, 2);
    const thief = client('Thief'); game.onJoin(thief);
    game.onMove(thief, { action: 'RESUME', token }); assert.equal(game.players[0], newcomer);
});

test('Observers receive later movement events, with private draw identities redacted', () => {
    const { game, a, b } = room(); a.ready = b.ready = true;
    game.onMove(a, { action: 'START_GAME' });
    const observer = client('Watcher'); game.onJoin(observer);
    game.onMove(a, { action: 'DRAW' });
    const message = observer.messages.filter(m => m.type === 'SYNC').at(-1);
    assert.ok(message?.view?.events.length);
    assert.equal(message?.view?.events[0].card.defId, null);
    assert.equal(game.globalStateSync(observer).view?.events.length, 0);
});

test('Lobby compacts disconnected seats and caps player count at eight', () => {
    const { game, a, b } = room(); game.onDisconnect(a);
    assert.equal(game.players[0], b); assert.equal(game.globalStateSync(b).isHost, true);
    for (let i = 0; i < 7; i++) assert.ok(game.onJoin(client(`P${i}`)));
    assert.equal(game.onJoin(client('Overflow')), false);
    game.onRemove(); assert.equal(game.engine, null);
});
