import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Engine } from '../../client/fuck_you/js/engine.js';
import type { Card, Move } from '../../client/fuck_you/js/engine.js';
import { CARDS, CARD_BY_ID, COLORS } from '../../client/fuck_you/js/cards.js';

let serial = 0;
const card = (defId: string): Card => ({ iid: `test-${++serial}`, defId });
function rig(hands: Array<Array<string>>, deck = ['blue-1', 'green-2', 'yellow-3', 'blue-4', 'green-5', 'yellow-6', 'blue-7', 'green-8']): Engine {
    const e = new Engine(hands.length, () => .1);
    e.hands = hands.map(hand => hand.map(card));
    e.deck = deck.map(card);
    e.discard = [card('red-5')]; e.color = 'red'; e.events = []; e.log = [];
    return e;
}
function play(e: Engine, seat = e.turn, index = 0, extra: Move = {}): void {
    assert.equal(e.dispatch(seat, { action: 'PLAY', iid: e.hands[seat][index].iid, color: 'red', ...extra }), null);
}
function answer(e: Engine, selection: Array<string>, seat = e.prompt?.player ?? e.turn, extra: Move = {}): void {
    assert.ok(e.prompt);
    assert.equal(e.dispatch(seat, { action: 'RESPOND', promptId: e.prompt.id, selection, ...extra }), null);
}

test('Catalog has every front and exactly 126 physical cards', () => {
    assert.equal(CARDS.length, 74);
    assert.equal(new Set(CARDS.map(c => c.id)).size, 74);
    assert.equal(CARDS.reduce((sum, c) => sum + c.copies, 0), 126);
    for (const c of CARDS) assert.ok(c.source.page >= 3 && c.source.page <= 16 && c.source.cell >= 0 && c.source.cell < 9);
    for (const count of [2, 3, 8]) {
        const e = new Engine(count);
        assert.ok(e.hands.every(h => h.length === 7));
        assert.equal(e.deck.length + e.discard.length + count * 7, 126);
        assert.equal(CARD_BY_ID[e.view(0).top.defId].effect.op, 'number');
    }
    assert.throws(() => new Engine(1)); assert.throws(() => new Engine(9));
});

test('Match color, number, or action symbol, but not draw two against a wild draw four', () => {
    const e = rig([['green-5', 'blue-2', 'red-1'], ['blue-3']]);
    assert.ok(e.legal(0, e.hands[0][0]));
    assert.equal(e.legal(0, e.hands[0][1]), false);
    assert.ok(e.legal(0, e.hands[0][2]));
    e.discard = [card('blue-skip')];
    e.hands[0].push(card('green-skip')); assert.ok(e.legal(0, e.hands[0][3]));
    e.discard = [card('draw-four')];
    e.hands[0].push(card('blue-draw')); assert.equal(e.legal(0, e.hands[0][4]), false);
});

test('Untrusted plays cannot change state or play other players cards', () => {
    const e = rig([['red-1', 'blue-2'], ['red-3']]);
    const before = JSON.stringify(e.view(0));
    for (const [seat, move] of [
        [1, { action: 'PLAY', iid: e.hands[1][0].iid }],
        [0, { action: 'PLAY', iid: e.hands[1][0].iid }],
        [0, { action: 'PLAY', iid: e.hands[0][1].iid }],
        [0, { action: 'PASS' }], [0, { action: 'NONSENSE' }], [-1, { action: 'DRAW' }]
    ] as Array<[number, Move]>) assert.ok(e.dispatch(seat, move));
    assert.equal(JSON.stringify(e.view(0)), before);
});

test('Draw one: only the drawn card can be played; passing is optional', () => {
    const e = rig([['red-1', 'red-2'], ['blue-2']], ['red-8']);
    assert.equal(e.dispatch(0, { action: 'DRAW' }), null);
    assert.equal(e.turn, 0); assert.equal(e.drawn, e.hands[0][2].iid);
    assert.deepEqual(e.view(0).playable, [e.drawn]);
    assert.ok(e.dispatch(0, { action: 'DRAW' }));
    assert.ok(e.dispatch(0, { action: 'PLAY', iid: e.hands[0][0].iid }));
    assert.equal(e.dispatch(0, { action: 'PASS' }), null); assert.equal(e.turn, 1);
    const unplayable = rig([['red-1'], ['blue-2']], ['blue-8']);
    assert.equal(unplayable.dispatch(0, { action: 'DRAW' }), null); assert.equal(unplayable.turn, 1);
});

test('Skip, reverse, draw two and draw four resolve turn order and penalties', () => {
    for (const id of ['red-skip', 'red-draw', 'draw-four']) {
        const e = rig([[id, 'blue-1'], ['red-2'], ['green-2']]);
        play(e); assert.equal(e.turn, 2);
        assert.equal(e.hands[1].length, id === 'red-skip' ? 1 : id === 'red-draw' ? 3 : 5);
    }
    const two = rig([['red-reverse', 'blue-1'], ['red-2']]); play(two); assert.equal(two.turn, 0);
    const three = rig([['red-reverse', 'blue-1'], ['red-2'], ['green-2']]); play(three);
    assert.equal(three.direction, -1); assert.equal(three.turn, 2);
    const illegal = rig([['draw-four', 'red-1'], ['blue-2']]);
    assert.ok(illegal.dispatch(0, { action: 'PLAY', iid: illegal.hands[0][0].iid, color: 'green' }));
});

test('Wild requires a real color and last draw cards apply penalties before winning', () => {
    const e = rig([['wild', 'red-1'], ['blue-2']]);
    assert.ok(e.dispatch(0, { action: 'PLAY', iid: e.hands[0][0].iid, color: 'purple' }));
    play(e, 0, 0, { color: 'green' }); assert.equal(e.color, 'green');
    const last = rig([['draw-four'], ['red-2']]); play(last);
    assert.equal(last.hands[1].length, 5); assert.equal(last.winner, 0);
});

test('Eye reveals only the next player until their turn ends', () => {
    const e = rig([['eye-of-sauron', 'red-1'], ['red-2', 'blue-3'], ['green-1']]);
    play(e);
    assert.ok(e.view(2).players[1].hand.every(c => c.defId));
    assert.ok(e.view(2).players[0].hand.every(c => c.defId === null));
    play(e, 1);
    assert.ok(e.view(2).players[1].hand.every(c => c.defId === null));
});

test('Hand Swap validates the target and awards the empty hand after swapping', () => {
    const e = rig([['hand-swap', 'red-1', 'blue-2'], ['green-3'], ['yellow-4']]);
    const other = e.hands[1][0].iid;
    play(e);
    assert.ok(e.dispatch(2, { action: 'RESPOND', promptId: e.prompt?.id, selection: ['1'] }));
    assert.ok(e.dispatch(0, { action: 'RESPOND', promptId: e.prompt?.id, selection: ['0'] }));
    answer(e, ['1']);
    assert.equal(e.hands[0][0].iid, other); assert.equal(e.hands[1].length, 2);
    const last = rig([['hand-swap'], ['red-1', 'red-2']]); play(last); answer(last, ['1']);
    assert.equal(last.winner, 1);
});

test('RPS choices stay secret until both submit; first to two wins and loser draws six', () => {
    const e = rig([['rock-paper-scissors', 'red-1'], ['blue-2'], ['green-3']]);
    play(e);
    assert.ok(e.view(0).prompt); assert.ok(e.view(2).prompt); assert.equal(e.view(1).prompt, null);
    answer(e, ['rock'], 0);
    assert.equal(e.view(0).prompt, null);
    assert.ok(e.view(2).prompt); assert.ok(!JSON.stringify(e.view(2)).includes('chose rock'));
    assert.ok(e.dispatch(0, { action: 'RESPOND', promptId: e.prompt?.id, selection: ['paper'] }));
    answer(e, ['scissors'], 2);
    answer(e, ['rock'], 0); answer(e, ['scissors'], 2);
    assert.equal(e.prompt, null); assert.equal(e.hands[2].length, 7); assert.equal(e.turn, 1);
});

test('Lightning plays two cards in order and resolves both effects before choosing final color', () => {
    const e = rig([['lightning-bolt', 'blue-draw', 'green-skip', 'yellow-1'], ['red-2'], ['red-3'], ['red-4']]);
    play(e);
    answer(e, [e.hands[0][0].iid]); assert.equal(e.hands[1].length, 3);
    answer(e, [e.hands[0][0].iid]);
    assert.deepEqual(e.prompt?.options, ['blue', 'green']);
    answer(e, ['green']); assert.equal(e.color, 'green'); assert.equal(e.turn, 3);
    assert.equal(e.hands[0].length, 1);
});

test('Lightning may finish with one remaining card; nested wild effects still resolve', () => {
    const e = rig([['lightning-bolt', 'wild'], ['red-2']]); play(e);
    answer(e, [e.hands[0][0].iid]); answer(e, ['blue']); answer(e, ['green']);
    assert.equal(e.winner, 0);
    const nested = rig([['lightning-bolt', 'hand-swap', 'blue-1', 'yellow-2'], ['red-2', 'red-3']]);
    play(nested); answer(nested, [nested.hands[0][0].iid]); answer(nested, ['green']); answer(nested, ['1']);
    assert.equal(nested.prompt?.kind, 'play');
});

test('Gift requires five cards after playing, unique selections, and leaves two', () => {
    const e = rig([['unexpected-gift', 'red-1', 'red-2', 'red-3', 'red-4', 'red-6'], ['blue-2']]);
    play(e); answer(e, ['1']);
    const id = e.hands[0][0].iid;
    assert.ok(e.dispatch(0, { action: 'RESPOND', promptId: e.prompt?.id, selection: [id, id, id] }));
    answer(e, e.hands[0].slice(0, 3).map(c => c.iid));
    assert.equal(e.hands[0].length, 2); assert.equal(e.hands[1].length, 4);
    const short = rig([['unexpected-gift', 'red-1', 'red-2', 'red-3', 'red-4'], ['blue-1']]);
    assert.equal(short.legal(0, short.hands[0][0], true), false);
});

test('God Hand returns the hand, shuffles, and draws exactly two', () => {
    const e = rig([['god-hand', 'red-1', 'red-2', 'red-3'], ['blue-2']]);
    const total = e.deck.length + e.hands.flat().length + e.discard.length;
    play(e); assert.equal(e.hands[0].length, 2);
    assert.equal(e.deck.length + e.hands.flat().length + e.discard.length, total);
    assert.equal(e.events.filter(v => v.to === 'deck').length, 3);
});

test('Force Update asks the next player for a special card and resolves its effect', () => {
    const e = rig([['force-update', 'red-1'], ['green-skip', 'yellow-2'], ['red-3']]);
    play(e); assert.equal(e.prompt?.player, 1);
    assert.deepEqual(e.prompt?.options, [e.hands[1][0].iid]);
    answer(e, [e.hands[1][0].iid]); assert.equal(e.turn, 0);
    const search = rig([['force-update', 'red-1'], ['green-1'], ['red-2']], ['yellow-3', 'blue-draw', 'blue-2']);
    play(search); assert.equal(search.hands[1].length, 3);
    answer(search, [search.hands[1][2].iid]); assert.equal(search.hands[2].length, 3);
    const absent = rig([['force-update', 'red-1'], ['green-1'], ['red-2']], ['blue-2']);
    play(absent); assert.equal(absent.prompt, null); assert.equal(absent.turn, 2);
    assert.equal(absent.deck.length, 0);
});

test('Burglar steals one per opponent; Philanthropist gives one per opponent and leaves two', () => {
    const e = rig([['burglar', 'red-1'], ['blue-1', 'green-2'], ['yellow-1', 'green-3']]);
    play(e); assert.deepEqual(e.hands.map(h => h.length), [3, 1, 1]);
    const p = rig([['philanthropist', 'red-1', 'red-2', 'red-3', 'red-4'], ['blue-1'], ['yellow-1']]);
    play(p); assert.deepEqual(p.hands.map(h => h.length), [2, 2, 2]);
    const short = rig([['philanthropist', 'red-1', 'red-2', 'red-3'], ['blue-1'], ['yellow-1']]);
    assert.equal(short.legal(0, short.hands[0][0], true), false);
});

test('Bottle excludes actor; chain follows and wraps turn order', () => {
    const bottle = rig([['spin-the-bottle', 'red-1'], ['blue-1'], ['green-1']]); play(bottle);
    assert.deepEqual(bottle.hands.map(h => h.length), [1, 7, 1]);
    const chain = rig([['chain-reaction', 'red-1'], ['blue-1'], ['green-1']]); play(chain);
    assert.deepEqual(chain.hands.map(h => h.length), [2, 5, 3]);
    assert.equal(chain.turn, 1);
});

test('Sacrifice draws one per player, except when it is the last card', () => {
    const e = rig([['sacrifice', 'red-1'], ['blue-1'], ['green-1']]); play(e);
    assert.deepEqual(e.hands.map(h => h.length), [4, 2, 2]);
    const last = rig([['sacrifice'], ['blue-1']]); play(last);
    assert.equal(last.winner, 0); assert.equal(last.hands[1].length, 1);
});

test('Allergy returns only its color; any Bomb draws through blue, including self', () => {
    const e = rig([['red-allergy', 'red-1', 'red-2', 'blue-1'], ['green-1']]); play(e);
    assert.deepEqual(e.hands[0].map(c => c.defId), ['blue-1']);
    for (const color of COLORS) {
        const bomb = rig([[`${color}-bomb`, 'red-1'], ['yellow-2', 'green-3', 'blue-4']], ['red-9', 'blue-7', 'green-1']);
        bomb.color = color; play(bomb);
        assert.deepEqual(bomb.hands[0].map(c => c.defId), ['red-1', 'green-1', 'blue-7']);
        assert.equal(bomb.winner, null);
    }
    const missing = rig([['red-bomb'], ['green-1', 'blue-2']], ['yellow-1']); play(missing);
    assert.equal(missing.prompt, null); assert.equal(missing.hands[0].length, 2);
});

test('Refill preserves top discard and missing searches terminate', () => {
    const e = rig([['blue-1'], ['yellow-1']], []);
    const top = e.discard[0];
    e.discard.unshift(card('green-2'), card('blue-3'));
    assert.equal(e.dispatch(0, { action: 'DRAW' }), null);
    assert.deepEqual(e.discard, [top]); assert.equal(e.deck.length, 1);
    const empty = rig([['blue-1'], ['yellow-1']], []);
    assert.equal(empty.dispatch(0, { action: 'DRAW' }), null); assert.equal(empty.turn, 1);
});

test('UNO can be called, caught, pre-announced, and expires on the next action', () => {
    const e = rig([['red-1', 'blue-1'], ['red-2', 'green-2']]); play(e);
    assert.equal(e.vulnerable, 0);
    assert.equal(e.dispatch(1, { action: 'CATCH' }), null); assert.equal(e.hands[0].length, 3);
    assert.equal(e.vulnerable, null);
    const announced = rig([['red-1', 'blue-1'], ['red-2']]); play(announced, 0, 0, { uno: true });
    assert.equal(announced.vulnerable, null);
    const called = rig([['red-1', 'blue-1'], ['red-2']]); play(called);
    assert.equal(called.dispatch(0, { action: 'UNO' }), null); assert.equal(called.vulnerable, null);
    const expired = rig([['red-1', 'blue-1'], ['red-2', 'green-2']]); play(expired); play(expired);
    assert.notEqual(expired.vulnerable, 0);
});

test('Private views hide opponents cards, prompts, and draw event identities from spectators', () => {
    const e = rig([['red-1', 'blue-1'], ['red-2', 'green-2']]);
    assert.ok(e.view(-1).players.every(p => p.hand.every(c => c.defId === null)));
    e.dispatch(0, { action: 'DRAW' });
    const hidden = e.view(1).events.find(v => v.to === 0);
    assert.equal(hidden?.card.defId, null); assert.equal(hidden?.card.iid, 'hidden');
    assert.ok(e.view(0).events.find(v => v.to === 0)?.card.defId);
    assert.equal(e.view(-1).playable.length, 0);
});

test('Seeded complete games preserve all 126 unique cards, keep private views, and reach a winner', () => {
    for (let seed = 1; seed <= 35; seed++) {
        let value = seed;
        const rng = (): number => {
            value = (Math.imul(value, 1664525) + 1013904223) >>> 0;
            return value / 0x100000000;
        };
        const e = new Engine(2 + seed % 7, rng);
        let steps = 0;
        while (e.winner === null && steps++ < 12000) {
            const prompt = e.hands.map((_, seat) => e.view(seat).prompt).find(p => p);
            if (prompt) {
                const seats = e.hands.map((_, seat) => seat).filter(seat => e.view(seat).prompt);
                for (const seat of seats) {
                    const p = e.view(seat).prompt;
                    if (!p) continue;
                    const options = [...p.options];
                    for (let i = options.length - 1; i > 0; i--) {
                        const j = Math.floor(rng() * (i + 1)); [options[i], options[j]] = [options[j], options[i]];
                    }
                    answer(e, options.slice(0, p.count), seat, { uno: true });
                }
            } else {
                const view = e.view(e.turn);
                if (view.playable.length) assert.equal(e.dispatch(e.turn, {
                    action: 'PLAY', iid: view.playable[Math.floor(rng() * view.playable.length)], color: COLORS[Math.floor(rng() * 4)], uno: true
                }), null);
                else assert.equal(e.dispatch(e.turn, { action: view.drawn ? 'PASS' : 'DRAW' }), null);
            }
            const all = [...e.deck, ...e.discard, ...e.hands.flat()];
            assert.equal(all.length, 126, `Seed ${seed}, step ${steps}`);
            assert.equal(new Set(all.map(c => c.iid)).size, 126);
            assert.ok(e.hands.every(h => h.length > 0) || e.winner !== null || e.prompt !== null);
        }
        assert.notEqual(e.winner, null, `Seed ${seed} did not finish after ${steps} actions`);
        assert.ok(e.dispatch(e.turn, { action: 'DRAW' }));
    }
});
