import assert from 'node:assert/strict';
import { test } from 'node:test';
import Game, { AUTO_PASS_MS } from '../build/server/games/high_society.js';
import Client from '../build/server/client.js';
import { Engine, canBid, isForcedPass } from '../build/client/high_society/js/engine.js';
import { decide } from '../build/client/high_society/js/ai.js';
import { layout, contentSize } from '../build/client/high_society/js/ui/polygon.js';

const money = (...values) => values.map(value => ({ id: value, value }));
function room(t) {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 10000 });
    const g = new Game();
    const clients = Array.from({ length: 3 }, () => {
        const c = new Client({ sendUTF() {} }); c.ready = true; return c;
    });
    clients.forEach(c => g.onJoin(c));
    g.onMove(clients[0], { action: 'SET_OPTIONS', seats: 3 });
    g.onMove(clients[0], { action: 'START_GAME' });
    g.clearTimer(); g.animationUntil = 0;
    const e = g.engine;
    e.phase = 'auction'; e.turn = 0; e.highest = 3; e.passed.fill(false);
    e.hands[0] = money(1); e.table[0] = [];
    t.after(() => { g.onRemove(); t.mock.timers.reset(); });
    return { g, e, clients };
}
test('Forced pass uses hand plus committed bid and excludes non-auction turns', () => {
    const e = new Engine({ seats: 3 });
    e.phase = 'auction'; e.turn = 0; e.highest = 10;
    e.hands[0] = money(2, 3); e.table[0] = money(6);
    assert.equal(canBid(e, 0), true);
    e.highest = 11;
    assert.equal(canBid(e, 0), false);
    assert.equal(e.view(0).legal.forcedPass, true);
    assert.equal(e.view(-1).legal.forcedPass, false);
    e.table[0] = money(25); e.hands[0] = [];
    assert.equal(canBid(e, 0), false);
    assert.equal(isForcedPass(e, 0), true);
    assert.equal(isForcedPass(e, 1), false);
    for (const phase of ['fauxPas', 'gameEnd']) {
        e.phase = phase; assert.equal(isForcedPass(e, 0), false);
    }
    e.phase = 'disgrace'; assert.equal(isForcedPass(e, 0), true);
    e.passed[0] = true; assert.equal(isForcedPass(e, 0), false);
});
test('Human countdown waits for animation, emits auto only on actual auto-pass', t => {
    const { g, e, clients } = room(t);
    assert.equal(AUTO_PASS_MS, 3000);
    g.animationUntil = Date.now() + 700; g.onUsernameChange();
    assert.equal(g.globalStateSync(clients[1]).view.autoPass.remainingMs, 3700);
    t.mock.timers.tick(3699); assert.equal(e.turn, 0);
    t.mock.timers.tick(1); assert.equal(e.turn, 1);
    assert.equal(e.events.findLast(event => event.type === 'pass').auto, true);
    assert.equal(g.autoPassTimer, null);
});
test('Manual pass cancels timer; invalid moves do not reset it', t => {
    const { g, e, clients } = room(t); g.onUsernameChange();
    const deadline = g.autoPass.deadline;
    g.onMove(clients[0], { action: 'BID', cards: [1] });
    assert.equal(g.autoPass.deadline, deadline);
    g.onMove(clients[0], { action: 'PASS' });
    const seq = e.events.length;
    assert.equal(e.events.findLast(event => event.type === 'pass').auto, undefined);
    t.mock.timers.tick(4000); assert.equal(e.events.length, seq);
});
test('Held forced seat keeps deadline through disconnect and resume', t => {
    const { g, e, clients } = room(t); g.onUsernameChange();
    const token = g.globalStateSync(clients[0]).token;
    t.mock.timers.tick(1000); g.onDisconnect(clients[0]);
    const returning = new Client({ sendUTF() {} });
    g.onJoin(returning); g.onMove(returning, { action: 'RESUME', token });
    assert.equal(g.globalStateSync(returning).view.autoPass.remainingMs, 2000);
    g.onDisconnect(returning); g.onDisconnect(clients[1]); g.onDisconnect(clients[2]);
    t.mock.timers.tick(2000);
    assert.equal(e.turn, 1);
    assert.equal(e.events.findLast(event => event.type === 'pass').auto, true);
});
test('Sequential forced humans get separate full countdowns', t => {
    const { g, e } = room(t); e.hands[1] = money(1); g.onUsernameChange();
    t.mock.timers.tick(3000); assert.equal(e.turn, 1);
    assert.equal(g.autoPass.deadline - Date.now(), 3450);
    t.mock.timers.tick(3449); assert.equal(e.turn, 1);
    t.mock.timers.tick(1);
    assert.equal(e.events.filter(event => event.type === 'pass' && event.auto).length, 2);
});
test('CPU, Faux Pas and game end never arm human auto-pass', t => {
    const { g, e } = room(t);
    for (const phase of ['fauxPas', 'gameEnd']) {
        e.phase = phase; g.onUsernameChange(); assert.equal(g.autoPassTimer, null);
    }
    e.phase = 'auction'; g.replaced.add(0); g.onUsernameChange();
    assert.equal(g.autoPassTimer, null); assert.notEqual(g.timer, null);
});
test('Stale callbacks cannot act on a new turn or removed engine', t => {
    const { g, e } = room(t); g.onUsernameChange();
    const seq = e.events.length;
    e.turn = 1; t.mock.timers.tick(3000);
    assert.equal(e.events.length, seq);
    e.turn = 0; g.onUsernameChange(); g.onRemove();
    t.mock.timers.tick(10000); assert.equal(e.events.length, seq);
});
test('Polygon positions and label flips cover every local and spectator seat', () => {
    for (const count of [3, 4, 5]) for (let local = 0; local < count; local++) {
        const table = layout(count, { w: 300, h: 220 }, local);
        assert.ok(table.radius >= 352);
        assert.equal(table.seats[local].rotationDeg, 0);
        for (let i = 0; i < count; i++) {
            const angle = table.seats[i].rotationDeg;
            assert.equal(angle, 360 * (i - local) / count);
            assert.ok(Math.abs(Math.hypot(table.seats[i].anchor.x, table.seats[i].anchor.y) - table.radius) < 1e-8);
        }
        assert.equal(contentSize(table, { w: 300, h: 220 }).w, 1364);
    }
    for (const [count, expected] of [[4, [false, false, true, false]], [5, [false, false, true, true, false]]])
        assert.deepEqual(layout(count, { w: 300, h: 220 }, 0).seats.map(s => {
            const angle = (s.rotationDeg % 360 + 360) % 360;
            return angle > 90 && angle < 270;
        }), expected);
});
test('Forced-pass fuzz games end without an invalid automatic move', () => {
    let seed = 121;
    const rng = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
    let forced = 0;
    for (let game = 0; game < 150; game++) {
        const e = new Engine({ seats: 3 + game % 3, rng });
        e.hands = e.hands.map((hand, i) => hand.filter(c => game % 3 && c.value <= 1 + (i + game) % 3));
        e.spent = e.hands.map(hand => 80 - hand.reduce((sum, c) => sum + c.value, 0));
        let moves = 0;
        while (e.phase !== 'gameEnd' && moves++ < 1000) {
            const auto = isForcedPass(e, e.turn);
            const move = auto ? { action: 'PASS' } : decide(e.view(e.turn, Infinity));
            assert.equal(e.dispatch(e.turn, move, auto), null);
            forced += +auto;
        }
        assert.equal(e.phase, 'gameEnd');
    }
    assert.ok(forced > 0);
});
test('Forced disgrace pass takes the card and is marked automatic', t => {
    const { g, e } = room(t);
    e.phase = 'disgrace'; e.current = { id: 'passe', kind: 'passe', label: 'Passé', value: -5, end: false };
    g.onUsernameChange(); t.mock.timers.tick(3000);
    assert.ok(e.status[0].some(c => c.id === 'passe'));
    assert.equal(e.events.findLast(event => event.type === 'pass').auto, true);
});
