import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Engine } from '../build/client/high_society/js/engine.js';
import { createDeck } from '../build/client/high_society/js/rules.js';
import { score, results } from '../build/client/high_society/js/scoring.js';
import { decide } from '../build/client/high_society/js/ai.js';

const card = id => createDeck().find(c => c.id === id);
function fixture(kind = 'luxury-10') {
    const e = new Engine({ seats: 3, rng: () => .5 });
    e.current = card(kind);
    e.phase = ['luxury', 'prestige'].includes(e.current.kind) ? 'auction' : 'disgrace';
    e.turn = 0; e.starter = 0; e.endCardsRevealed = 0;
    e.deck = [card('luxury-01')];
    return e;
}
test('Deck, denominations, deterministic shuffle and privacy', () => {
    assert.equal(createDeck().length, 16);
    assert.equal(createDeck().filter(c => c.end).length, 4);
    const e = new Engine({ rng: () => .5 });
    assert.deepEqual(e.deck, new Engine({ rng: () => .5 }).deck);
    assert.equal(e.hands[0].length, 11);
    assert.equal(e.hands[0].reduce((s,c) => s+c.value,0), 80);
    assert.deepEqual(e.view(-1).myHand, []);
    assert.equal('hands' in e.view(-1), false);
    assert.equal('hand' in e.view(0).players[1], false);
    assert.equal(e.view(-1).result, undefined);
});
test('Bid validation, cumulative totals and pass returns', () => {
    const e = fixture();
    for (const cards of [[], [1,1], [999], ['1'], [null]]) assert.ok(e.dispatch(0,{action:'BID',cards}));
    assert.equal(e.dispatch(0,{action:'BID',cards:[1,2]}), null);
    assert.ok(e.dispatch(1,{action:'BID',cards:[3]}));
    assert.equal(e.dispatch(1,{action:'BID',cards:[4]}), null);
    assert.equal(e.dispatch(2,{action:'PASS'}), null);
    assert.equal(e.dispatch(0,{action:'BID',cards:[3]}), null);
    assert.equal(e.highest, 6);
    assert.equal(e.dispatch(1,{action:'PASS'}), null);
    assert.equal(e.status[0][0].id, 'luxury-10');
    assert.equal(e.spent[0], 6);
    assert.equal(e.hands[1].length, 11);
    assert.equal(e.turn, 0);
});
test('Normal auction can be free; disgrace ends at first pass', () => {
    let e = fixture();
    e.dispatch(0,{action:'PASS'}); e.dispatch(1,{action:'PASS'});
    assert.equal(e.status[2][0].id,'luxury-10'); assert.equal(e.spent[2],0);
    e = fixture('passe');
    e.dispatch(0,{action:'BID',cards:[5]}); e.dispatch(1,{action:'BID',cards:[6]});
    e.dispatch(2,{action:'BID',cards:[7]}); e.dispatch(0,{action:'PASS'});
    assert.equal(e.status[0][0].id,'passe');
    assert.equal(e.hands[0].length,11); assert.deepEqual(e.spent,[0,6,7]);
    assert.equal(e.turn,0);
});
test('Faux Pas resolves no, one and multiple luxuries, including delayed receipt', () => {
    let e = fixture('faux-pas'); e.dispatch(0,{action:'PASS'});
    assert.equal(e.pendingFauxPas[0],true);
    e.current = card('luxury-10'); e.phase='auction'; e.turn=1;
    e.dispatch(1,{action:'PASS'}); e.dispatch(2,{action:'PASS'});
    assert.equal(e.status[0].length,0); assert.equal(e.pendingFauxPas[0],false);
    e=fixture('faux-pas'); e.status[0]=[card('luxury-03')]; e.dispatch(0,{action:'PASS'});
    assert.equal(e.status[0].length,0); assert.equal(e.pendingFauxPas[0],false);
    e=fixture('faux-pas'); e.status[0]=[card('luxury-03'),card('luxury-10')];
    e.dispatch(0,{action:'PASS'}); assert.equal(e.phase,'fauxPas');
    assert.ok(e.dispatch(0,{action:'CHOOSE_DISCARD',id:'passe'}));
    assert.equal(e.dispatch(0,{action:'CHOOSE_DISCARD',id:'luxury-03'}),null);
    assert.deepEqual(e.status[0].map(c=>c.id),['luxury-10']);
});
test('Fourth end card is revealed but never awarded', () => {
    const e=fixture(); e.endCardsRevealed=3; e.deck=[card('scandale')];
    e.dispatch(0,{action:'PASS'}); e.dispatch(1,{action:'PASS'});
    assert.equal(e.phase,'gameEnd'); assert.equal(e.endCardsRevealed,4);
    assert.equal(e.current.id,'scandale');
    assert.ok(e.status.every(s=>s.every(c=>c.id!=='scandale')));
    assert.ok(e.result); assert.equal(e.view(-1).result.hands.length,3);
});
test('Scoring order, rounding, cast-out, tiebreaks and shared wins', () => {
    assert.equal(score(['luxury-10','luxury-02','passe','prestige-1','prestige-2','scandale'].map(card)).score,14);
    assert.equal(score(['passe','scandale'].map(card)).score,-2);
    assert.equal(score(['luxury-03','scandale'].map(card)).score,1);
    assert.equal(score(['luxury-10','prestige-1','prestige-2','prestige-3'].map(card)).score,80);
    const hands=amounts=>amounts.map(value=>[{id:value,value}]);
    let r=results([[card('luxury-10')],[],[]],hands([1,2,2]));
    assert.deepEqual(r.winners,[1,2]); assert.equal(r.scores[0].castOut,true);
    r=results([[],[],[]],hands([2,2,2])); assert.deepEqual(r.winners,[0,1,2]);
    r=results([[],[],[]],hands([1,2,3])); assert.deepEqual(r.winners,[2]);
    r=results([[],[card('luxury-10')],[card('luxury-04'),card('luxury-06')]],hands([1,2,2]));
    assert.deepEqual(r.winners,[1]);
});
test('Seeded CPU playthroughs terminate, never make illegal moves and conserve money', () => {
    for(let seed=1;seed<=150;seed++) {
        let n=seed;
        const e=new Engine({seats:3+seed%3,rng:()=>((n=(n*1664525+1013904223)>>>0)/2**32)});
        let moves=0;
        while(e.phase!=='gameEnd') {
            assert.equal(e.dispatch(e.turn,decide(e.view(e.turn,Infinity))),null);
            for(let i=0;i<e.hands.length;i++)
                assert.equal([...e.hands[i],...e.table[i]].reduce((s,c)=>s+c.value,0)+e.spent[i],80);
            assert.ok(++moves<1000);
        }
        assert.equal(e.endCardsRevealed,4);
    }
});
