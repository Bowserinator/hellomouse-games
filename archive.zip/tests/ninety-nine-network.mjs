import assert from 'node:assert/strict';
import websocket from 'websocket';
async function connect() {
    const socket = new websocket.w3cwebsocket('ws://localhost:8126');
    const messages = []; const waiters = [];
    socket.onmessage = event => {
        const message = JSON.parse(event.data);
        const index = waiters.findIndex(waiter => waiter.predicate(message));
        if (index < 0) messages.push(message);
        else { const waiter = waiters.splice(index, 1)[0]; clearTimeout(waiter.timer); waiter.resolve(message); }
    };
    await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
    return { socket, send: message => socket.send(JSON.stringify(message)),
        wait: predicate => new Promise((resolve, reject) => {
            const index = messages.findIndex(predicate);
            if (index >= 0) return resolve(messages.splice(index, 1)[0]);
            const timer = setTimeout(() => reject(new Error('Network expectation timed out')), 10000);
            waiters.push({ predicate, timer, resolve });
        }) };
}
const clients = [];
try {
    const host = await connect(); clients.push(host);
    host.send({ type: 'CREATE', gameType: 'ninety_nine' });
    const room = (await host.wait(m => m.type === 'UUID')).uuid;
    const a = await host.wait(m => m.type === 'SYNC'); assert.equal(a.isHost, true);
    const guest = await connect(); clients.push(guest); guest.send({ type: 'JOIN', gameID: room });
    await guest.wait(m => m.type === 'SYNC' && m.youAre === 1);
    host.send({ type: 'MOVE', action: 'SET_OPTIONS', variantId: 'baltimore', seats: 2, tokens: 1 });
    const live = await guest.wait(m => m.type === 'SYNC' && m.settings.variantId === 'baltimore');
    assert.equal(live.isHost, false); assert.equal(live.seats.length, 2);
    host.send({ type: 'READY' }); guest.send({ type: 'READY' });
    await host.wait(m => m.type === 'SYNC' && m.seats.every(s => s.ready));
    host.send({ type: 'MOVE', action: 'START_GAME' });
    const started = await host.wait(m => m.type === 'SYNC' && m.started);
    assert.equal(started.view.players[0].hand[0].rank !== undefined, true);
    assert.ok(started.view.players[1].hand.every(c => Object.keys(c).length === 1));
    const observer = await connect(); clients.push(observer); observer.send({ type: 'JOIN', gameID: room });
    const observed = await observer.wait(m => m.type === 'SYNC');
    assert.equal(observed.youAre, -1); assert.equal(observed.view.events.length, 0);
    assert.ok(observed.view.players.every(p => p.hand.every(c => !c.rank)));
    const guestStart = await guest.wait(m => m.type === 'SYNC' && m.started);
    guest.socket.close();
    await host.wait(m => m.type === 'SYNC' && !m.seats[1].connected);
    observer.send({ type: 'MOVE', action: 'RESUME', token: guestStart.token });
    const resumed = await observer.wait(m => m.type === 'SYNC' && m.youAre === 1);
    assert.equal(resumed.view.events.length, 0); assert.ok(resumed.view.players[1].hand.every(c => c.rank));
    observer.send({ type: 'MOVE', action: 'PLAY', iid: 'forged' });
    assert.equal((await observer.wait(m => m.type === 'ERROR')).code, 'MOVE');
    console.log('Passed WebSocket create/join/live settings/ready/start/privacy/observer/resume/forged move checks');
} finally { for (const client of clients) client.socket.close(); }
