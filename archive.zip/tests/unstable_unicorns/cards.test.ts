import { test } from 'node:test';
import assert from 'node:assert/strict';

import { BASE_CATALOG } from '../../client/unstable_unicorns/js/catalog/base.js';
import { BASE_CUSTOMS, BASE_DEFS } from '../../client/unstable_unicorns/js/engine/cards/index.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';

const registry = buildRegistry(BASE_CATALOG, BASE_DEFS, BASE_CUSTOMS);

test('the current catalog has exactly one usable engine definition per card', () => {
    assert.equal(BASE_CATALOG.length, 76);
    assert.equal(new Set(BASE_CATALOG.map(card => card.id)).size, BASE_CATALOG.length);
    assert.equal(Object.keys(registry.byId).length, BASE_CATALOG.length);

    for (const card of BASE_CATALOG) {
        const def = registry.byId[card.id];
        assert.ok(def, `Missing definition for ${card.id}`);
        assert.equal(def.kind, card.kind, `${card.id} kind differs from its catalog card`);
        assert.ok(card.name.length > 0, `${card.id} has no name`);
        assert.ok(card.text.length > 0, `${card.id} has no rules text`);
    }
});

test('every current catalog card can exist without violating zone conservation', () => {
    const state = emptyState(3, 7);
    for (const [index, card] of BASE_CATALOG.entries())
        createCard(state, `card-${index}`, card.id, index % state.players.length, 'deck');
    assertInvariant(state);
    assert.equal(state.deck.length, BASE_CATALOG.length);
});

test('the confirmed Magical Unicorns remain Basic special Unicorn definitions', () => {
    for (const id of ['narwhal-torpedo', 'unicorn-on-the-cob']) {
        const def = registry.byId[id];
        assert.equal(def.kind, 'basic');
        assert.equal(def.unicornType, 'special');
        assert.ok(def.triggers?.some(trigger => trigger.on === 'enterStable'));
    }
});
