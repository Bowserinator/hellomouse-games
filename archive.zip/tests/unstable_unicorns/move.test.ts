import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { emptyState, createCard } from '../../client/unstable_unicorns/js/engine/state.js';
import { EventLog } from '../../client/unstable_unicorns/js/engine/events.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import type { MoveCtx } from '../../client/unstable_unicorns/js/engine/move.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';

function ctx(defs: Array<CardDef>): { ctx: MoveCtx; calls: Array<{ player: number; source: string }>; add: (defId: string, owner: number, zone: 'hand' | 'stable' | 'nursery' | 'deck' | 'discard') => string } {
    const state = emptyState(3, 7);
    const byId = new Map(defs.map(def => [def.id, def]));
    const calls: Array<{ player: number; source: string }> = [];
    let next = 0;
    const moveCtx: MoveCtx = {
        state,
        log: new EventLog(),
        defOf: iid => byId.get(state.cards[iid].defId),
        runReplacement: (player, source) => {
            calls.push({ player, source });
        }
    };
    return {
        ctx: moveCtx,
        calls,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        }
    };
}

test('play moves hand to stable and raises both events', () => {
    const f = ctx([{ id: 'u', kind: 'basic' }]);
    const iid = f.add('u', 0, 'hand');
    const out = moveCard(f.ctx, iid, 'stable', 'play');

    assert.deepEqual({ moved: out.moved, from: out.from, to: out.to }, { moved: true, from: 'hand', to: 'stable' });
    assert.deepEqual(f.ctx.state.players[0].stable, [iid]);
    assert.deepEqual(f.ctx.state.players[0].hand, []);
    assert.deepEqual(f.ctx.log.drain().map(e => e.type), ['play', 'enterStable']);
    assertInvariant(f.ctx.state);
});

test('babies go to the nursery instead of the discard pile', () => {
    const f = ctx([{ id: 'baby', kind: 'baby' }]);
    const iid = f.add('baby', 0, 'stable');
    const out = moveCard(f.ctx, iid, 'discard', 'destroy');

    assert.equal(out.moved, true);
    assert.equal(out.to, 'nursery');
    assert.deepEqual(f.ctx.state.nursery, [iid]);
    assert.deepEqual(f.ctx.state.discard, []);
    assert.deepEqual(f.ctx.log.drain().map(e => e.type), ['destroy', 'leaveStable']);
    assertInvariant(f.ctx.state);
});

test('protection stops the move before anything happens', () => {
    const f = ctx([
        { id: 'u', kind: 'basic' },
        { id: 'shield', kind: 'upgrade', modifiers: [{ m: 'protect', against: 'destroy' }] }
    ]);
    const u = f.add('u', 0, 'stable');
    f.add('shield', 0, 'stable');

    const out = moveCard(f.ctx, u, 'discard', 'destroy');
    assert.equal(out.moved, false);
    assert.equal(out.shielded, true);
    assert.deepEqual(f.ctx.state.players[0].stable, [u, 'c1']);
    assert.deepEqual(f.ctx.log.drain(), []);
    assertInvariant(f.ctx.state);

    assert.equal(moveCard(f.ctx, u, 'discard', 'sacrifice').moved, true);
});

test('a replacement effect runs instead of the move', () => {
    const f = ctx([
        { id: 'u', kind: 'basic' },
        {
            id: 'saver', kind: 'upgrade',
            replacements: [{ r: 'replace', when: 'destroy', effect: { e: 'prim', prim: { p: 'takeExtraTurn' } } }]
        }
    ]);
    const u = f.add('u', 0, 'stable');
    f.add('saver', 0, 'stable');

    const out = moveCard(f.ctx, u, 'discard', 'destroy');
    assert.equal(out.moved, false);
    assert.equal(out.replaced, true);
    assert.deepEqual(f.calls, [{ player: 0, source: 'c1' }]);
    assert.deepEqual(f.ctx.state.players[0].stable, [u, 'c1']);
    assert.deepEqual(f.ctx.log.drain(), []);
    assertInvariant(f.ctx.state);
});

test('stealing changes the owner and the stable', () => {
    const f = ctx([{ id: 'u', kind: 'basic' }]);
    const u = f.add('u', 1, 'stable');
    const out = moveCard(f.ctx, u, { zone: 'stable', owner: 0 }, 'play');

    assert.equal(out.moved, true);
    assert.deepEqual(f.ctx.state.players[0].stable, [u]);
    assert.deepEqual(f.ctx.state.players[1].stable, []);
    assert.equal(f.ctx.state.cards[u].owner, 0);
    assertInvariant(f.ctx.state);
});

test('cards put back on the deck go on top', () => {
    const f = ctx([{ id: 'u', kind: 'basic' }, { id: 'v', kind: 'basic' }]);
    const top = f.add('v', 0, 'deck');
    const u = f.add('u', 0, 'hand');
    moveCard(f.ctx, u, 'deck', 'discard');
    assert.deepEqual(f.ctx.state.deck, [u, top]);
    assert.equal(f.ctx.state.cards[u].revealedTo.length, 0);
    assertInvariant(f.ctx.state);
});

test('moving an unknown card is a programming error', () => {
    const f = ctx([{ id: 'u', kind: 'basic' }]);
    assert.throws(() => moveCard(f.ctx, 'nope', 'discard', 'destroy'), /unknown card/);
});

test('a card played into another stable is logged as played by the hand owner on the stable owner', async () => {
    const { cardScene } = await import('./scenarios.js');
    const { engine, add, act } = cardScene();
    const downgrade = add('slowdown', 0);
    act({ type: 'PLAY_CARD', iid: downgrade, target: 1 });
    const event = engine.log.history.find(entry => entry.type === 'play' && entry.card === downgrade);
    assert.equal(event?.player, 0);
    assert.equal(event?.targetPlayer, 1);
});
