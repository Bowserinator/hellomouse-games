import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect, Trigger } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { emptyState, createCard } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import { EventLog } from '../../client/unstable_unicorns/js/engine/events.js';
import { seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { ExecCtx } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { startEffect } from '../../client/unstable_unicorns/js/engine/exec/interpreter.js';
import { applyAnswer } from '../../client/unstable_unicorns/js/engine/exec/prompt.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';
import { prim } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';

interface Env {
    ex: ExecCtx;
    state: GameState;
    nodes: NodeMap;
    add(defId: string, owner: number, zone: Zone): string;
    script(effect: Effect, player?: number, source?: string): void;
    chain(): 'wait' | 'done';
}

function env(defs: Array<CardDef>, playerCount = 3, winTarget = 7): Env {
    const state = emptyState(playerCount, winTarget);
    const byId = new Map(defs.map(def => [def.id, def]));
    const nodes: NodeMap = {};
    for (const def of defs) compileCard(def, nodes);
    let next = 0;
    let scripts = 0;
    const ex: ExecCtx = {
        state,
        nodes,
        log: new EventLog(),
        rng: seedFrom('chain'),
        defOf: iid => byId.get(state.cards[iid].defId),
        prompts: { n: 0 },
        custom: {},
        queue: pending => {
            state.links.next.push(pending);
        }
    };
    return {
        ex,
        state,
        nodes,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        },
        script(effect, player = 0, source = 'c0') {
            if (!effect.id) compileCard({ id: `script${++scripts}`, kind: 'magic', onPlay: effect }, nodes);
            startEffect(ex, effect.id as string, player, source);
        },
        chain() {
            return resolveLinks(ex);
        }
    };
}

const drawOne = (): Effect => prim({ p: 'draw', count: 1 });
const killOther = (): Effect => prim({
    p: 'destroy',
    sel: { zone: 'stable', owner: 'other', filter: { f: 'type', type: 'basic' }, count: 1 }
});

const unicorn = (id: string): CardDef => ({ id, kind: 'basic' });
const magic = (id: string): CardDef => ({ id, kind: 'magic' });

const onDestroy = (effect: Effect, when?: Trigger['when']): Trigger => ({ on: 'destroy', effect, when });

test('a trigger raised in a link resolves in the next link', () => {
    const e = env([
        { id: 'a', kind: 'upgrade', triggers: [onDestroy(drawOne())] },
        unicorn('b'),
        unicorn('d')
    ]);
    e.add('a', 0, 'stable');
    const victim = e.add('b', 1, 'stable');
    const top = e.add('d', 0, 'deck');

    e.script(killOther(), 0, 'a');
    assert.equal(e.chain(), 'done');

    assert.equal(e.state.cards[victim].zone, 'discard');
    assert.deepEqual(e.state.players[0].hand, [top]);
});

test('links run in turn order from the active player', () => {
    const defs = [
        { id: 'a', kind: 'upgrade', triggers: [onDestroy(drawOne())] },
        { id: 'c', kind: 'upgrade', triggers: [onDestroy(drawOne())] },
        unicorn('b'),
        unicorn('d1'),
        unicorn('d2')
    ] as Array<CardDef>;

    const run = (active: number) => {
        const e = env(defs);
        e.add('a', 0, 'stable');
        e.add('c', 1, 'stable');
        e.add('b', 2, 'stable');
        const first = e.add('d1', 0, 'deck');
        const second = e.add('d2', 0, 'deck');
        e.state.turn.player = active;
        e.script(killOther(), 0, 'a');
        assert.equal(e.chain(), 'done');
        return { a: e.state.players[0].hand[0], c: e.state.players[1].hand[0], first, second };
    };

    const zero = run(0);
    assert.deepEqual([zero.a, zero.c], [zero.first, zero.second]);

    const one = run(1);
    assert.deepEqual([one.c, one.a], [one.first, one.second]);
});

test('each declared trigger on one card resolves for its event', () => {
    const e = env([
        { id: 'a', kind: 'upgrade', triggers: [onDestroy(drawOne()), onDestroy(drawOne())] },
        unicorn('b'),
        unicorn('d1'),
        unicorn('d2')
    ]);
    e.add('a', 0, 'stable');
    e.add('b', 1, 'stable');
    e.add('d1', 0, 'deck');
    e.add('d2', 0, 'deck');

    e.script(killOther(), 0, 'a');
    assert.equal(e.chain(), 'done');

    assert.equal(e.state.players[0].hand.length, 2);
});

test('events raised inside a link feed the following link', () => {
    const e = env([
        { id: 'a', kind: 'upgrade', triggers: [onDestroy(drawOne())] },
        {
            id: 'w',
            kind: 'upgrade',
            triggers: [{
                on: 'draw',
                when: { c: 'count', zone: 'hand', owner: 'self', filter: { f: 'type', type: 'basic' }, cmp: 'lt', n: 1 },
                effect: drawOne()
            }]
        },
        unicorn('b'),
        unicorn('d1'),
        unicorn('d2'),
        unicorn('d3')
    ]);
    e.add('a', 0, 'stable');
    e.add('w', 1, 'stable');
    e.add('b', 2, 'stable');
    e.add('d1', 0, 'deck');
    e.add('d2', 0, 'deck');
    e.add('d3', 0, 'deck');

    e.script(killOther(), 0, 'a');
    assert.equal(e.chain(), 'done');

    assert.equal(e.state.players[0].hand.length, 1);
    assert.equal(e.state.players[1].hand.length, 1);
});

test('the end of a link preserves non-Unicorn Stable cards', () => {
    const e = env([
        { id: 'up', kind: 'upgrade', modifiers: [{ m: 'stableLimit', value: 1 }] },
        magic('m1'),
        magic('m2')
    ]);
    e.add('up', 0, 'stable');
    const one = e.add('m1', 0, 'stable');
    const two = e.add('m2', 0, 'stable');

    assert.equal(e.chain(), 'done');

    assert.equal(e.state.players[0].stable.length, 3);
    assert.deepEqual(e.state.discard, []);
    assert.ok(e.state.players[0].stable.includes(one));
    assert.ok(e.state.players[0].stable.includes(two));
});

test('stable overflow asks the owner to choose a Unicorn sacrifice', () => {
    const e = env([
        { id: 'limit', kind: 'upgrade', modifiers: [{ m: 'stableLimit', value: 1 }] },
        unicorn('u'),
        unicorn('v')
    ]);
    const limit = e.add('limit', 0, 'stable');
    const first = e.add('u', 0, 'stable');
    const second = e.add('v', 0, 'stable');

    assert.equal(e.chain(), 'wait');
    assert.equal(e.state.prompt?.kind, 'cards');
    assert.deepEqual(new Set(e.state.prompt?.cards), new Set([first, second]));
    applyAnswer(e.state, [first]);
    assert.equal(e.chain(), 'done');
    assert.equal(e.state.cards[first].zone, 'discard');
    assert.equal(e.state.cards[second].zone, 'stable');
    assert.equal(e.state.cards[limit].zone, 'stable');
});

test('reaching the win target marks a pending winner', () => {
    const e = env([unicorn('u'), unicorn('v')], 3, 2);
    e.add('u', 1, 'stable');
    e.add('v', 1, 'stable');

    assert.equal(e.chain(), 'done');

    assert.equal(e.state.pendingWinner, 1);
    assert.equal(e.state.winner, null);
});

test('a pending winner below the win target is cleared', () => {
    const e = env([unicorn('u'), unicorn('v')], 3, 2);
    const first = e.add('u', 1, 'stable');
    const second = e.add('v', 1, 'stable');
    e.state.pendingWinner = 1;

    e.state.players[1].stable = e.state.players[1].stable.filter(iid => iid !== second);
    e.state.cards[first].zone = 'discard';
    e.state.discard.push(first);

    assert.equal(e.chain(), 'done');
    assert.equal(e.state.pendingWinner, null);
});
