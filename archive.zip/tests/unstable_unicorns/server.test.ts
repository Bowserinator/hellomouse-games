import { test } from 'node:test';
import assert from 'node:assert/strict';

import Client from '../../server/client.js';
import UnstableUnicornsGame from '../../server/games/unstable_unicorns.js';
import type { ViewModel } from '../../client/unstable_unicorns/js/engine/view.js';
import { createCard } from '../../client/unstable_unicorns/js/engine/state.js';

interface SeatSync {
    username: string | null;
    ready: boolean;
    connected: boolean;
}

interface SyncMessage {
    type?: string;
    error?: string;
    started?: boolean;
    youAre?: number;
    isHost?: boolean;
    seats?: Array<SeatSync>;
    packs?: Array<string>;
    packNames?: Array<string>;
    minPlayers?: number;
    maxPlayers?: number;
    view?: ViewModel;
    events?: Array<{ seq: number; type: string }>;
}

class MockConnection {
    sent: Array<SyncMessage> = [];

    sendUTF(data: string) {
        this.sent.push(JSON.parse(data) as SyncMessage);
    }
}

interface Player {
    client: Client;
    conn: MockConnection;
}

function addPlayer(game: UnstableUnicornsGame, name: string): Player {
    const conn = new MockConnection();
    const client = new Client(conn);
    client.username = name;
    game.onJoin(client);
    return { client, conn };
}

function room(count = 3): { game: UnstableUnicornsGame; players: Array<Player> } {
    const game = new UnstableUnicornsGame();
    game.uuid = 'room1';
    game.onRoomCreate();
    const players = [] as Array<Player>;
    for (let i = 0; i < count; i++) players.push(addPlayer(game, `p${i}`));
    return { game, players };
}

function lastSync(player: Player): SyncMessage {
    const message = player.conn.sent[player.conn.sent.length - 1];
    assert.equal(message.type, 'SYNC');
    return message;
}

function errors(player: Player): Array<string> {
    return player.conn.sent
        .filter(message => message.type === 'ERROR')
        .map(message => String(message.error));
}

function lastError(player: Player): string {
    const list = errors(player);
    assert.ok(list.length > 0, `${player.client.username} got no error`);
    return list[list.length - 1];
}

function viewOf(player: Player): ViewModel {
    const view = lastSync(player).view;
    assert.ok(view);
    return view;
}

function startedRoom(count = 3) {
    const made = room(count);
    for (const player of made.players) player.client.ready = true;
    made.game.onMove(made.players[0].client, { action: 'START_GAME' });
    return made;
}

test('lobby sync lists seats and packs', () => {
    const { players } = room(3);
    const sync = lastSync(players[0]);

    assert.equal(sync.started, false);
    assert.equal(sync.youAre, 0);
    assert.equal(sync.isHost, true);
    assert.deepEqual(sync.seats?.map(seat => seat.username), ['p0', 'p1', 'p2']);
    assert.deepEqual(sync.packs, ['base']);
    assert.ok(sync.packNames?.includes('base'));
    assert.equal(sync.minPlayers, 3);
    assert.equal(sync.maxPlayers, 8);

    const second = lastSync(players[1]);
    assert.equal(second.youAre, 1);
    assert.equal(second.isHost, false);
});

test('only the host picks packs and starts', () => {
    const { game, players } = room(3);

    game.onMove(players[1].client, { action: 'SET_PACKS', packs: ['base'] });
    assert.equal(lastError(players[1]), 'Only the host picks the packs');

    game.onMove(players[0].client, { action: 'SET_PACKS', packs: ['nope'] });
    assert.equal(lastError(players[0]), 'Unknown pack nope');

    game.onMove(players[1].client, { action: 'START_GAME' });
    assert.equal(lastError(players[1]), 'Only the host starts the game');
});

test('start needs enough players and everyone ready', () => {
    const few = room(2);
    few.game.onMove(few.players[0].client, { action: 'START_GAME' });
    assert.equal(lastError(few.players[0]), 'Not enough players');

    const { game, players } = room(3);
    players[0].client.ready = true;
    players[1].client.ready = true;
    game.onMove(players[0].client, { action: 'START_GAME' });
    assert.equal(lastError(players[0]), 'Not everyone is ready');
    assert.equal(game.started, false);
});

test('start deals a baby pick to every seat', () => {
    const { players } = startedRoom(3);

    for (const player of players) {
        const sync = lastSync(player);
        assert.equal(sync.started, true);
        const view = viewOf(player);
        assert.equal(view.phase, 'PICK_BABY');
        assert.equal(view.winTarget, 7);
        assert.equal(view.nursery.length, 12);
        assert.equal(view.players.length, 3);
    }
});

test('a late client cannot join a started game', () => {
    const { game, players } = startedRoom(3);
    const late = addPlayer(game, 'late');

    assert.equal(game.players.length, 3);
    assert.equal(late.client.isInGame(), false);
    assert.equal(late.conn.sent.length, 0);
    assert.equal(game.players[2], players[2].client);
});

test('sync shows your hand and hides the others', () => {
    const { players } = startedRoom(3);
    const mine = viewOf(players[0]);
    const theirs = viewOf(players[1]);

    const own = mine.players[0].hand;
    assert.ok(own);
    assert.equal(own.length, 5);
    assert.equal(mine.players[1].hand, null);
    assert.equal(mine.players[1].handCount, 5);

    const hidden = own[0];
    assert.ok(hidden in mine.cards);
    assert.equal(hidden in theirs.cards, false);
    assert.doesNotMatch(JSON.stringify(theirs.cards), new RegExp(`"${hidden}"`));
});

test('malformed moves only answer the sender', () => {
    const { game, players } = startedRoom(3);

    game.onMove(players[0].client, { action: 'PLAY_CARD', iid: 5 });
    assert.equal(lastError(players[0]), 'PLAY_CARD needs iid');
    assert.deepEqual(errors(players[1]), []);

    game.onMove(players[0].client, { action: 'DROP_TABLE' });
    assert.equal(lastError(players[0]), 'Unknown move');
});

test('baby picks move to the stable and open the table', () => {
    const { game, players } = startedRoom(3);

    for (const player of players) {
        const baby = viewOf(player).nursery[0];
        game.onMove(player.client, { action: 'PICK_BABY', iid: baby });
        assert.ok(viewOf(player).players[viewOf(player).seat].babyChosen);
    }

    const view = viewOf(players[0]);
    assert.equal(view.phase, 'AWAIT_BEGIN');
    assert.equal(view.turn.player, 0);
    assert.equal(view.nursery.length, 9);
});

test('only the active seat may begin the turn', () => {
    const { game, players } = startedRoom(3);
    for (const player of players) game.onMove(player.client, { action: 'PICK_BABY', iid: viewOf(player).nursery[0] });

    game.onMove(players[1].client, { action: 'BEGIN_TURN' });
    assert.equal(lastError(players[1]), 'It is not your turn');
    assert.deepEqual(errors(players[0]), []);

    game.onMove(players[0].client, { action: 'BEGIN_TURN' });
    let view = viewOf(players[0]);
    assert.equal(view.phase, 'ACTION');
    assert.equal(view.players[0].handCount, 6);
    assert.equal(view.turn.actionsLeft, 1);
    assert.equal(view.turn.drawsLeft, 1);

    game.onMove(players[0].client, { action: 'DRAW_ACTION' });
    view = viewOf(players[0]);
    assert.equal(view.players[0].handCount, 7);
    assert.equal(view.turn.actionsLeft, 0);
    assert.equal(view.turn.drawsLeft, 0);
});

test('events are delivered once per seat', () => {
    const { game, players } = startedRoom(3);
    for (const player of players) game.onMove(player.client, { action: 'PICK_BABY', iid: viewOf(player).nursery[0] });

    game.onMove(players[0].client, { action: 'BEGIN_TURN' });
    const events = lastSync(players[0]).events;
    assert.ok(events);
    assert.ok(events.length > 0);

    game.syncAll();
    assert.deepEqual(lastSync(players[0]).events, []);
    for (const event of events) assert.equal(typeof event.seq, 'number');
});

test('a started game holds the seat of a disconnected player', () => {
    const { game, players } = startedRoom(3);
    game.onDisconnect(players[2].client);

    assert.equal(game.players.length, 3);
    assert.equal(game.players[2], null);
    assert.equal(lastSync(players[0]).seats?.[2].connected, false);

    const again = addPlayer(game, 'p2');
    assert.equal(game.players[2], again.client);
    assert.equal(lastSync(players[0]).seats?.[2].connected, true);
    assert.equal(again.client.username, 'p2');
    assert.equal(viewOf(again).seat, 2);
});

test('a lobby drops the seat of a disconnected player', () => {
    const { game, players } = room(4);
    game.onDisconnect(players[1].client);

    assert.equal(game.players.length, 3);
    assert.deepEqual(lastSync(players[0]).seats?.map(seat => seat.username), ['p0', 'p2', 'p3']);
    assert.equal(lastSync(players[2]).youAre, 1);
});

test('a targeted play reaches the chosen stable', () => {
    const { game, players } = startedRoom(3);
    for (const player of players) {
        const baby = viewOf(player).nursery[0];
        game.onMove(player.client, { action: 'PICK_BABY', iid: baby });
    }
    game.onMove(players[0].client, { action: 'BEGIN_TURN' });

    const engine = game.engine;
    assert.ok(engine);
    createCard(engine.state, 'planted', 'pandamonium', 0, 'hand');
    game.onMove(players[0].client, { action: 'PLAY_CARD', iid: 'planted', target: 1 });

    assert.deepEqual(errors(players[0]), []);
    assert.equal(viewOf(players[1]).cards.planted?.owner, 1);
    assert.equal(viewOf(players[1]).players[1].stable.includes('planted'), true);
    assert.equal(viewOf(players[0]).cards.planted?.owner, 1);
});
