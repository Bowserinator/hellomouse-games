import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, CatalogEntry } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { prim } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';
import { catalogFor, PACKS, packNames } from '../../client/unstable_unicorns/js/catalog/index.js';

const entry = (id: string, copies = 1, kind: CatalogEntry['kind'] = 'basic'): CatalogEntry => ({
    id,
    kind,
    name: id,
    text: id,
    copies
});

const unicorn = (id: string): CardDef => ({ id, kind: 'basic' });

test('packs define descriptions alongside their catalogs', () => {
    for (const name of packNames()) {
        assert.ok(PACKS[name].dsc.trim().length > 0);
        assert.ok(PACKS[name].cards.length > 0);
        assert.deepEqual(catalogFor([name]), PACKS[name].cards);
    }
    assert.deepEqual(catalogFor(packNames()), Object.values(PACKS).flatMap(pack => pack.cards));
    assert.throws(() => catalogFor(['unknown-pack']), /Unknown card pack unknown-pack/);
});

test('a catalog entry without a script fails fast', () => {
    assert.throws(
        () => buildRegistry([entry('ghost')], [unicorn('real')], new Set()),
        /ghost: catalog entry has no card script/
    );
});

test('a script without a catalog entry fails fast', () => {
    assert.throws(
        () => buildRegistry([entry('real')], [unicorn('real'), unicorn('ghost')], new Set()),
        /ghost: card script has no catalog entry/
    );
});

test('an invalid script fails fast with every issue', () => {
    const broken: CardDef = { id: 'broken', kind: 'magic', onPlay: prim({ p: 'draw', count: -1 }) };
    assert.throws(() => buildRegistry([entry('broken', 1, 'magic')], [broken], new Set()),
        /Card registry is invalid/);
});

test('the deck list expands the printed copies', () => {
    const registry = buildRegistry(
        [entry('a', 3), entry('b', 2)],
        [unicorn('a'), unicorn('b')],
        new Set()
    );
    assert.deepEqual(registry.deckList, ['a', 'a', 'a', 'b', 'b']);
});

test('compiling assigns node ids from card ids', () => {
    const registry = buildRegistry(
        [entry('spell', 1, 'magic')],
        [{ id: 'spell', kind: 'magic', onPlay: prim({ p: 'draw', count: 1 }) }],
        new Set()
    );
    assert.ok(registry.nodes['spell#onPlay']);
});
