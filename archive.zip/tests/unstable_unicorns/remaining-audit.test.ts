import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cardScene } from './scenarios.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import { moveCtxOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';

function moveToStable(engine: ReturnType<typeof cardScene>['engine'], iid: string, owner = 0) {
    assert.equal(moveCard(moveCtxOf(engine.ex), iid, { zone: 'stable', owner }, 'play').moved, true);
    resolveLinks(engine.ex);
}

test('Alluring Narwhal does not retrigger on an unrelated entry', () => {
    const { engine, add, answer } = cardScene();
    add('double-dutch', 1, 'stable');
    const alluring = add('alluring-narwhal');
    moveToStable(engine, alluring);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(false);
    const unrelated = add('basic-unicorn-blue');
    moveToStable(engine, unrelated);
    assert.equal(engine.state.prompt, null);
});

test('Blinding Light suppresses matching entry and turn-start triggers', () => {
    const { engine, add } = cardScene();
    add('blinding-light', 0, 'stable');
    add('extra-tail', 0, 'stable');
    add('basic-unicorn-blue', 0, 'deck');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.players[0].hand.length, 0);

    const greedy = add('greedy-flying-unicorn');
    moveToStable(engine, greedy);
    assert.equal(engine.state.players[0].hand.length, 0);
});

test('Chainsaw Unicorn and Targeted Destruction offer sacrifice and destroy choices', () => {
    const chainsaw = cardScene();
    const ownUpgrade = chainsaw.add('double-dutch', 0, 'stable');
    const victim = chainsaw.add('slowdown', 1, 'stable');
    const card = chainsaw.add('chainsaw-unicorn');
    chainsaw.act({ type: 'PLAY_CARD', iid: card });
    chainsaw.answer(true);
    assert.equal(chainsaw.engine.state.prompt?.kind, 'option');
    chainsaw.answer(1);
    chainsaw.answer([victim]);
    assert.equal(chainsaw.engine.state.cards[victim].zone, 'discard');
    assert.equal(chainsaw.engine.state.cards[ownUpgrade].zone, 'stable');

    const targeted = cardScene();
    const sacrifice = targeted.add('double-dutch', 0, 'stable');
    const target = targeted.add('slowdown', 1, 'stable');
    const spell = targeted.add('targeted-destruction');
    targeted.act({ type: 'PLAY_CARD', iid: spell });
    assert.equal(targeted.engine.state.prompt?.kind, 'option');
    targeted.answer(0);
    assert.equal(targeted.engine.state.cards[sacrifice].zone, 'discard');
    assert.equal(targeted.engine.state.cards[target].zone, 'stable');
});

test('Change of Luck draws, discards, and grants one extra turn', () => {
    const { engine, add, act, answer } = cardScene();
    for (let i = 0; i < 5; i++) add('basic-unicorn-blue', 0, 'deck');
    for (let i = 0; i < 3; i++) add('neigh', 0);
    const change = add('change-of-luck');
    act({ type: 'PLAY_CARD', iid: change });
    assert.equal(engine.state.prompt?.kind, 'cards');
    answer(engine.state.prompt!.cards.slice(0, 3));
    assert.equal(engine.state.turn.extraTurns, 1);
    assert.equal(engine.state.players[0].hand.length, 2);
});

test('Extra Tail is optional and Sadistic Ritual is mandatory on the owners turn', () => {
    const extra = cardScene();
    extra.add('extra-tail', 0, 'stable');
    extra.add('basic-unicorn-blue', 0, 'deck');
    extra.engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(extra.engine.ex);
    assert.equal(extra.engine.state.prompt?.kind, 'yesno');
    extra.answer(true);
    assert.equal(extra.engine.state.players[0].hand.length, 1);

    const ritual = cardScene();
    const sacrifice = ritual.add('basic-unicorn-blue', 0, 'stable');
    ritual.add('sadistic-ritual', 0, 'stable');
    ritual.add('basic-unicorn-green', 0, 'deck');
    ritual.engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(ritual.engine.ex);
    assert.equal(ritual.engine.state.cards[sacrifice].zone, 'discard');
    assert.equal(ritual.engine.state.players[0].hand.length, 1);
});

test('Flying Unicorns offer optional retrieval of their matching discard cards', () => {
    for (const [source, fetched] of [
        ['magical-flying-unicorn', 'change-of-luck'],
        ['majestic-flying-unicorn', 'basic-unicorn-blue'],
        ['swift-flying-unicorn', 'neigh']
    ] as const) {
        const { engine, add, act, answer } = cardScene();
        const card = add(fetched, 0, 'discard');
        const flying = add(source);
        act({ type: 'PLAY_CARD', iid: flying });
        assert.equal(engine.state.prompt?.kind, 'yesno', source);
        answer(true);
        assert.equal(engine.state.prompt?.kind, 'cards', source);
        answer([card]);
        assert.equal(engine.state.cards[card].zone, 'hand', source);
    }
});

test('Rainbow Unicorn offers only a plain Basic Unicorn from its owners hand', () => {
    const { engine, add, act, answer } = cardScene();
    const plain = add('basic-unicorn-blue');
    const special = add('narwhal-torpedo');
    const rainbow = add('rainbow-unicorn');
    act({ type: 'PLAY_CARD', iid: rainbow });
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.cards[plain].zone, 'stable');
    assert.equal(engine.state.cards[special].zone, 'hand');
});

test('Unfair Bargain swaps complete hands with the chosen opponent', () => {
    const { engine, add, act, answer } = cardScene();
    const own = add('neigh', 0);
    const other = add('super-neigh', 1);
    const bargain = add('unfair-bargain');
    act({ type: 'PLAY_CARD', iid: bargain });
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.cards[own].owner, 1);
    assert.equal(engine.state.cards[other].owner, 0);
    assert.equal(engine.state.cards[bargain].zone, 'discard');
});

test('Queen Bee blocks Basic entry into other Stables, not her own Stable', () => {
    const { engine, add } = cardScene(2);
    add('queen-bee-unicorn', 1, 'stable');
    const plain = add('basic-unicorn-blue');
    assert.equal(engine.view(0).playable.includes(plain), false);
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: plain }).ok, false);
    assert.equal(moveCard(moveCtxOf(engine.ex), plain, { zone: 'stable', owner: 0 }, 'play').moved, false);
    assert.equal(engine.state.cards[plain].zone, 'hand');
    assert.equal(moveCard(moveCtxOf(engine.ex), plain, { zone: 'stable', owner: 1 }, 'play').moved, true);
    const special = add('narwhal-torpedo');
    assert.equal(moveCard(moveCtxOf(engine.ex), special, { zone: 'stable', owner: 0 }, 'play').moved, true);
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[plain].owner, 1);
    assert.equal(engine.state.cards[special].owner, 0);
    assert.equal(engine.state.cards[special].zone, 'stable');
});

test('Temporary theft returns a card that moved to another Stable', () => {
    const { engine, add, act } = cardScene();
    const seductive = add('seductive-unicorn');
    const stolen = add('basic-unicorn-blue', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: seductive });
    assert.equal(engine.state.cards[stolen].owner, 0);
    moveCard(moveCtxOf(engine.ex), stolen, { zone: 'stable', owner: 2 }, 'play');
    moveCard(moveCtxOf(engine.ex), seductive, 'discard', 'destroy');
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[stolen].owner, 1);
    assert.equal(engine.state.cards[stolen].zone, 'stable');
});
