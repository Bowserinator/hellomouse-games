import assert from 'node:assert/strict';
import { BASE_CATALOG } from '../../client/unstable_unicorns/js/catalog/base.js';
import { BASE_CUSTOMS, BASE_DEFS } from '../../client/unstable_unicorns/js/engine/cards/index.js';
import { Engine } from '../../client/unstable_unicorns/js/engine/engine.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import type { Binding, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';

export const registry = buildRegistry(BASE_CATALOG, BASE_DEFS, BASE_CUSTOMS);

export function cardScene(playerCount = 3) {
    const engine = new Engine({ registry, playerCount, seed: 'card-regression' });
    engine.state = emptyState(playerCount, 7);
    engine.state.phase = 'ACTION';
    let next = 0;
    const add = (defId: string, owner = 0, zone: Zone = 'hand') => {
        assert.ok(registry.byId[defId], `Unknown fixture card ${defId}`);
        const iid = `scenario${next++}`;
        createCard(engine.state, iid, defId, owner, zone);
        return iid;
    };
    const act = (action: unknown, seat = engine.state.turn.player) => {
        const result = engine.dispatch(seat, action);
        if (!result.ok) assert.fail(result.error);
        assertInvariant(engine.state);
    };
    const answer = (selection: Binding) => {
        const prompt = engine.state.prompt;
        assert.ok(prompt, 'Expected a prompt');
        act({ type: 'RESPOND', promptId: prompt.id, selection }, prompt.player);
    };
    return { engine, add, act, answer };
}
