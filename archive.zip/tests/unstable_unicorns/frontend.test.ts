import { test } from 'node:test';
import assert from 'node:assert/strict';

import { contentSize, layout } from '../../client/unstable_unicorns/js/ui/polygon.js';
import type { Vec } from '../../client/unstable_unicorns/js/ui/polygon.js';
import {
    MAX_SCALE, MIN_SCALE, clampScale, contains, fitCamera, panBy, screenToWorld, worldToScreen, zoomAt
} from '../../client/unstable_unicorns/js/ui/camera-math.js';
import { nextStep } from '../../client/unstable_unicorns/js/next-step.js';
import type { NextStep } from '../../client/unstable_unicorns/js/next-step.js';
import type { CardView, PromptView, ViewModel } from '../../client/unstable_unicorns/js/engine/view.js';

const CARD = { w: 143, h: 198 };

function rotate(point: Vec, deg: number): Vec {
    const rad = (deg * Math.PI) / 180;
    return {
        x: point.x * Math.cos(rad) - point.y * Math.sin(rad),
        y: point.x * Math.sin(rad) + point.y * Math.cos(rad)
    };
}

function view(overrides: Partial<ViewModel> = {}): ViewModel {
    const cards: Record<string, CardView> = {
        a: { defId: 'unicorn', owner: 0, zone: 'stable', revealed: true, neighable: false }
    };
    const base: ViewModel = {
        seat: 0,
        phase: 'ACTION',
        turn: { player: 0, actionsUsed: 0, actionsLeft: 1, drawsUsed: 0, drawsLeft: 1 },
        winTarget: 7,
        winner: null,
        winReason: null,
        over: false,
        pendingWinner: null,
        players: [
            { id: 0, handCount: 2, hand: ['a'], stable: ['a'], babyChosen: true, unicorns: 1 },
            { id: 1, handCount: 3, hand: null, stable: [], babyChosen: true, unicorns: 0 }
        ],
        cards,
        deckCount: 20,
        discard: [],
        nursery: [],
        handLimit: 7,
        prompt: null,
        promptOpen: false,
        waitingOn: [0],
        chain: { top: null, canNeigh: false },
        playable: [],
        needsTarget: [],
        blockers: {},
        targets: {},
        futile: {},
        ...overrides
    };
    base.promptOpen = overrides.promptOpen ?? (overrides.prompt !== null && overrides.prompt !== undefined);
    return base;
}

test('polygon: the local seat sits at 0 degrees at the bottom', () => {
    for (let count = 3; count <= 8; count++) {
        const table = layout(count, CARD, 1);
        assert.equal(table.seats[1].rotationDeg, 0);
        assert.ok(Math.abs(table.seats[1].anchor.x) < 1e-9, `seat at bottom for ${count}`);
        assert.ok(table.seats[1].anchor.y > 0);
    }
});

test('polygon: seats are equally spaced and on the ring', () => {
    for (let count = 3; count <= 8; count++) {
        const table = layout(count, CARD);
        table.seats.forEach((seat, index) => {
            assert.ok(Math.abs(seat.rotationDeg - (360 * index) / count) < 1e-9);
            const distance = Math.hypot(seat.anchor.x, seat.anchor.y);
            assert.ok(Math.abs(distance - table.radius) < 1e-9);
        });
        for (let index = 1; index < count; index++) {
            const previous = table.seats[index - 1].anchor;
            const current = table.seats[index].anchor;
            const chord = Math.hypot(current.x - previous.x, current.y - previous.y);
            assert.ok(chord >= CARD.w, `regions overlap for ${count} players`);
        }
    }
});

test('polygon: each seat faces the table center', () => {
    for (let count = 3; count <= 8; count++) {
        const table = layout(count, CARD, 2);
        table.seats.forEach(seat => {
            const up = rotate({ x: 0, y: -1 }, seat.rotationDeg);
            const toCenter = { x: -seat.anchor.x, y: -seat.anchor.y };
            const length = Math.hypot(toCenter.x, toCenter.y);
            assert.ok(Math.abs(up.x - toCenter.x / length) < 1e-9);
            assert.ok(Math.abs(up.y - toCenter.y / length) < 1e-9);
        });
    }
});

test('polygon: content size covers the ring and the card regions', () => {
    const table = layout(6, CARD);
    const size = contentSize(table, CARD);
    assert.ok(size.w >= table.radius * 2);
    assert.ok(size.h >= table.radius * 2);
});

test('camera: zoom keeps the cursor point fixed', () => {
    const camera = { x: 40, y: 20, scale: 1 };
    const cursor = { x: 300, y: 200 };
    const before = screenToWorld(camera, cursor);
    const zoomed = zoomAt(camera, cursor, 1.5);
    const after = screenToWorld(zoomed, cursor);
    assert.ok(Math.abs(before.x - after.x) < 1e-9);
    assert.ok(Math.abs(before.y - after.y) < 1e-9);
});

test('camera: zoom clamps at both ends', () => {
    const camera = { x: 0, y: 0, scale: 1 };
    const point = { x: 10, y: 10 };
    let zoomed = camera;
    for (let step = 0; step < 40; step++) zoomed = zoomAt(zoomed, point, 1.5);
    assert.equal(zoomed.scale, MAX_SCALE);
    for (let step = 0; step < 80; step++) zoomed = zoomAt(zoomed, point, 0.5);
    assert.equal(zoomed.scale, MIN_SCALE);
    assert.equal(clampScale(99), MAX_SCALE);
    assert.equal(clampScale(0), MIN_SCALE);
});

test('camera: pan and zoom compose without drift', () => {
    const camera = { x: 12, y: -8, scale: 0.8 };
    const point = { x: 120, y: 90 };
    const world = screenToWorld(camera, point);
    const moved = panBy(camera, 30, -20);
    const back = panBy(moved, -30, 20);
    assert.deepEqual(back, camera);
    const screen = worldToScreen(camera, world);
    assert.ok(Math.abs(screen.x - point.x) < 1e-9);
    assert.ok(Math.abs(screen.y - point.y) < 1e-9);
});

test('camera: fit contains the table for every player count', () => {
    const viewport = { w: 1280, h: 800 };
    for (let count = 3; count <= 8; count++) {
        const table = layout(count, CARD);
        const size = contentSize(table, CARD);
        const camera = fitCamera(size, viewport);
        assert.ok(contains(camera, size, viewport), `fit fails for ${count} players`);
    }
});

test('next step: full state table', () => {
    const cases: Array<[string, Partial<ViewModel>, NextStep]> = [
        ['your turn has not begun', { phase: 'AWAIT_BEGIN' }, 'begin-turn'],
        ['legal plays and actions left', { playable: ['a'] }, 'end-turn'],
        ['actions left, no legal plays', { playable: [] }, 'draw'],
        ['no actions left, draw would spend nothing', { turn: { player: 0, actionsUsed: 1, actionsLeft: 0, drawsUsed: 1, drawsLeft: 0 } }, 'end-turn'],
        ['no cards left to draw', { playable: [], deckCount: 0, discard: [] }, 'end-turn'],
        ['not your turn', { turn: { player: 1, actionsUsed: 0, actionsLeft: 1, drawsUsed: 0, drawsLeft: 1 } }, null],
        ['waiting on a prompt', {
            prompt: { id: 1, player: 0, kind: 'yesno', reason: 'neigh?', source: null, cards: [], players: [], min: 0, max: 1 } as PromptView
        }, null],
        ['game over', { winner: 0 }, null],
        ['game over with everyone losing', { over: true, winner: null }, null],
        ['discarding down to the hand limit', { phase: 'DISCARD_LIMIT' }, null],
        ['picking a baby unicorn', { phase: 'PICK_BABY' }, null]
    ];
    for (const [label, overrides, expected] of cases)
        assert.equal(nextStep(view(overrides)), expected, label);
});
