import { test } from 'node:test';
import assert from 'node:assert/strict';

import { Engine } from '../../client/unstable_unicorns/js/engine/engine.js';
import type { Action } from '../../client/unstable_unicorns/js/engine/engine.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { BASE_CUSTOMS, BASE_DEFS } from '../../client/unstable_unicorns/js/engine/cards/index.js';
import { BASE_CATALOG } from '../../client/unstable_unicorns/js/catalog/base.js';
import { nextInt, seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { Rng } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { Binding, GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import { WILDCARD } from '../../client/unstable_unicorns/js/vars.js';

const GAMES = Number(process.env.FUZZ_GAMES ?? 1000);
const MAX_ACTIONS = 3000;

const registry = buildRegistry(BASE_CATALOG, BASE_DEFS, BASE_CUSTOMS);

function newEngine(seed: string, playerCount: number): Engine {
    return new Engine({ registry, playerCount, seed });
}

interface ZoneList {
    zone: Zone;
    owner: number;
    iids: Array<string>;
}

function zoneLists(state: GameState): Array<ZoneList> {
    const lists: Array<ZoneList> = [
        { zone: 'deck', owner: -1, iids: state.deck },
        { zone: 'discard', owner: -1, iids: state.discard },
        { zone: 'nursery', owner: -1, iids: state.nursery },
        { zone: 'limbo', owner: -1, iids: state.limbo }
    ];
    for (const player of state.players) {
        lists.push({ zone: 'hand', owner: player.id, iids: player.hand });
        lists.push({ zone: 'stable', owner: player.id, iids: player.stable });
    }
    return lists;
}

function checkInvariants(state: GameState, where: string): void {
    const seen = new Set<string>();
    for (const list of zoneLists(state)) {
        for (const iid of list.iids) {
            assert.equal(seen.has(iid), false, `${where}: ${iid} is in two zones`);
            seen.add(iid);
            const card = state.cards[iid];
            assert.ok(card, `${where}: ${iid} has no card entry`);
            assert.equal(card.zone, list.zone, `${where}: ${iid} sits in ${list.zone} but claims ${card.zone}`);
            if (list.zone === 'hand' || list.zone === 'stable')
                assert.equal(card.owner, list.owner, `${where}: ${iid} owner mismatch`);
        }
        assert.equal(new Set(list.iids).size, list.iids.length, `${where}: duplicate iid inside ${list.zone}`);
    }
    for (const iid of Object.keys(state.cards))
        assert.equal(seen.has(iid), true, `${where}: ${iid} is in cards but in no zone`);

    const encoded = JSON.stringify(state);
    assert.equal(encoded.includes('undefined'), false, `${where}: undefined leaked into the state`);
    assert.equal(encoded.includes(WILDCARD), false, `${where}: wildcard leaked into a real state`);
    assert.deepEqual(JSON.parse(encoded), state, `${where}: state does not survive a JSON round trip`);
}

function hash(text: string): string {
    let value = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) {
        value ^= text.charCodeAt(i);
        value = Math.imul(value, 0x01000193) >>> 0;
    }
    return value.toString(16).padStart(8, '0');
}

function shuffleIn(rng: Rng, items: Array<string>): Array<string> {
    const list = [...items];
    for (let i = list.length - 1; i > 0; i--) {
        const j = nextInt(rng, i + 1);
        [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
}

function randomAnswer(prompt: NonNullable<GameState['prompt']>, rng: Rng): Binding {
    if (prompt.kind === 'order') return shuffleIn(rng, prompt.cards);
    if (prompt.kind === 'player') return [prompt.players[nextInt(rng, prompt.players.length)]];
    if (prompt.kind === 'yesno') return nextInt(rng, 2) === 1;
    if (prompt.kind === 'option') return prompt.min + nextInt(rng, Math.max(1, prompt.max - prompt.min + 1));

    const max = Math.min(prompt.cards.length, prompt.max);
    const min = Math.min(prompt.min, max);
    const wanted = min + nextInt(rng, Math.max(1, max - min + 1));
    return shuffleIn(rng, prompt.cards).slice(0, wanted);
}

function instantInHand(engine: Engine, seat: number): string | null {
    const state = engine.state;
    for (const iid of state.players[seat].hand) {
        const def = registry.byId[state.cards[iid].defId];
        if (def?.instant) return iid;
    }
    return null;
}

function botAction(engine: Engine, seat: number, rng: Rng): Action | null {
    const state = engine.state;
    const me = state.players[seat];

    if (state.phase === 'PICK_BABY' && !me.babyChosen) {
        const baby = state.nursery.find(iid => registry.byId[state.cards[iid].defId]?.kind === 'baby');
        if (baby) return { type: 'PICK_BABY', iid: baby };
        return null;
    }

    if (state.prompt && state.prompt.player === seat)
        return { type: 'RESPOND', promptId: state.prompt.id, selection: randomAnswer(state.prompt, rng) };
    if (state.prompt) return null;

    if (state.phase === 'AWAIT_BEGIN' && state.turn.player === seat) return { type: 'BEGIN_TURN' };

    if (state.phase === 'DISCARD_LIMIT' && state.turn.player === seat) {
        const limit = engine.view(seat).handLimit;
        const excess = me.hand.length - limit;
        if (excess <= 0) return null;
        return { type: 'DISCARD', iids: shuffleIn(rng, me.hand).slice(0, excess) };
    }

    if (state.phase !== 'ACTION' || state.turn.player !== seat) return null;
    if (state.prompt) return null;

    const view = engine.view(seat);
    if (view.turn.actionsLeft <= 0 && view.turn.drawsLeft <= 0) return { type: 'END_TURN' };
    if (view.pendingWinner !== null) return { type: 'END_TURN' };

    const roll = nextInt(rng, 10);
    if (roll === 0 && view.chain.top && view.chain.canNeigh) {
        const instant = instantInHand(engine, seat);
        if (instant) return { type: 'NEIGH', iid: instant, targetEntryId: view.chain.top.id };
    }
    if (roll <= 2 && view.turn.drawsLeft > 0 && (view.deckCount > 0 || view.discard.length > 0))
        return { type: 'DRAW_ACTION' };
    if (roll <= 5 && view.playable.length > 0) {
        const iid = view.playable[nextInt(rng, view.playable.length)];
        if (view.needsTarget.includes(iid))
            return { type: 'PLAY_CARD', iid, target: nextInt(rng, state.players.length) };
        return { type: 'PLAY_CARD', iid };
    }
    return { type: 'END_TURN' };
}

interface Played {
    actions: Array<{ seat: number; action: Action }>;
    state: GameState;
    steps: number;
}

function playGame(seed: string, playerCount: number): Played {
    const engine = newEngine(seed, playerCount);
    const rng = seedFrom(`${seed}:bot`);
    const actions: Array<{ seat: number; action: Action }> = [];
    let steps = 0;

    while (engine.state.phase !== 'OVER' && steps < MAX_ACTIONS) {
        let acted = false;
        for (let seat = 0; seat < playerCount && !acted; seat++) {
            const action = botAction(engine, seat, rng);
            if (!action) continue;
            const result = engine.dispatch(seat, action);
            assert.equal(result.ok, true, `${seed} seat ${seat}: ${JSON.stringify(action)} failed: ${result.ok ? '' : result.error}; prompt=${JSON.stringify(engine.state.prompt)}`);
            actions.push({ seat, action });
            steps++;
            acted = true;
            checkInvariants(engine.state, `${seed} step ${steps}`);
        }
        if (!acted) break;
    }

    return { actions, state: engine.state, steps };
}

test('seeded self-play keeps the state invariants and ends', () => {
    let finished = 0;
    let capped = 0;
    let totalSteps = 0;

    for (let game = 0; game < GAMES; game++) {
        const playerCount = 3 + (game % 6);
        const seed = `fuzz-${game}`;
        const played = playGame(seed, playerCount);
        totalSteps += played.steps;

        if (played.state.phase === 'OVER') {
            finished++;
            assert.ok(played.state.winner === null || played.state.winner < playerCount, `${seed}: winner out of range`);
            assert.ok(played.state.winner !== null || played.state.winReason === 'allLose', `${seed}: no winner without all losing`);
        } else {
            capped++;
            assert.ok(played.steps >= MAX_ACTIONS, `${seed}: stopped early without a winner at step ${played.steps}`);
        }

        assert.equal(played.state.prompt, null, `${seed}: game ended with an open prompt`);
        assert.deepEqual(played.state.players.map(player => player.id), [...Array(playerCount).keys()]);
    }

    assert.ok(finished > 0, 'no game reached a winner');
    assert.ok(capped < GAMES * 0.05, `${capped} of ${GAMES} games hit the action cap`);
    assert.ok(totalSteps > GAMES * 10, 'games were suspiciously short');
});

test('the same seed and action log reproduce the same final state', () => {
    for (let game = 0; game < 40; game++) {
        const playerCount = 3 + (game % 6);
        const seed = `replay-${game}`;
        const played = playGame(seed, playerCount);
        const expected = hash(JSON.stringify(played.state));

        const replay = newEngine(seed, playerCount);
        for (const entry of played.actions) {
            const result = replay.dispatch(entry.seat, entry.action);
            assert.equal(result.ok, true, `${seed}: replay rejected ${JSON.stringify(entry.action)}`);
        }

        assert.equal(hash(JSON.stringify(replay.state)), expected, `${seed}: replay diverged`);
    }
});

test('stale and foreign actions are rejected without touching the state', () => {
    const engine = newEngine('reject', 3);
    for (let seat = 0; seat < 3; seat++)
        assert.equal(engine.dispatch(seat, { type: 'PICK_BABY', iid: engine.state.nursery[0] }).ok, true);

    const before = JSON.stringify(engine.state);
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: 'missing' }).ok, false);
    assert.equal(engine.dispatch(5, { type: 'BEGIN_TURN' }).ok, false);
    assert.equal(engine.dispatch(0, { type: 'RESPOND', promptId: 99, selection: [] }).ok, false);
    assert.equal(engine.dispatch(1, { type: 'NEIGH', iid: 'x', targetEntryId: 1 }).ok, false);
    assert.equal(engine.dispatch(0, { type: 'DISCARD', iids: ['x'] }).ok, false);
    assert.equal(JSON.stringify(engine.state), before);
    assert.equal(engine.dispatch(0, { type: 'BEGIN_TURN' }).ok, true);

    const promptEngine = newEngine('stale', 3);
    for (let seat = 0; seat < 3; seat++)
        promptEngine.dispatch(seat, { type: 'PICK_BABY', iid: promptEngine.state.nursery[0] });
    promptEngine.dispatch(0, { type: 'BEGIN_TURN' });
    const rng = seedFrom('stale:bot');
    for (let step = 0; step < 30; step++) {
        const seat = promptEngine.state.prompt ? promptEngine.state.prompt.player : promptEngine.state.turn.player;
        const action = botAction(promptEngine, seat, rng);
        if (!action) break;
        assert.equal(promptEngine.dispatch(seat, action).ok, true);
        if (promptEngine.state.phase === 'OVER') break;
    }
});
