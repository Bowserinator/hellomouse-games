import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, CatalogEntry } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { Engine } from '../../client/unstable_unicorns/js/engine/engine.js';
import { prim } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';
import { createCard } from '../../client/unstable_unicorns/js/engine/state.js';

const entry = (id: string, copies: number, kind: CatalogEntry['kind']): CatalogEntry => ({
    id,
    kind,
    name: id,
    text: id,
    copies
});

const catalog: Array<CatalogEntry> = [
    entry('baby', 3, 'baby'),
    entry('basic', 9, 'basic'),
    entry('up', 4, 'upgrade'),
    entry('down', 4, 'downgrade'),
    entry('selfonly', 2, 'upgrade'),
    entry('otheronly', 2, 'upgrade'),
    entry('ask', 4, 'magic')
];

const defs: Array<CardDef> = [
    { id: 'baby', kind: 'baby' },
    { id: 'basic', kind: 'basic' },
    { id: 'up', kind: 'upgrade' },
    { id: 'down', kind: 'downgrade', playTarget: 'any' },
    { id: 'selfonly', kind: 'upgrade', playTarget: 'self' },
    { id: 'otheronly', kind: 'upgrade', playTarget: 'other' },
    {
        id: 'ask',
        kind: 'magic',
        onPlay: prim({
            p: 'discard',
            sel: { zone: 'hand', owner: 'self', count: 1 }
        })
    }
];

function engine(seed = 'targeting'): Engine {
    return new Engine({
        registry: buildRegistry(catalog, defs, new Set()),
        playerCount: 3,
        seed
    });
}

let counter = 0;

function give(e: Engine, seat: number, defId: string): string {
    const iid = `x${counter++}`;
    createCard(e.state, iid, defId, seat, 'hand');
    return iid;
}

function acting(e: Engine) {
    e.state.phase = 'ACTION';
    e.state.turn.player = 0;
    e.state.turn.actionsUsed = 0;
    e.state.prompt = null;
}

test('a downgrade goes into the chosen stable', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'down');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 1 }), { ok: true });
    assert.equal(e.state.cards[card].owner, 1);
    assert.equal(e.state.players[1].stable.includes(card), true);
    assertInvariant(e.state);
});

test('a downgrade without a target stays in the owner stable', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'down');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: card }), { ok: true });
    assert.equal(e.state.cards[card].owner, 0);
    assertInvariant(e.state);
});

test('an unknown target seat is refused', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'down');
    const result = e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 9 });
    assert.equal(result.ok, false);
    assert.match(result.ok ? '' : result.error, /target stable/);
    assert.equal(e.state.cards[card].zone, 'hand');
});

test('a non-integer target seat is refused', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'down');
    const result = e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 'one' });
    assert.equal(result.ok, false);
    assert.match(result.ok ? '' : result.error, /must be a seat/);
});

test('an upgrade can be pushed into another stable', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'up');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 1 }), { ok: true });
    assert.equal(e.state.cards[card].owner, 1);
    assert.equal(e.state.players[1].stable.includes(card), true);
    assertInvariant(e.state);
});

test('a basic unicorn enters the owner stable even when a target is given', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'basic');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 1 }), { ok: true });
    assert.equal(e.state.cards[card].owner, 0);
    assert.equal(e.state.players[0].stable.includes(card), true);
    assertInvariant(e.state);
});

test('a self only card rejects another stable', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'selfonly');
    const result = e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 1 });
    assert.equal(result.ok, false);
    assert.match(result.ok ? '' : result.error, /your own stable/);
});

test('an other only card rejects the own stable', () => {
    const e = engine();
    acting(e);
    const card = give(e, 0, 'otheronly');
    const result = e.dispatch(0, { type: 'PLAY_CARD', iid: card, target: 0 });
    assert.equal(result.ok, false);
    assert.match(result.ok ? '' : result.error, /another stable/);
});

test('the view marks the cards that need a target seat and their legal targets', () => {
    const e = engine();
    acting(e);
    e.state.players[0].hand.length = 0;
    const down = give(e, 0, 'down');
    const up = give(e, 0, 'up');
    const selfonly = give(e, 0, 'selfonly');
    const otheronly = give(e, 0, 'otheronly');
    const basic = give(e, 0, 'basic');
    const view = e.view(0);
    assert.deepEqual(view.needsTarget, [down, up, selfonly, otheronly]);
    assert.equal(view.playable.includes(up), true);
    assert.deepEqual(view.targets[down], [0, 1, 2]);
    assert.deepEqual(view.targets[up], [0, 1, 2]);
    assert.deepEqual(view.targets[selfonly], [0]);
    assert.deepEqual(view.targets[otheronly], [1, 2]);
    assert.equal(view.targets[basic], undefined);
});

test('an open prompt blocks other moves but not a neigh', () => {
    const e = engine();
    acting(e);
    for (let i = 0; i < 3; i++) give(e, 0, 'basic');
    const ask = give(e, 0, 'ask');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: ask }), { ok: true });
    assert.equal(e.state.prompt?.player, 0);

    const blocked = e.dispatch(0, { type: 'DRAW_ACTION' });
    assert.equal(blocked.ok, false);
    assert.match(blocked.ok ? '' : blocked.error, /open prompt/);
    assert.equal(e.state.phase, 'ACTION');

    const other = e.dispatch(1, { type: 'BEGIN_TURN' });
    assert.equal(other.ok, false);

    const prompt = e.state.prompt;
    assert.ok(prompt);

    const stale = e.dispatch(0, { type: 'RESPOND', promptId: 99, selection: [] });
    assert.equal(stale.ok, false);
    assert.match(stale.ok ? '' : stale.error, /out of date/);

    const foreign = e.dispatch(1, { type: 'RESPOND', promptId: prompt.id, selection: [e.state.players[0].hand[0]] });
    assert.equal(foreign.ok, false);
    assert.match(foreign.ok ? '' : foreign.error, /another player/);
    assert.equal(e.state.prompt?.id, prompt.id);

    assert.deepEqual(e.dispatch(0, { type: 'RESPOND', promptId: prompt.id, selection: [prompt.cards[0]] }), { ok: true });
    assert.equal(e.state.prompt, null);
});
