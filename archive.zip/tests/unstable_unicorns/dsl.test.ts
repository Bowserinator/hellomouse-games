import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard, resolveEffect } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { validateCard, validateRegistry } from '../../client/unstable_unicorns/js/engine/dsl/validate.js';
import { matches } from '../../client/unstable_unicorns/js/engine/dsl/filter.js';
import type { FilterCtx } from '../../client/unstable_unicorns/js/engine/dsl/filter.js';
import { holds } from '../../client/unstable_unicorns/js/engine/dsl/cond.js';
import type { CondCtx } from '../../client/unstable_unicorns/js/engine/dsl/cond.js';
import { seq, prim, sel, not } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';

const NO_CUSTOMS = new Set<string>();

function goodCard(): CardDef {
    return {
        id: 'test:draw2',
        kind: 'magic',
        onPlay: seq(
            prim({ p: 'draw', count: 2 }),
            { e: 'choice', options: [
                prim({ p: 'destroy', sel: sel('stable', 'any', 1) }),
                prim({ p: 'discard', sel: sel('hand', 'self', 1) })
            ] },
            { e: 'when', cond: { c: 'event', type: 'draw' }, effect: prim({ p: 'takeExtraTurn' }) }
        )
    };
}

function ctx(overrides: Partial<FilterCtx> = {}): FilterCtx {
    return {
        self: 0,
        active: 1,
        defOf: iid => iid === 'u1' ? { kind: 'basic', tags: ['t'], unicornType: 'basic' } : { kind: 'magic' },
        isUnicorn: () => true,
        ownerOf: iid => iid === 'u1' ? 0 : 1,
        ...overrides
    };
}

test('compile assigns stable ids and reuses them on recompile', () => {
    const first: NodeMap = {};
    const second: NodeMap = {};
    compileCard(goodCard(), first);
    compileCard(goodCard(), second);
    assert.deepEqual(Object.keys(first).sort(), Object.keys(second).sort());
    assert.ok(Object.keys(first).includes('test:draw2#onPlay'));
    assert.ok(Object.keys(first).includes('test:draw2#onPlay.1.0'));
    assert.equal(resolveEffect(first, 'test:draw2#onPlay').e, 'seq');
    assert.throws(() => resolveEffect(first, 'nope'), /Unknown effect node/);
});

test('validate accepts a well formed card', () => {
    assert.deepEqual(validateCard(goodCard(), NO_CUSTOMS), []);
});

test('validate rejects unknown node kinds', () => {
    const cases: Array<[string, Effect]> = [
        ['unknown effect', { e: 'bogus' } as unknown as Effect],
        ['unknown primitive', prim({ p: 'bogus' } as unknown as never)],
        ['unknown filter', prim({ p: 'destroy', sel: sel('stable', 'self', 1, { filter: { f: 'bogus' } as never }) })],
        ['unknown condition', { e: 'when', cond: { c: 'bogus' } as never, effect: prim({ p: 'takeExtraTurn' }) }],
        ['bad selector zone', prim({ p: 'destroy', sel: sel('bogus' as never, 'self', 1) })],
        ['bad count', prim({ p: 'draw', count: -1 })],
        ['empty choice', { e: 'choice', options: [] }],
        ['bad lingering expiry', prim({ p: 'addLingering', until: 'never' as never, effect: prim({ p: 'takeExtraTurn' }) })]
    ];
    for (const [label, effect] of cases) {
        const card: CardDef = { id: 'test:bad', kind: 'magic', onPlay: effect };
        assert.notDeepEqual(validateCard(card, NO_CUSTOMS), [], label);
    }
});

test('validate rejects unknown modifiers, triggers and replacements', () => {
    const modifier = validateCard({
        id: 'test:m', kind: 'upgrade',
        modifiers: [{ m: 'bogus' } as never]
    }, NO_CUSTOMS);
    assert.ok(modifier.some(issue => issue.includes('unknown modifier')));

    const trigger = validateCard({
        id: 'test:t', kind: 'basic',
        triggers: [{ on: 'bogus' as never, effect: prim({ p: 'draw', count: 1 }) }]
    }, NO_CUSTOMS);
    assert.ok(trigger.some(issue => issue.includes('unknown event')));

    const replacement = validateCard({
        id: 'test:r', kind: 'upgrade',
        replacements: [{ r: 'replace', when: 'bogus' as never, effect: prim({ p: 'takeExtraTurn' }) }]
    }, NO_CUSTOMS);
    assert.ok(replacement.some(issue => issue.includes('unknown event')));

    const instant = validateCard({ id: 'test:i', kind: 'magic', instant: {} as never }, NO_CUSTOMS);
    assert.ok(instant.some(issue => issue.includes('instant')));
});

test('validate rejects bindings used before they are defined', () => {
    const bad: CardDef = {
        id: 'test:bind', kind: 'magic',
        onPlay: seq(
            prim({ p: 'draw', count: { var: 'picked' } }),
            prim({ p: 'destroy', sel: sel('stable', 'self', 1, { as: 'picked' }) })
        )
    };
    assert.ok(validateCard(bad, NO_CUSTOMS).some(issue => issue.includes('used before')));

    const good: CardDef = {
        id: 'test:bind2', kind: 'magic',
        onPlay: seq(
            prim({ p: 'destroy', sel: sel('stable', 'self', 1, { as: 'picked' }) }),
            prim({ p: 'draw', count: { var: 'picked' } })
        )
    };
    assert.deepEqual(validateCard(good, NO_CUSTOMS), []);
});

test('validate rejects unknown custom handlers', () => {
    const card: CardDef = {
        id: 'test:custom', kind: 'magic',
        onPlay: prim({ p: 'custom', name: 'nope' })
    };
    assert.ok(validateCard(card, NO_CUSTOMS).some(issue => issue.includes('unknown custom handler')));
    assert.deepEqual(validateCard(card, new Set(['nope'])), []);
});

test('validateRegistry cross checks catalog and scripts', () => {
    const defs: Array<CardDef> = [{ id: 'a', kind: 'basic' }];
    assert.deepEqual(validateRegistry(defs, [{ id: 'a', name: 'A', kind: 'basic', text: '', copies: 1 }], NO_CUSTOMS), []);

    const missingScript = validateRegistry(defs, [{ id: 'b', name: 'B', kind: 'basic', text: '', copies: 1 }], NO_CUSTOMS);
    assert.equal(missingScript.length, 2);

    const duplicate = validateRegistry([...defs, ...defs], [{ id: 'a', name: 'A', kind: 'basic', text: '', copies: 1 }], NO_CUSTOMS);
    assert.ok(duplicate.some(issue => issue.includes('duplicate')));
});

test('filters match kind, tag, owner and combinators', () => {
    const c = ctx();
    assert.equal(matches({ f: 'type', type: 'basic' }, 'u1', c), true);
    assert.equal(matches({ f: 'tag', tag: 't' }, 'u1', c), true);
    assert.equal(matches({ f: 'tag', tag: 'x' }, 'u1', c), false);
    assert.equal(matches({ f: 'owner', owner: 'self' }, 'u1', c), true);
    assert.equal(matches({ f: 'owner', owner: 'other' }, 'u1', c), false);
    assert.equal(matches({ f: 'owner', owner: 'active' }, 'u1', c), false);
    assert.equal(matches(not({ f: 'type', type: 'basic' }), 'u1', c), false);
    assert.equal(matches({ f: 'and', all: [{ f: 'type', type: 'basic' }, { f: 'tag', tag: 't' }] }, 'u1', c), true);
    assert.equal(matches({ f: 'or', any: [{ f: 'type', type: 'magic' }, { f: 'tag', tag: 't' }] }, 'u1', c), true);
    assert.equal(matches({ f: 'or', any: [{ f: 'type', type: 'magic' }, { f: 'tag', tag: 'zz' }] }, 'u1', c), false);
    assert.equal(matches(undefined, 'anything', c), true);
});

test('unicorn filter asks the modifier layer, so pandas work', () => {
    const c = ctx({
        defOf: () => ({ kind: 'basic', unicornType: 'basic' }),
        isUnicorn: (iid, type) => iid === 'panda' && (type === undefined || type === 'panda')
    });
    assert.equal(matches({ f: 'unicorn', unicorn: 'panda' }, 'panda', c), true);
    assert.equal(matches({ f: 'unicorn', unicorn: 'basic' }, 'panda', c), false);
    assert.equal(matches({ f: 'unicorn' }, 'panda', c), true);
});

function condCtx(overrides: Partial<CondCtx> = {}): CondCtx {
    return {
        ...ctx(),
        source: 'u1',
        zoneOf: iid => iid === 'u1' ? 'stable' : null,
        countZone: (zone, owner) => zone === 'hand' && owner === 'self' ? 3 : 1,
        ...overrides
    };
}

test('conditions check events, counts and source placement', () => {
    const c = condCtx();
    assert.equal(holds({ c: 'event', type: 'draw' }, { ...c, event: { type: 'draw' } }), true);
    assert.equal(holds({ c: 'event', type: 'draw' }, c), false);
    assert.equal(holds({ c: 'count', zone: 'hand', owner: 'self', cmp: 'gte', n: 3 }, c), true);
    assert.equal(holds({ c: 'count', zone: 'hand', owner: 'self', cmp: 'gt', n: 3 }, c), false);
    assert.equal(holds({ c: 'count', zone: 'hand', owner: 'self', cmp: 'lt', n: 4 }, c), true);
    assert.equal(holds({ c: 'selfInStable' }, c), true);
    assert.equal(holds({ c: 'selfInStable' }, { ...c, zoneOf: () => 'hand' }), false);
    assert.equal(holds({ c: 'not', not: { c: 'selfInStable' } }, c), false);
    assert.equal(holds({ c: 'and', all: [{ c: 'selfInStable' }, { c: 'count', zone: 'hand', owner: 'self', cmp: 'eq', n: 3 }] }, c), true);
    assert.equal(holds({ c: 'or', any: [{ c: 'selfInStable' }, { c: 'event', type: 'play' }] }, c), true);
    assert.equal(holds(undefined, c), true);
});
