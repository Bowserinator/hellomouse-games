import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cardScene, registry } from './scenarios.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import { moveCtxOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';
import { worldOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { unicornCount } from '../../client/unstable_unicorns/js/engine/query/modifiers.js';
import { deckOutWinner } from '../../client/unstable_unicorns/js/engine/win.js';

test('Good Deal cannot pay its discard cost with its own resolving spell', () => {
    const { engine, add, act, answer } = cardScene();
    for (let i = 0; i < 8; i++) add('basic-unicorn-blue', 0, 'deck');
    const spell = add('good-deal');
    act({ type: 'PLAY_CARD', iid: spell });
    assert.equal(engine.state.cards[spell].zone, 'limbo');
    const prompt = engine.state.prompt;
    assert.ok(prompt);
    assert.equal(prompt.cards.length, 3);
    assert.ok(!prompt.cards.includes(spell));
    assert.equal(engine.dispatch(0, {
        type: 'RESPOND', promptId: prompt.id, selection: [spell]
    }).ok, false);
    answer([prompt.cards[0]]);
    assert.equal(engine.state.cards[spell].zone, 'discard');
    assert.equal(engine.state.players[0].hand.length, 2);
    assert.equal(engine.eventsSince(0).filter(event => event.type === 'draw').length, 3);
    assert.equal(engine.eventsSince(0).filter(event => event.type === 'discard' && event.card === spell).length, 1);
});

test('Back Kick makes the returned card owner discard after their Unicorn returns', () => {
    const { engine, add, act, answer } = cardScene();
    const backKick = add('back-kick');
    const returned = add('basic-unicorn-blue', 1, 'stable');
    const cost = add('basic-unicorn-blue', 1);
    act({ type: 'PLAY_CARD', iid: backKick });
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.cards[returned].zone, 'hand');
    assert.equal(engine.state.prompt?.player, 1);
    assert.deepEqual(new Set(engine.state.prompt?.cards), new Set([returned, cost]));
    answer([cost]);
    assert.equal(engine.state.cards[cost].zone, 'discard');
    assert.equal(engine.state.cards[returned].zone, 'hand');
});

test('Blatant Thievery lets its controller inspect and choose a card from another hand', () => {
    const { engine, add, act, answer } = cardScene();
    const thievery = add('blatant-thievery');
    const first = add('neigh', 1, 'hand');
    const second = add('super-neigh', 1, 'hand');
    act({ type: 'PLAY_CARD', iid: thievery });
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.prompt?.kind, 'cards');
    assert.deepEqual(new Set(engine.state.prompt?.cards), new Set([first, second]));
    answer([second]);
    assert.equal(engine.state.cards[second].owner, 0);
    assert.equal(engine.state.cards[second].zone, 'hand');
    assert.equal(engine.state.cards[first].owner, 1);
});

test('Annoying Flying Unicorn optionally makes the chosen player discard', () => {
    const { engine, add, act, answer } = cardScene();
    const annoying = add('annoying-flying-unicorn');
    const card = add('neigh', 1, 'hand');
    act({ type: 'PLAY_CARD', iid: annoying });
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.prompt?.player, 1);
    answer([card]);
    assert.equal(engine.state.cards[card].zone, 'discard');
});

test('Mermaid Unicorn optionally returns a card from the chosen Stable', () => {
    const { engine, add, act, answer } = cardScene();
    const mermaid = add('mermaid-unicorn');
    const returned = add('double-dutch', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: mermaid });
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.prompt?.kind, 'cards');
    answer([returned]);
    assert.equal(engine.state.cards[returned].zone, 'hand');
    assert.equal(engine.state.cards[returned].owner, 1);
});

test('Re-Target lets its controller choose another Stable for the card', () => {
    const { engine, add, act, answer } = cardScene();
    const retarget = add('re-target');
    const upgrade = add('double-dutch', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: retarget });
    assert.equal(engine.state.prompt?.kind, 'player');
    assert.deepEqual(engine.state.prompt?.players, [0, 2]);
    answer([2]);
    assert.equal(engine.state.cards[upgrade].owner, 2);
    assert.equal(engine.state.cards[upgrade].zone, 'stable');
});

test('Americorn lets its owner choose the player whose card is taken', () => {
    const { engine, add, act, answer } = cardScene();
    const americorn = add('americorn');
    const first = add('neigh', 1, 'hand');
    const second = add('super-neigh', 2, 'hand');
    act({ type: 'PLAY_CARD', iid: americorn });
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([2]);
    assert.equal(engine.state.cards[second].owner, 0);
    assert.equal(engine.state.cards[second].zone, 'hand');
    assert.equal(engine.state.cards[first].owner, 1);
});

test('Seductive Unicorn returns its stolen Unicorn when it leaves the Stable', () => {
    const { engine, add, act } = cardScene();
    const seductive = add('seductive-unicorn');
    const stolen = add('basic-unicorn-blue', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: seductive });
    assert.equal(engine.state.cards[stolen].owner, 0);
    moveCard(moveCtxOf(engine.ex), seductive, 'discard', 'destroy');
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[stolen].owner, 1);
    assert.equal(engine.state.cards[stolen].zone, 'stable');
});

test('Unicorn Lasso returns a stolen Unicorn at the end of the turn', () => {
    const { engine, add, answer } = cardScene();
    add('unicorn-lasso', 0, 'stable');
    const stolen = add('basic-unicorn-blue', 1, 'stable');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.cards[stolen].owner, 0);
    assert.equal(engine.state.cards[stolen].zone, 'stable');
    engine.dispatch(0, { type: 'END_TURN' });
    assert.equal(engine.state.cards[stolen].owner, 1);
    assert.equal(engine.state.cards[stolen].zone, 'stable');
});

test('Unicorn Shrinkray replaces the chosen players Unicorns without firing their effects', () => {
    const { engine, add, act, answer } = cardScene();
    const shrinkray = add('unicorn-shrinkray');
    const victim = add('basic-unicorn-blue', 1, 'stable');
    const baby = add('baby-unicorn-blue', 1, 'nursery');
    add('stabby-the-unicorn', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: shrinkray });
    assert.equal(engine.state.prompt?.kind, 'player');
    answer([1]);
    assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.cards[baby].zone, 'stable');
    assert.equal(engine.state.cards[baby].owner, 1);
    assert.equal(engine.state.prompt, null);
});

test('Neigh during a Magic cost prompt restores the hand and removes the pending effect', () => {
    const { engine, add, act } = cardScene();
    for (let i = 0; i < 8; i++) add('basic-unicorn-blue', 0, 'deck');
    const spell = add('good-deal');
    const neigh = add('neigh', 1);
    const beforeDeck = [...engine.state.deck];
    act({ type: 'PLAY_CARD', iid: spell });
    const top = engine.stack.top();
    assert.ok(top);
    act({ type: 'NEIGH', iid: neigh, targetEntryId: top.id }, 1);
    assert.equal(engine.state.prompt, null);
    assert.deepEqual(engine.state.players[0].hand, []);
    assert.deepEqual(engine.state.deck, beforeDeck);
    assert.deepEqual(engine.state.limbo, []);
    assert.equal(engine.state.cards[spell].zone, 'discard');
    assert.equal(engine.state.cards[neigh].zone, 'discard');
});

test('Neigh events distinguish Super Neigh from a normal Neigh', () => {
    for (const [defId, superNeigh] of [['neigh', false], ['super-neigh', true]] as const) {
        const { engine, add, act } = cardScene();
        const played = add('basic-unicorn-blue');
        const counter = add(defId, 1, 'hand');
        act({ type: 'PLAY_CARD', iid: played });
        const top = engine.stack.top();
        assert.ok(top);
        act({ type: 'NEIGH', iid: counter, targetEntryId: top.id }, 1);
        const event = engine.eventsSince(0).find(item => item.type === 'neigh');
        assert.equal(event?.superNeigh, superNeigh);
    }
});

test('Stable transfers emit departure for the old owner and entry for the new owner', () => {
    const { engine, add } = cardScene();
    const unicorn = add('basic-unicorn-blue', 1, 'stable');
    moveCard(moveCtxOf(engine.ex), unicorn, { zone: 'stable', owner: 0 }, 'play');
    const events = engine.eventsSince(0);
    assert.ok(events.some(event => event.type === 'leaveStable' && event.card === unicorn && event.player === 1));
    assert.ok(events.some(event => event.type === 'enterStable' && event.card === unicorn && event.player === 0));
});

test('Entry triggers only activate for their source and resolve once', () => {
    const { engine, add, act } = cardScene();
    for (let i = 0; i < 8; i++) add('basic-unicorn-blue', 0, 'deck');
    add('greedy-flying-unicorn', 1, 'stable');
    const ownGreedy = add('greedy-flying-unicorn');
    act({ type: 'PLAY_CARD', iid: ownGreedy });
    assert.equal(engine.state.players[0].hand.length, 1);
    assert.equal(engine.state.players[1].hand.length, 0);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.eventsSince(0).filter(event => event.type === 'draw').length, 1);
});

test('Beginning-of-turn abilities only trigger for the owner', () => {
    const { engine, add } = cardScene();
    for (let i = 0; i < 8; i++) add('basic-unicorn-blue', 0, 'deck');
    add('extra-tail', 0, 'stable');
    engine.ex.log.emit({ type: 'turnStart', player: 1 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.players[0].hand.length, 0);
    assert.equal(engine.state.prompt, null);
});

test('Barbed Wire resolves a separate discard for every Unicorn entry', () => {
    const { engine, add, answer } = cardScene();
    add('barbed-wire', 0, 'stable');
    for (let i = 0; i < 4; i++) add('basic-unicorn-blue');
    const first = add('basic-unicorn-blue', 1);
    const second = add('basic-unicorn-blue', 1);
    moveCard(moveCtxOf(engine.ex), first, { zone: 'stable', owner: 0 }, 'play');
    moveCard(moveCtxOf(engine.ex), second, { zone: 'stable', owner: 0 }, 'play');
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.player, 0);
    answer([engine.state.prompt!.cards[0]]);
    assert.equal(engine.state.prompt?.player, 0);
    answer([engine.state.prompt!.cards[0]]);
    assert.equal(engine.state.players[0].hand.length, 2);
    assert.equal(engine.state.prompt, null);
});

test('Barbed Wire ignores Upgrade entry and other players Unicorns', () => {
    const { engine, add } = cardScene();
    add('barbed-wire', 0, 'stable');
    add('basic-unicorn-blue');
    const upgrade = add('rainbow-aura');
    const otherUnicorn = add('basic-unicorn-blue', 1);
    moveCard(moveCtxOf(engine.ex), upgrade, { zone: 'stable', owner: 0 }, 'play');
    moveCard(moveCtxOf(engine.ex), otherUnicorn, { zone: 'stable', owner: 1 }, 'play');
    resolveLinks(engine.ex);
    assert.equal(engine.state.players[0].hand.length, 1);
    assert.equal(engine.state.prompt, null);
});

test('Stabby can activate its own destruction ability after leaving the Stable', () => {
    const { engine, add, answer } = cardScene();
    const stabby = add('stabby-the-unicorn', 0, 'stable');
    const victim = add('basic-unicorn-blue', 1, 'stable');
    moveCard(moveCtxOf(engine.ex), stabby, 'discard', 'destroy');
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.cards[victim].zone, 'discard');
});

test('Flying return replacements affect only their source', () => {
    const { engine, add } = cardScene();
    const flying = add('greedy-flying-unicorn', 0, 'stable');
    const victim = add('basic-unicorn-blue', 1, 'stable');
    moveCard(moveCtxOf(engine.ex), victim, 'discard', 'destroy');
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.cards[flying].zone, 'stable');
    moveCard(moveCtxOf(engine.ex), flying, 'discard', 'sacrifice');
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[flying].zone, 'hand');
    assert.equal(engine.state.cards[flying].owner, 0);
});

for (const accept of [true, false])
    test(`Black Knight sacrifices itself only when its owner accepts: ${accept}`, () => {
        const { engine, add, answer } = cardScene();
        const knight = add('black-knight-unicorn', 0, 'stable');
        const victim = add('basic-unicorn-blue', 0, 'stable');
        moveCard(moveCtxOf(engine.ex), victim, 'discard', 'destroy');
        resolveLinks(engine.ex);
        assert.equal(engine.state.prompt?.player, 0);
        assert.equal(engine.state.prompt?.kind, 'yesno');
        answer(accept);
        assert.equal(engine.state.cards[knight].zone, accept ? 'discard' : 'stable');
        assert.equal(engine.state.cards[victim].zone, accept ? 'stable' : 'discard');
        assert.equal(engine.state.prompt, null);
    });

test('Black Knight does not intercept another players destruction', () => {
    const { engine, add } = cardScene();
    const knight = add('black-knight-unicorn', 0, 'stable');
    const victim = add('basic-unicorn-blue', 1, 'stable');
    moveCard(moveCtxOf(engine.ex), victim, 'discard', 'destroy');
    resolveLinks(engine.ex);
    assert.equal(engine.state.cards[knight].zone, 'stable');
    assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.prompt, null);
});

test('Double Dutch grants a second play only when present at turn start', () => {
    const { engine, add, act } = cardScene();
    const dutch = add('double-dutch', 0, 'stable');
    const first = add('basic-unicorn-blue');
    const second = add('basic-unicorn-green');
    const third = add('basic-unicorn-orange');
    add('basic-unicorn-indigo', 0, 'deck');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    act({ type: 'PLAY_CARD', iid: first });
    act({ type: 'PLAY_CARD', iid: second });
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: third }).ok, false);
    moveCard(moveCtxOf(engine.ex), dutch, 'discard', 'discard');
    engine.state.phase = 'AWAIT_BEGIN';
    engine.state.turn.player = 0;
    act({ type: 'BEGIN_TURN' });
    assert.equal(engine.state.turn.bonusPlays, 0);
});

test('Double Dutch cannot turn a draw into a second card action', () => {
    const { engine, add, act } = cardScene();
    add('double-dutch', 0, 'stable');
    add('basic-unicorn-blue', 0, 'deck');
    add('basic-unicorn-green', 0, 'deck');
    const card = add('basic-unicorn-blue');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    act({ type: 'DRAW_ACTION' });
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: card }).ok, false);
    assert.equal(engine.dispatch(0, { type: 'DRAW_ACTION' }).ok, false);
});

test('Yay protects Basic, Magical Unicorn, and Magic plays without blocking their effects', () => {
    for (const defId of ['basic-unicorn-blue', 'greedy-flying-unicorn', 'good-deal']) {
        const { engine, add, act, answer } = cardScene();
        const yay = add('yay');
        for (let i = 0; i < 8; i++) add('basic-unicorn-blue', 0, 'deck');
        const card = add(defId);
        const neigh = add('neigh', 1);
        act({ type: 'PLAY_CARD', iid: yay });
        for (let turn = 0; turn < 3; turn++) {
            act({ type: 'END_TURN' });
            act({ type: 'BEGIN_TURN' });
        }
        const before = engine.view(0);
        assert.ok(before.playable.includes(card));
        assert.equal(before.blockers[card], undefined);
        assert.equal(before.futile[card], undefined);
        const handSize = engine.state.players[0].hand.length;
        act({ type: 'PLAY_CARD', iid: card });
        const top = engine.stack.top();
        assert.ok(top?.immune);
        if (defId === 'greedy-flying-unicorn') {
            assert.equal(engine.state.players[0].hand.length, handSize);
            assert.equal(engine.state.prompt, null);
        }
        if (defId === 'good-deal') {
            assert.equal(engine.state.prompt?.kind, 'cards');
            answer([engine.state.prompt!.cards[0]]);
            assert.equal(engine.state.players[0].hand.length, handSize + 1);
        }
        assert.equal(engine.view(1).chain.canNeigh, false);
        assert.equal(engine.dispatch(1, { type: 'NEIGH', iid: neigh, targetEntryId: top.id }).ok, false);
    }
});

test('Yay leaves every otherwise legal Magic card playable', () => {
    const { engine, add } = cardScene();
    for (let i = 0; i < 20; i++) add('basic-unicorn-blue', 0, 'deck');
    for (const player of engine.state.players) {
        add('basic-unicorn-blue', player.id, 'stable');
        if (player.id !== 0) add('neigh', player.id);
    }
    add('double-dutch', 0, 'stable');
    Object.values(registry.byId).filter(def => def.kind === 'baby').slice(0, 3)
        .forEach(def => add(def.id, -1, 'nursery'));
    const spells = Object.values(registry.byId).filter(def => def.kind === 'magic')
        .map(def => add(def.id));
    const before = engine.view(0);
    add('yay', 0, 'stable');
    const after = engine.view(0);
    for (const iid of spells) {
        const name = engine.state.cards[iid].defId;
        assert.ok(before.playable.includes(iid), `Magic blocked without Yay: ${name}: ${before.blockers[iid]}`);
        assert.ok(after.playable.includes(iid), `Yay blocks ${name}: ${after.blockers[iid]}`);
        assert.equal(after.futile[iid], before.futile[iid], `Yay changes the effect warning for ${name}`);
    }
});

test('Targeted Destruction can use its last choice without a sacrificial Upgrade', () => {
    const { engine, add, act, answer } = cardScene();
    const target = add('double-dutch', 1, 'stable');
    const spell = add('targeted-destruction');
    const before = engine.view(0);
    assert.ok(before.playable.includes(spell), before.blockers[spell]);
    act({ type: 'PLAY_CARD', iid: spell });
    assert.equal(engine.state.prompt?.kind, 'option');
    answer(1);
    assert.equal(engine.state.cards[target].zone, 'discard');
    assert.equal(engine.state.cards[spell].zone, 'discard');
});

test('Confirmed Magical Unicorns enter and remain in the Stable', () => {
    const { engine, add, act, answer } = cardScene();
    add('basic-unicorn-blue', 0, 'stable');
    const torpedo = add('narwhal-torpedo');
    act({ type: 'PLAY_CARD', iid: torpedo });
    assert.equal(engine.state.cards[torpedo].zone, 'stable');
    engine.state.turn.actionsUsed = 0;
    const cob = add('unicorn-on-the-cob');
    for (let i = 0; i < 3; i++) add('basic-unicorn-blue', 0, 'deck');
    act({ type: 'PLAY_CARD', iid: cob });
    assert.equal(engine.state.cards[cob].zone, 'stable');
    answer([engine.state.prompt!.cards[0]]);
});

for (const downgrade of Object.values(registry.byId).filter(def => def.kind === 'downgrade')) {
    test(`Narwhal Torpedo resolves against ${downgrade.id}`, () => {
        const { engine, add, act, answer } = cardScene();
        add('basic-unicorn-blue', 0, 'stable');
        const target = add(downgrade.id, 0, 'stable');
        add('neigh');
        add('neigh');
        const torpedo = add('narwhal-torpedo');
        assert.ok(engine.view(0).playable.includes(torpedo));
        act({ type: 'PLAY_CARD', iid: torpedo });
        if (downgrade.id === 'barbed-wire') {
            assert.equal(engine.state.prompt?.source, target);
            assert.equal(engine.state.prompt?.kind, 'cards');
            answer([engine.state.prompt!.cards[0]]);
        }
        assert.equal(engine.state.prompt, null);
        assert.equal(engine.state.cards[torpedo].zone, 'stable');
        assert.equal(engine.state.cards[target].zone,
            downgrade.id === 'blinding-light' ? 'stable' : 'discard');
    });
}

test('Narwhal Torpedo continues after Barbed Wire and Tiny Stable choices', () => {
    const { engine, add, act, answer } = cardScene();
    const basics = Array.from({ length: 5 }, () => add('basic-unicorn-blue', 0, 'stable'));
    const downgrades = Object.values(registry.byId)
        .filter(def => def.kind === 'downgrade' && def.id !== 'blinding-light' && def.id !== 'pandamonium')
        .map(def => add(def.id, 0, 'stable'));
    const upgrade = add('yay', 0, 'stable');
    const opposing = add('broken-stable', 1, 'stable');
    add('neigh');
    add('neigh');
    const torpedo = add('narwhal-torpedo');
    act({ type: 'PLAY_CARD', iid: torpedo });
    let answers = 0;
    for (; engine.state.prompt && answers < 4; answers++) {
        const prompt = engine.state.prompt;
        const source = engine.state.cards[prompt.source!].defId;
        assert.ok(source === 'barbed-wire' || source === 'tiny-stable', source);
        const chosen = source === 'tiny-stable'
            ? prompt.cards.find(iid => basics.includes(iid))!
            : prompt.cards[0];
        answer([chosen]);
    }
    assert.ok(answers >= 2, 'Expected both entry-trigger choices');
    assert.equal(engine.state.prompt, null);
    for (const iid of downgrades) assert.equal(engine.state.cards[iid].zone, 'discard');
    assert.equal(engine.state.cards[torpedo].zone, 'stable');
    assert.equal(engine.state.cards[upgrade].zone, 'stable');
    assert.equal(engine.state.cards[opposing].zone, 'stable');
});

test('Tiny Stable asks its owner to sacrifice when a sixth non-Panda Unicorn enters', () => {
    const { engine, add, act, answer } = cardScene();
    add('tiny-stable', 0, 'stable');
    for (let i = 0; i < 5; i++) add('basic-unicorn-blue', 0, 'stable');
    const sixth = add('basic-unicorn-green');
    act({ type: 'PLAY_CARD', iid: sixth });
    assert.equal(engine.state.prompt?.kind, 'cards');
    assert.equal(engine.state.prompt?.player, 0);
    assert.equal(engine.state.prompt?.cards.length, 6);
    answer([engine.state.prompt!.cards[0]]);
});

test('Tiny Stable does not count Pandas', () => {
    const { engine, add, act } = cardScene();
    add('tiny-stable', 0, 'stable');
    add('pandamonium', 0, 'stable');
    for (let i = 0; i < 6; i++) add('basic-unicorn-blue', 0, 'stable');
    const panda = add('basic-unicorn-green');
    act({ type: 'PLAY_CARD', iid: panda });
    assert.equal(engine.state.prompt, null);
});

test('Two-for-one permits one own sacrifice and two opposing targets', () => {
    const { add, act } = cardScene();
    add('basic-unicorn-blue', 0, 'stable');
    add('basic-unicorn-green', 1, 'stable');
    add('basic-unicorn-orange', 1, 'stable');
    const card = add('two-for-one');
    act({ type: 'PLAY_CARD', iid: card });
});

test('Rainbow Mane and Extra Tail require a plain Basic Unicorn', () => {
    const { engine, add } = cardScene();
    const mane = add('rainbow-mane');
    const tail = add('extra-tail');
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: mane }).ok, false);
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: tail }).ok, false);
    add('basic-unicorn-blue', 0, 'stable');
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: mane }).ok, true);
});

test('Stable-entry restrictions apply to effect-driven moves', () => {
    const { engine, add } = cardScene();
    const tail = add('extra-tail');
    assert.equal(moveCard(moveCtxOf(engine.ex), tail, { zone: 'stable', owner: 0 }, 'play').moved, false);
    add('queen-bee-unicorn', 1, 'stable');
    const basic = add('basic-unicorn-blue');
    assert.equal(moveCard(moveCtxOf(engine.ex), basic, { zone: 'stable', owner: 0 }, 'play').moved, false);
    const special = add('narwhal-torpedo');
    assert.equal(moveCard(moveCtxOf(engine.ex), special, { zone: 'stable', owner: 1 }, 'play').moved, true);
});

test('An unsuccessful card search still shuffles the deck', () => {
    const { engine, add, act, answer } = cardScene();
    for (let i = 0; i < 3; i++) add('basic-unicorn-blue', 0, 'deck');
    const classy = add('classy-narwhal');
    const rngBefore = engine.ex.rng.s;
    act({ type: 'PLAY_CARD', iid: classy });
    answer(true);
    assert.notEqual(engine.ex.rng.s, rngBefore);
});

test('All optional searches shuffle only after an attempted search', () => {
    for (const id of ['classy-narwhal', 'shabby-the-narwhal', 'the-great-narwhal']) {
        const accepted = cardScene();
        for (let i = 0; i < 3; i++) accepted.add('basic-unicorn-blue', 0, 'deck');
        const card = accepted.add(id);
        accepted.act({ type: 'PLAY_CARD', iid: card });
        const acceptedRng = accepted.engine.ex.rng.s;
        accepted.answer(true);
        assert.notEqual(accepted.engine.ex.rng.s, acceptedRng, `${id} did not shuffle after a no-match search`);

        const declined = cardScene();
        for (let i = 0; i < 3; i++) declined.add('basic-unicorn-blue', 0, 'deck');
        const declinedCard = declined.add(id);
        declined.act({ type: 'PLAY_CARD', iid: declinedCard });
        const declinedRng = declined.engine.ex.rng.s;
        declined.answer(false);
        assert.equal(declined.engine.ex.rng.s, declinedRng, `${id} shuffled after a declined search`);
    }
});

test('Pandamonium removes affected Unicorns from counts and Unicorn targeting', () => {
    const { engine, add } = cardScene(2);
    add('pandamonium', 0, 'stable');
    const panda = add('ginormous-unicorn', 0, 'stable');
    const normal = add('basic-unicorn-blue', 1, 'stable');
    assert.equal(unicornCount(worldOf(engine.ex), 0), 0);
    assert.equal(unicornCount(worldOf(engine.ex), 1), 1);
    assert.equal(deckOutWinner(worldOf(engine.ex), id => id).winner, 1);
    const poison = add('unicorn-poison');
    const result = engine.dispatch(0, { type: 'PLAY_CARD', iid: poison });
    assert.equal(result.ok, true);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.cards[panda].zone, 'stable');
    assert.equal(engine.state.cards[normal].zone, 'discard');
});

test('Tiny Stable ignores six Pandas under Pandamonium', () => {
    const { engine, add } = cardScene();
    add('tiny-stable', 0, 'stable');
    add('pandamonium', 0, 'stable');
    const pandas = Array.from({ length: 6 }, () => add('basic-unicorn-blue', 0, 'stable'));
    const extra = add('basic-unicorn-blue');
    moveCard(moveCtxOf(engine.ex), extra, { zone: 'stable', owner: 0 }, 'play');
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.players[0].stable.filter(iid => pandas.includes(iid)).length, 6);
    assert.equal(unicornCount(worldOf(engine.ex), 0), 0);
});

test('Summoning Ritual puts its selected discard Unicorn directly into its owners Stable', () => {
    const { engine, add, answer } = cardScene();
    add('summoning-ritual', 0, 'stable');
    add('basic-unicorn-blue');
    add('basic-unicorn-green');
    const summoned = add('basic-unicorn-orange', 0, 'discard');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.prompt?.kind, 'cards');
    answer([summoned]);
    assert.ok(engine.state.players[0].stable.includes(summoned));
    assert.equal(engine.state.cards[summoned].zone, 'stable');
});

test('Glitter Tornado returns one card from every players Stable', () => {
    const { engine, add, act } = cardScene();
    const mine = add('basic-unicorn-blue', 0, 'stable');
    const theirs = add('basic-unicorn-green', 1, 'stable');
    const tornado = add('glitter-tornado');
    act({ type: 'PLAY_CARD', iid: tornado });
    assert.ok(engine.state.players[0].hand.includes(mine));
    assert.ok(engine.state.players[1].hand.includes(theirs));
});

test('Shake Up shuffles its source, hand, and discard before drawing five cards', () => {
    const { engine, add, act } = cardScene();
    const oldHand = add('basic-unicorn-blue');
    const oldDiscard = add('basic-unicorn-green', 0, 'discard');
    const shake = add('shake-up');
    for (let i = 0; i < 6; i++) add('basic-unicorn-orange', 0, 'deck');
    act({ type: 'PLAY_CARD', iid: shake });
    assert.equal(engine.state.players[0].hand.length, 5);
    assert.equal(engine.state.discard.length, 0);
    assert.equal(engine.state.limbo.length, 0);
    for (const iid of [oldHand, oldDiscard, shake])
        assert.ok(engine.state.players[0].hand.includes(iid) || engine.state.deck.includes(iid));
});

test('Puppicorn cannot be destroyed or sacrificed', () => {
    const { engine, add } = cardScene();
    const puppicorn = add('puppicorn', 0, 'stable');
    assert.equal(moveCard(moveCtxOf(engine.ex), puppicorn, 'discard', 'destroy').shielded, true);
    assert.equal(moveCard(moveCtxOf(engine.ex), puppicorn, 'discard', 'sacrifice').shielded, true);
    assert.equal(engine.state.cards[puppicorn].zone, 'stable');
});

test('Destroy prompts exclude protected Unicorns', () => {
    const { engine, add, act } = cardScene();
    add('rainbow-aura', 1, 'stable');
    const protectedUnicorn = add('basic-unicorn-blue', 1, 'stable');
    const first = add('basic-unicorn-blue', 2, 'stable');
    const second = add('basic-unicorn-blue', 2, 'stable');
    const poison = add('unicorn-poison');
    act({ type: 'PLAY_CARD', iid: poison });
    assert.ok(engine.state.prompt);
    assert.deepEqual(engine.state.prompt.cards, [first, second]);
    assert.ok(!engine.state.prompt.cards.includes(protectedUnicorn));
});

test('Glitter Bomb optionally sacrifices a card before destroying any card', () => {
    const { engine, add, answer } = cardScene();
    add('glitter-bomb', 0, 'stable');
    const sacrifice = add('basic-unicorn-blue', 0, 'stable');
    const victim = add('rainbow-aura', 1, 'stable');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.ok(engine.state.prompt?.cards.includes(sacrifice));
    answer([sacrifice]);
    assert.ok(engine.state.prompt?.cards.includes(victim));
    answer([victim]);
    assert.equal(engine.state.cards[sacrifice].zone, 'discard');
    assert.equal(engine.state.cards[victim].zone, 'discard');
});

test('Shark With A Horn sacrifices its own card before destroying a Unicorn', () => {
    const { engine, add, act, answer } = cardScene();
    const shark = add('shark-with-a-horn');
    const other = add('basic-unicorn-blue', 0, 'stable');
    const victim = add('basic-unicorn-green', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: shark });
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.cards[shark].zone, 'discard');
    assert.ok(engine.state.prompt?.cards.includes(victim));
    answer([victim]);
    assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.cards[other].zone, 'stable');
});

test('Rhinocorn does not skip the turn when destruction is replaced', () => {
    const { engine, add, answer } = cardScene();
    add('rhinocorn', 0, 'stable');
    const flying = add('annoying-flying-unicorn', 1, 'stable');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    answer([flying]);
    assert.equal(engine.state.cards[flying].zone, 'hand');
    assert.equal(engine.state.turn.endNow, false);
});

test('Rhinocorn decline leaves the turn in its normal action phase', () => {
    const { engine, add, answer } = cardScene();
    add('rhinocorn', 0, 'stable');
    add('basic-unicorn-blue', 1, 'stable');
    engine.ex.log.emit({ type: 'turnStart', player: 0 });
    resolveLinks(engine.ex);
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(false);
    assert.equal(engine.state.turn.endNow, false);
    assert.equal(engine.state.phase, 'ACTION');
});

test('Unicorn Swap exchanges the selected Unicorns between their Stables', () => {
    const { engine, add, act } = cardScene();
    const mine = add('basic-unicorn-blue', 0, 'stable');
    const theirs = add('basic-unicorn-green', 1, 'stable');
    const swap = add('unicorn-swap');
    act({ type: 'PLAY_CARD', iid: swap });
    assert.equal(engine.state.cards[mine].owner, 1);
    assert.equal(engine.state.cards[theirs].owner, 0);
});

test('Mystical Vortex discards each players card before shuffling the discard', () => {
    const { engine, add, act } = cardScene();
    const own = add('neigh', 0, 'hand');
    const other = add('super-neigh', 1, 'hand');
    const vortex = add('mystical-vortex');
    act({ type: 'PLAY_CARD', iid: vortex });
    assert.ok(engine.state.deck.includes(own));
    assert.ok(engine.state.deck.includes(other));
    assert.equal(engine.state.cards[vortex].zone, 'discard');
});

for (const caster of [0, 1, 2]) {
    test(`Reset Button clears every Stable with Yay active for seat ${caster}`, () => {
        const { engine, add, act } = cardScene();
        engine.state.turn.player = caster;
        const unicorns = engine.state.players.map(player => [
            add('baby-unicorn-blue', player.id, 'stable'),
            add('basic-unicorn-blue', player.id, 'stable')
        ]);
        const removed = engine.state.players.map(player => add('double-dutch', player.id, 'stable'));
        removed.push(add('yay', caster, 'stable'));
        Object.values(registry.byId).filter(def => def.kind === 'downgrade').forEach((def, index) => {
            removed.push(add(def.id, (index + caster) % 3, 'stable'));
        });
        const reset = add('reset-button', caster);
        const before = engine.view(caster);
        assert.ok(before.playable.includes(reset));
        assert.equal(before.blockers[reset], undefined);
        assert.equal(before.futile[reset], undefined);
        act({ type: 'PLAY_CARD', iid: reset });
        assert.equal(engine.state.prompt, null);
        for (const iid of removed) {
            assert.equal(engine.state.cards[iid].zone, 'deck', registry.names[engine.state.cards[iid].defId]);
            assert.ok(engine.state.deck.includes(iid));
        }
        for (const player of engine.state.players)
            assert.deepEqual(player.stable, unicorns[player.id]);
        assert.equal(engine.state.cards[reset].zone, 'discard');
    });
}

test('Unicorn on the Cob cannot discard its resolving card as a cost', () => {
    const { engine, add, act, answer } = cardScene();
    add('basic-unicorn-blue', 0, 'deck');
    add('basic-unicorn-green', 0, 'deck');
    const cob = add('unicorn-on-the-cob');
    act({ type: 'PLAY_CARD', iid: cob });
    assert.equal(engine.state.prompt?.kind, 'cards');
    assert.ok(!engine.state.prompt.cards.includes(cob));
    answer([engine.state.prompt.cards[0]]);
    assert.equal(engine.state.cards[cob].zone, 'stable');
});
