import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, CatalogEntry } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { buildRegistry } from '../../client/unstable_unicorns/js/engine/registry.js';
import { Engine } from '../../client/unstable_unicorns/js/engine/engine.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';
import { prim, sel, seq } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';
import { createCard } from '../../client/unstable_unicorns/js/engine/state.js';

const entry = (id: string, copies: number, kind: CatalogEntry['kind']): CatalogEntry => ({
    id,
    kind,
    name: id,
    text: id,
    copies
});

const catalog: Array<CatalogEntry> = [
    entry('baby', 3, 'baby'),
    entry('basic', 12, 'basic'),
    entry('spell', 6, 'magic')
];

const defs: Array<CardDef> = [
    { id: 'baby', kind: 'baby' },
    { id: 'basic', kind: 'basic' },
    { id: 'spell', kind: 'magic', onPlay: prim({ p: 'draw', count: 1 }) }
];

function engine(playerCount = 3): Engine {
    return new Engine({
        registry: buildRegistry(catalog, defs, new Set()),
        playerCount,
        seed: 'engine'
    });
}

function seats(e: Engine) {
    for (let seat = 0; seat < e.state.players.length; seat++) {
        const baby = e.state.nursery.find(iid => e.defOf(iid)?.kind === 'baby') as string;
        assert.deepEqual(e.dispatch(seat, { type: 'PICK_BABY', iid: baby }), { ok: true });
    }
}

test('setup deals an opening hand and leaves the babies in the nursery', () => {
    const e = engine();
    assert.equal(e.state.phase, 'PICK_BABY');
    for (const player of e.state.players) assert.equal(player.hand.length, 5);
    assert.equal(e.state.nursery.length, 3);
    assert.equal(e.state.deck.length, 18 - 15);
    assertInvariant(e.state);
});

test('the same seed deals the same hands', () => {
    const many: Array<CatalogEntry> = [];
    for (let i = 0; i < 21; i++) many.push(entry(`k${i}`, 1, 'basic'));
    const plain = many.map(item => ({ id: item.id, kind: 'basic' as const }));
    const order = (seed: string): string => {
        const table = new Engine({
            registry: buildRegistry(many, plain, new Set()),
            playerCount: 3,
            seed
        });
        return JSON.stringify(table.state.deck.map(iid => table.state.cards[iid].defId));
    };

    assert.equal(order('engine'), order('engine'));
    assert.notEqual(order('engine'), order('other'));
});

test('a baby pick takes the card from the nursery and starts the game', () => {
    const e = engine();
    seats(e);
    assert.equal(e.state.phase, 'AWAIT_BEGIN');
    for (const player of e.state.players) {
        assert.equal(player.stable.length, 1);
        assert.equal(e.defOf(player.stable[0])?.kind, 'baby');
        assert.equal(player.babyChosen, true);
    }
    assertInvariant(e.state);
});

test('a second baby pick is refused', () => {
    const e = engine();
    const baby = e.state.nursery[0];
    assert.deepEqual(e.dispatch(0, { type: 'PICK_BABY', iid: baby }), { ok: true });
    const other = e.state.nursery[0];
    const result = e.dispatch(0, { type: 'PICK_BABY', iid: other });
    assert.equal(result.ok, false);
});

test('malformed actions never throw', () => {
    const e = engine();
    assert.equal(e.dispatch(0, null).ok, false);
    assert.equal(e.dispatch(0, {}).ok, false);
    assert.equal(e.dispatch(0, { type: 'NOPE' }).ok, false);
    assert.equal(e.dispatch(0, { type: 'PICK_BABY' }).ok, false);
    assert.equal(e.dispatch(0, { type: 'PICK_BABY', iid: 7 }).ok, false);
    assert.equal(e.dispatch(9, { type: 'BEGIN_TURN' }).ok, false);
    assert.equal(e.dispatch(0, { type: 'RESPOND', promptId: 1 }).ok, false);
    assert.equal(e.dispatch(0, { type: 'RESPOND', promptId: 1, selection: 'x' }).ok, false);
    assert.equal(e.dispatch(0, { type: 'NEIGH', iid: 'c1' }).ok, false);
});

test('a turn begins only in the right phase and by the right seat', () => {
    const e = engine();
    assert.equal(e.dispatch(0, { type: 'BEGIN_TURN' }).ok, false);
    seats(e);

    assert.equal(e.dispatch(1, { type: 'BEGIN_TURN' }).ok, false);
    const before = e.state.players[0].hand.length;
    assert.deepEqual(e.dispatch(0, { type: 'BEGIN_TURN' }), { ok: true });
    assert.equal(e.state.phase, 'ACTION');
    assert.equal(e.state.players[0].hand.length, before + 1);
    assert.deepEqual(e.dispatch(0, { type: 'DRAW_ACTION' }), { ok: true });
    assert.equal(e.state.players[0].hand.length, before + 2);
    assertInvariant(e.state);
});

test('an unplayable card is refused and a unicorn reaches the stable', () => {
    const e = engine();
    seats(e);
    e.dispatch(0, { type: 'BEGIN_TURN' });

    const hand = e.state.players[0].hand;
    const unicorn = hand.find(iid => e.defOf(iid)?.kind === 'basic') as string;
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: unicorn }), { ok: true });
    assert.deepEqual(e.state.players[0].stable.includes(unicorn), true);

    const foreign = e.state.players[1].hand[0];
    assert.equal(e.dispatch(0, { type: 'PLAY_CARD', iid: foreign }).ok, false);
    assertInvariant(e.state);
});

test('a spell resolves and lands in the discard pile', () => {
    const e = engine();
    seats(e);
    e.dispatch(0, { type: 'BEGIN_TURN' });

    const spell = e.state.players[0].hand.find(iid => e.defOf(iid)?.kind === 'magic') as string;
    const before = e.state.players[0].hand.length;
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: spell }), { ok: true });
    assert.equal(e.state.discard.includes(spell), true);
    assert.equal(e.state.players[0].hand.length, before - 1 + 1);
    assertInvariant(e.state);
});

test('ending the turn hands play to the next seat', () => {
    const e = engine();
    seats(e);
    e.dispatch(0, { type: 'BEGIN_TURN' });
    assert.deepEqual(e.dispatch(0, { type: 'END_TURN' }), { ok: true });
    assert.equal(e.state.turn.player, 1);
    assert.equal(e.state.phase, 'AWAIT_BEGIN');
    assert.equal(e.dispatch(1, { type: 'BEGIN_TURN' }).ok, true);
    assertInvariant(e.state);
});

test('the view shows the own hand and counts for the rest', () => {
    const e = engine();
    seats(e);
    const view = e.view(0);
    assert.deepEqual(view.players[0].hand, e.state.players[0].hand);
    assert.equal(view.players[1].hand, null);
    assert.equal(view.players[1].handCount, e.state.players[1].hand.length);
    assert.equal(view.phase, 'AWAIT_BEGIN');
    assert.deepEqual(view.waitingOn, [0]);
    const json = JSON.stringify(view);
    for (const iid of e.state.players[1].hand) {
        const defId = e.state.cards[iid].defId;
        assert.equal(json.includes(`"c${iid.slice(1)}"`) && defId === 'baby', defId === 'baby');
    }
});

test('the event log keeps its sequence numbers', () => {
    const e = engine();
    seats(e);
    e.dispatch(0, { type: 'BEGIN_TURN' });
    const all = e.eventsSince(0);
    assert.ok(all.length > 0);
    assert.deepEqual(e.eventsSince(all[all.length - 1].seq), []);
    assert.equal(all[0].seq, 1);
});

test('playability does not depend on hidden hand contents', () => {
    const e = engine();
    seats(e);
    e.dispatch(0, { type: 'BEGIN_TURN' });
    const before = e.playable(0);

    for (const iid of e.state.players[1].hand) e.state.cards[iid].defId = 'spell';
    assert.deepEqual(e.playable(0), before);

    for (const iid of e.state.players[2].hand) e.state.cards[iid].defId = 'baby';
    assert.deepEqual(e.playable(0), before);
});

test('the view flags playable cards that would have no effect', () => {
    const e = new Engine({
        registry: buildRegistry(
            [...catalog, entry('recycle', 6, 'magic')],
            [...defs, { id: 'recycle', kind: 'magic', onPlay: prim({ p: 'fetchFromDiscard', count: 1 }) }],
            new Set()
        ),
        playerCount: 3,
        seed: 'engine'
    });
    seats(e);
    createCard(e.state, 'r0', 'recycle', 0, 'hand');
    assert.deepEqual(e.dispatch(0, { type: 'BEGIN_TURN' }), { ok: true });

    assert.equal(e.view(0).playable.includes('r0'), true);
    assert.equal(e.view(0).futile['r0'], true);
    assert.equal(e.view(0).blockers['r0'], undefined);

    createCard(e.state, 'd0', 'spell', 0, 'discard');
    assert.equal('r0' in e.view(0).futile, false);

    const before = e.state.players[0].hand.length;
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'r0' }), { ok: true });
    const prompt = e.state.prompt;
    assert.ok(prompt);
    assert.deepEqual(e.dispatch(0, { type: 'RESPOND', promptId: prompt.id, selection: [prompt.cards[0]] }), { ok: true });
    assert.equal(e.state.players[0].hand.includes('d0'), true);
    assert.equal(e.state.players[0].hand.length, before);
    assertInvariant(e.state);
});

test('canNeigh is false for a player whose own upgrade blocks instants', () => {
    const catalogWithLock = [...catalog, entry('walled', 3, 'upgrade')];
    const withLock: Array<CardDef> = [
        { id: 'baby', kind: 'baby' },
        { id: 'basic', kind: 'basic' },
        { id: 'spell', kind: 'magic', onPlay: prim({ p: 'draw', count: 1 }) },
        { id: 'walled', kind: 'upgrade', modifiers: [{ m: 'blockPlay', kind: 'instant' }] }
    ];
    const e = new Engine({
        registry: buildRegistry(catalogWithLock, withLock, new Set()),
        playerCount: 3,
        seed: 'engine'
    });
    seats(e);

    for (const seat of [0, 1]) createCard(e.state, `lock${seat}`, 'walled', seat, 'hand');
    assert.deepEqual(e.dispatch(0, { type: 'BEGIN_TURN' }), { ok: true });
    assert.ok(e.state.players[0].hand.includes('lock0'));
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'lock0' }), { ok: true });
    assert.deepEqual(e.dispatch(0, { type: 'END_TURN' }), { ok: true });

    assert.deepEqual(e.dispatch(1, { type: 'BEGIN_TURN' }), { ok: true });
    const played = e.state.players[1].hand.find(iid => e.defOf(iid)?.kind === 'basic') as string;
    assert.deepEqual(e.dispatch(1, { type: 'PLAY_CARD', iid: played }), { ok: true });

    assert.equal(e.view(0).chain.canNeigh, false);
    assert.equal(e.view(2).chain.canNeigh, true);
    assertInvariant(e.state);
});

test('a magic-blocked player can still neigh with an instant', () => {
    const catalogWithLock = [...catalog,
        entry('lockdown', 3, 'upgrade'),
        entry('nope', 6, 'instant'),
        entry('supernope', 1, 'instant')];
    const withLock: Array<CardDef> = [
        { id: 'baby', kind: 'baby' },
        { id: 'basic', kind: 'basic' },
        { id: 'spell', kind: 'magic', onPlay: prim({ p: 'draw', count: 1 }) },
        { id: 'lockdown', kind: 'upgrade', modifiers: [{ m: 'blockPlay', kind: 'magic' }] },
        { id: 'nope', kind: 'instant', instant: { neigh: true } },
        { id: 'supernope', kind: 'instant', instant: { neigh: true, superNeigh: true } }
    ];
    const e = new Engine({
        registry: buildRegistry(catalogWithLock, withLock, new Set()),
        playerCount: 3,
        seed: 'engine'
    });
    seats(e);

    createCard(e.state, 'lockS', 'lockdown', 0, 'stable');
    createCard(e.state, 'nope1', 'nope', 0, 'hand');
    createCard(e.state, 'spell0', 'spell', 0, 'hand');
    assert.deepEqual(e.dispatch(0, { type: 'BEGIN_TURN' }), { ok: true });

    const refused = e.dispatch(0, { type: 'PLAY_CARD', iid: 'spell0' });
    assert.equal(refused.ok, false);
    assert.equal(refused.ok ? '' : refused.error, 'You cannot play that kind of card now');
    assert.equal(e.state.cards['spell0'].zone, 'hand');

    assert.deepEqual(e.dispatch(0, { type: 'END_TURN' }), { ok: true });
    assert.equal(e.state.phase, 'DISCARD_LIMIT');
    assert.deepEqual(e.dispatch(0, { type: 'DISCARD', iids: [e.state.players[0].hand[0]] }), { ok: true });
    assert.equal(e.state.phase, 'AWAIT_BEGIN');

    assert.deepEqual(e.dispatch(1, { type: 'BEGIN_TURN' }), { ok: true });
    const played = e.state.players[1].hand.find(iid => e.defOf(iid)?.kind === 'basic') as string;
    assert.deepEqual(e.dispatch(1, { type: 'PLAY_CARD', iid: played }), { ok: true });

    const view = e.view(0);
    assert.equal(view.chain.canNeigh, true);
    assert.equal(view.cards['nope1'].neighable, true);
    assert.deepEqual(e.dispatch(0, { type: 'NEIGH', iid: 'nope1', targetEntryId: view.chain.top!.id }), { ok: true });
    assert.equal(e.state.cards[played].zone, 'discard');
    assert.equal(e.state.players[1].stable.includes(played), false);
    assert.equal(e.state.cards['nope1'].zone, 'discard');
    assertInvariant(e.state);
});

function promptEngine(onPlay: CardDef['onPlay']): Engine {
    const e = new Engine({
        registry: buildRegistry([...catalog, entry('choice', 1, 'magic')],
            [...defs, { id: 'choice', kind: 'magic', onPlay }], new Set()),
        playerCount: 3,
        seed: 'prompt-cancel'
    });
    seats(e);
    assert.deepEqual(e.dispatch(0, { type: 'BEGIN_TURN' }), { ok: true });
    createCard(e.state, 'test-choice', 'choice', 0, 'hand');
    return e;
}

test('playing a Magic card remains publicly named after it shuffles into the deck', () => {
    const e = promptEngine(prim({ p: 'shuffleZonesIntoDeck', zones: ['limbo'] }));
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'test-choice' }), { ok: true });
    assert.equal(e.state.cards['test-choice'].zone, 'deck');
    const opponent = e.view(1);
    assert.equal(opponent.cards['test-choice'], undefined);
    assert.equal(opponent.chain.top?.publicDefId, 'choice');
    const event = e.eventsSince(0).find(item => item.type === 'play' && item.card === 'test-choice');
    assert.equal(event?.publicDefId, 'choice');
    assertInvariant(e.state);
});

test('canceling a local required choice restores the play and retains public knowledge', () => {
    const e = promptEngine(prim({ p: 'discard', sel: sel('hand', 'self', 1) }));
    e.state.turn.bonusPlays = 1;
    createCard(e.state, 'previous-basic', 'basic', 0, 'hand');
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'previous-basic' }), { ok: true });
    const previous = e.stack.top();
    const rng = e.rng.s;
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'test-choice' }), { ok: true });
    const promptId = e.view(0).prompt?.id as number;
    const seen = e.log.history.at(-1)!.seq;
    assert.equal(e.view(0).prompt?.canCancel, true);
    assert.equal(e.view(1).prompt, null);
    assert.equal(e.dispatch(1, { type: 'CANCEL_PROMPT', promptId }).ok, false);
    assert.equal(e.dispatch(0, { type: 'CANCEL_PROMPT', promptId: promptId + 1 }).ok, false);
    assert.deepEqual(e.dispatch(0, { type: 'CANCEL_PROMPT', promptId }), { ok: true });
    assert.equal(e.state.prompt, null);
    assert.equal(e.state.cards['test-choice'].zone, 'hand');
    assert.deepEqual(e.state.cards['test-choice'].revealedTo, [0, 1, 2]);
    assert.equal(e.state.turn.actionsUsed, 1);
    assert.equal(e.stack.top()?.id, previous?.id);
    assert.equal(e.rng.s, rng);
    assert.equal(e.log.history.some(event => event.card === 'test-choice'), false);
    assert.equal(e.eventsSince(seen).at(-1)?.type, 'cancel');
    assertInvariant(e.state);
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'test-choice' }), { ok: true });
    assert.notEqual(e.view(0).prompt?.id, promptId);
    assert.equal(e.dispatch(0, { type: 'CANCEL_PROMPT', promptId }).ok, false);
});

test('a choice after learning a deck card cannot roll back the play', () => {
    const e = promptEngine(seq(prim({ p: 'draw', count: 1 }),
        prim({ p: 'discard', sel: sel('hand', 'self', 1) })));
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'test-choice' }), { ok: true });
    const promptId = e.view(0).prompt!.id;
    assert.equal(e.view(0).prompt?.canCancel, false);
    assert.equal(e.dispatch(0, { type: 'CANCEL_PROMPT', promptId }).ok, false);
    assert.equal(e.state.prompt?.id, promptId);
    assertInvariant(e.state);
});

test('a later choice cannot undo another player’s response', () => {
    const e = promptEngine(seq(prim({ p: 'discardFromPlayer' }),
        prim({ p: 'discard', sel: sel('hand', 'self', 1) })));
    assert.deepEqual(e.dispatch(0, { type: 'PLAY_CARD', iid: 'test-choice' }), { ok: true });
    assert.equal(e.view(0).prompt?.canCancel, true);
    const first = e.view(0).prompt!.id;
    assert.deepEqual(e.dispatch(0, { type: 'RESPOND', promptId: first, selection: [1] }), { ok: true });
    assert.equal(e.state.prompt?.player, 1);
    const other = e.state.prompt!.id;
    assert.deepEqual(e.dispatch(1, { type: 'RESPOND', promptId: other,
        selection: [e.state.players[1].hand[0]] }), { ok: true });
    assert.equal(e.state.prompt?.player, 0);
    const last = e.view(0).prompt!.id;
    assert.equal(e.view(0).prompt?.canCancel, false);
    assert.equal(e.dispatch(0, { type: 'CANCEL_PROMPT', promptId: last }).ok, false);
    assertInvariant(e.state);
});
