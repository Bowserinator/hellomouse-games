import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { emptyState, createCard } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import { EventLog } from '../../client/unstable_unicorns/js/engine/events.js';
import { seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { ExecCtx } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { respond, run, startEffect } from '../../client/unstable_unicorns/js/engine/exec/interpreter.js';
import type { RunState } from '../../client/unstable_unicorns/js/engine/exec/interpreter.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';
import { prim, sel, seq } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';
import { findReplacements } from '../../client/unstable_unicorns/js/engine/query/replacements.js';

interface Env {
    ex: ExecCtx;
    state: GameState;
    nodes: NodeMap;
    add(defId: string, owner: number, zone: Zone): string;
    script(effect: Effect, player?: number, source?: string): RunState;
    answer(answer: import('../../client/unstable_unicorns/js/engine/state.js').Binding): RunState;
    queued: Array<string>;
}

function env(defs: Array<CardDef>, playerCount = 3): Env {
    const state = emptyState(playerCount, 7);
    const byId = new Map(defs.map(def => [def.id, def]));
    const nodes: NodeMap = {};
    for (const def of defs) compileCard(def, nodes);
    const queued: Array<string> = [];
    let next = 0;
    let scripts = 0;
    const ex: ExecCtx = {
        state,
        nodes,
        log: new EventLog(),
        rng: seedFrom('test'),
        defOf: iid => byId.get(state.cards[iid].defId),
        prompts: { n: 0 },
        custom: {},
        queue: pending => {
            queued.push(pending.effect);
        }
    };
    const e: Env = {
        ex,
        state,
        nodes,
        queued,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        },
        script(effect, player = 0, source = 'c0') {
            if (!effect.id) compileCard({ id: `script${++scripts}`, kind: 'magic', onPlay: effect }, nodes);
            return startEffect(ex, effect.id as string, player, source);
        },
        answer(value) {
            const result = respond(ex, value);
            assert.equal('error' in result ? result.error : null, null);
            return (result as { state: RunState }).state;
        }
    };
    return e;
}

const unicorn = (id = 'u'): CardDef => ({ id, kind: 'basic' });
const magic = (id = 'm'): CardDef => ({ id, kind: 'magic' });

test('draw takes from the deck, reshuffling the discard when it runs out', () => {
    const e = env([unicorn(), magic()]);
    e.add('u', 0, 'deck');
    e.add('m', 0, 'deck');
    e.add('u', 0, 'discard');
    const out = e.script(prim({ p: 'draw', count: 3 }));

    assert.equal(out, 'done');
    assert.equal(e.state.players[0].hand.length, 3);
    assert.equal(e.state.deck.length, 0);
    assert.equal(e.state.discard.length, 0);
    assertInvariant(e.state);
});

test('discard asks the controller and moves the chosen card', () => {
    const e = env([magic()]);
    e.add('m', 0, 'hand');
    e.add('m', 0, 'hand');
    e.add('m', 0, 'hand');
    const out = e.script(prim({ p: 'discard', sel: sel('hand', 'self', 1) }));

    assert.equal(out, 'wait');
    assert.equal(e.state.prompt?.player, 0);
    assert.equal(e.state.prompt?.kind, 'cards');
    assert.equal(e.state.prompt?.reason, 'Choose a card to discard');
    const chosen = e.state.prompt?.cards[1];
    assert.equal(e.answer([chosen]), 'done');
    assert.deepEqual(e.state.discard, [chosen]);
    assert.equal(e.state.players[0].hand.length, 2);
    assertInvariant(e.state);
});

test('destroy and sacrifice use their own cause', () => {
    const e = env([unicorn()]);
    const a = e.add('u', 1, 'stable');
    assert.equal(e.script(prim({ p: 'destroy', sel: sel('stable', 'other', 1) })), 'done');
    assert.deepEqual(e.state.discard, [a]);

    const e2 = env([unicorn()]);
    const b = e2.add('u', 1, 'stable');
    assert.equal(e2.script(prim({ p: 'sacrifice', sel: sel('stable', 'other', 1) })), 'done');
    assert.deepEqual(e2.state.discard, [b]);
});

test('returnToHand sends a card back to its owner', () => {
    const e = env([unicorn()]);
    const u = e.add('u', 1, 'stable');
    e.script(prim({ p: 'returnToHand', sel: sel('stable', 'other', 1) }));
    assert.deepEqual(e.state.players[1].hand, [u]);
    assert.equal(e.state.players[1].hand.length, 1);
    assertInvariant(e.state);
});

test('moveCard and moveStable send cards to fixed zones', () => {
    const e = env([unicorn()]);
    const u = e.add('u', 0, 'hand');
    e.script(prim({ p: 'moveCard', sel: sel('hand', 'self', 1), zone: 'nursery', owner: 'self' }));
    assert.deepEqual(e.state.nursery, [u]);

    const e2 = env([unicorn()]);
    const v = e2.add('u', 1, 'stable');
    e2.script(prim({ p: 'moveStable', sel: sel('stable', 'other', 1), owner: 'self' }));
    assert.deepEqual(e2.state.players[0].stable, [v]);
    assert.equal(e2.state.cards[v].owner, 0);
    assertInvariant(e2.state);
});

test('stealRandom takes a random card and reveals it', () => {
    const e = env([unicorn()]);
    for (let i = 0; i < 3; i++) e.add('u', 1, 'hand');
    e.script(prim({ p: 'stealRandom', sel: sel('hand', 'other', 1) }));
    assert.equal(e.state.players[0].hand.length, 1);
    assert.equal(e.state.players[0].stable.length, 0);
    const iid = e.state.players[0].hand[0];
    assert.equal(e.state.cards[iid].revealedTo.length, 3);
    assert.equal(e.state.players[1].hand.length, 2);
    assertInvariant(e.state);
});

test('lookAndSteal keeps one card and returns the rest', () => {
    const e = env([unicorn(), magic()]);
    e.add('u', 0, 'deck');
    e.add('m', 0, 'deck');
    e.add('u', 0, 'deck');
    const out = e.script(prim({ p: 'lookAndSteal', from: 'deck', count: 3 }));
    assert.equal(out, 'wait');
    const prompt = e.state.prompt;
    assert.ok(prompt);
    const picked = prompt.cards[0];
    assert.equal(e.answer([picked]), 'done');
    assert.deepEqual(e.state.players[0].hand, [picked]);
    assert.equal(e.state.deck.length, 2);
    assertInvariant(e.state);
});

test('swapHands swaps two hands and their ownership', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'hand');
    e.add('u', 1, 'hand');
    e.add('u', 1, 'hand');
    const out = e.script(prim({ p: 'swapHands', who: 'other' }));
    assert.equal(out, 'wait');
    assert.equal(e.state.prompt?.kind, 'player');
    assert.equal(e.state.prompt?.reason, 'Choose a player to swap hands with');
    assert.equal(e.answer([1]), 'done');
    assert.equal(e.state.players[0].hand.length, 2);
    assert.equal(e.state.players[1].hand.length, 1);
    for (const iid of e.state.players[0].hand) assert.equal(e.state.cards[iid].owner, 0);
    assertInvariant(e.state);
});

test('tradeUnicorns swaps two stable cards', () => {
    const e = env([unicorn()]);
    const mine = e.add('u', 0, 'stable');
    const theirs = e.add('u', 1, 'stable');
    e.script(prim({ p: 'tradeUnicorns', mine: sel('stable', 'self', 1), theirs: sel('stable', 'other', 1) }));
    assert.deepEqual(e.state.players[0].stable, [theirs]);
    assert.deepEqual(e.state.players[1].stable, [mine]);
    assertInvariant(e.state);
});

test('search takes a filtered card and shuffles the source', () => {
    const e = env([unicorn(), magic()]);
    e.add('u', 0, 'deck');
    e.add('m', 0, 'deck');
    const out = e.script(prim({ p: 'search', from: 'deck', filter: { f: 'type', type: 'magic' }, count: 1, as: 'found' }));
    assert.equal(out, 'wait');
    const prompt = e.state.prompt;
    assert.ok(prompt);
    assert.equal(prompt.reason, 'Choose a card to add to your hand');
    const target = prompt.cards[0];
    assert.equal(e.answer([target]), 'done');
    assert.deepEqual(e.state.players[0].hand, [target]);
    assert.equal(e.state.deck.length, 1);
    assertInvariant(e.state);
});

test('a search reveals its candidates to the searcher only', () => {
    const e = env([unicorn(), magic()]);
    const hidden = [e.add('u', 0, 'deck'), e.add('m', 0, 'deck')];
    e.script(prim({ p: 'search', from: 'deck', count: 1 }));

    const prompt = e.state.prompt;
    assert.ok(prompt);
    assert.equal(prompt.player, 0);
    for (const iid of hidden) assert.deepEqual(e.state.cards[iid].revealedTo, [0]);
});

test('shuffleInto moves cards into a zone and shuffles it', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'hand');
    e.add('u', 0, 'hand');
    e.add('u', 0, 'deck');
    e.script(prim({ p: 'shuffleInto', sel: sel('hand', 'self', 2), zone: 'deck', owner: 'self' }));
    assert.equal(e.state.deck.length, 3);
    assert.equal(e.state.players[0].hand.length, 0);
    assertInvariant(e.state);
});

test('replaceUnicornsWithBabies discards Unicorns and swaps in nursery babies', () => {
    const e = env([unicorn(), { id: 'baby', kind: 'baby' }]);
    e.add('u', 0, 'stable');
    e.add('baby', 0, 'nursery');
    assert.equal(e.script(prim({ p: 'replaceUnicornsWithBabies' })), 'wait');
    assert.equal(e.answer([0]), 'done');
    assert.equal(e.state.players[0].stable.length, 1);
    assert.equal(e.state.cards[e.state.players[0].stable[0]].defId, 'baby');
    assert.equal(e.state.nursery.length, 0);
    assert.equal(e.state.discard.length, 1);
    assert.equal(e.state.cards[e.state.discard[0]].defId, 'u');
    assertInvariant(e.state);
});

test('turn flags, lingering and custom handlers', () => {
    const e = env([unicorn(), magic()]);
    e.script(prim({ p: 'takeExtraTurn' }));
    e.script(prim({ p: 'endTurnNow' }));
    assert.equal(e.state.turn.extraTurns, 1);
    assert.equal(e.state.turn.endNow, true);

    let calls = 0;
    e.ex.custom['ping'] = () => {
        calls++;
    };
    const out = e.script(seq(prim({ p: 'custom', name: 'ping' }), prim({ p: 'custom', name: 'absent' })));
    assert.equal(out, 'done');
    assert.equal(calls, 1);

    const lingering = seq(prim({ p: 'addLingering', until: 'endOfTurn', effect: prim({ p: 'draw', count: 1 }) }));
    e.script(lingering);
    assert.equal(e.state.lingering.length, 1);
    assert.equal(e.state.lingering[0].until, 'endOfTurn');
    assert.equal(e.state.lingering[0].effect.length > 0, true);
});

test('optional asks yes or no and skips on no', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    const effect: Effect = { e: 'optional', effect: prim({ p: 'draw', count: 1 }) };
    assert.equal(e.script(effect), 'wait');
    assert.equal(e.state.prompt?.kind, 'yesno');
    assert.equal(e.answer(false), 'done');
    assert.equal(e.state.players[0].hand.length, 0);
    assert.equal(e.state.deck.length, 1);

    assert.equal(e.script({ e: 'optional', effect: prim({ p: 'draw', count: 1 }) }), 'wait');
    assert.equal(e.answer(true), 'done');
    assert.equal(e.state.players[0].hand.length, 1);
});

test('ifYouDo also stops for a yes or no', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    const effect: Effect = { e: 'ifYouDo', effect: prim({ p: 'draw', count: 1 }) };
    assert.equal(e.script(effect), 'wait');
    assert.equal(e.answer(false), 'done');
    assert.equal(e.state.players[0].hand.length, 0);
});

test('choice asks for an option index', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    const effect: Effect = {
        e: 'choice',
        options: [prim({ p: 'draw', count: 1 }), prim({ p: 'takeExtraTurn' })]
    };
    assert.equal(e.script(effect), 'wait');
    assert.equal(e.state.prompt?.kind, 'option');
    assert.equal(e.state.prompt?.max, 1);
    assert.equal(e.answer(1), 'done');
    assert.equal(e.state.turn.extraTurns, 1);
    assert.equal(e.state.players[0].hand.length, 0);
});

test('when skips its effect when the condition is false', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    const off = e.script({ e: 'when', cond: { c: 'count', zone: 'hand', owner: 'self', cmp: 'gte', n: 1 }, effect: prim({ p: 'draw', count: 1 }) });
    assert.equal(off, 'done');
    assert.equal(e.state.players[0].hand.length, 0);

    e.add('u', 0, 'hand');
    const on = e.script({ e: 'when', cond: { c: 'count', zone: 'hand', owner: 'self', cmp: 'gte', n: 1 }, effect: prim({ p: 'draw', count: 1 }) });
    assert.equal(on, 'done');
    assert.equal(e.state.players[0].hand.length, 2);
});

test('repeat and forEachPlayer run their body the right number of times', () => {
    const e = env([unicorn()]);
    for (let i = 0; i < 4; i++) e.add('u', 0, 'deck');
    e.script({ e: 'repeat', count: 2, effect: prim({ p: 'draw', count: 1 }) });
    assert.equal(e.state.players[0].hand.length, 2);

    const e2 = env([unicorn()]);
    e2.add('u', 0, 'deck');
    e2.script({ e: 'forEachPlayer', effect: prim({ p: 'draw', count: 1 }) });
    assert.equal(e2.state.players[0].hand.length, 1);
    assert.equal(e2.state.players[1].hand.length, 0);
    assert.equal(e2.state.deck.length, 0);
});

test('illegal answers are rejected and the prompt stays open', () => {
    const e = env([magic()]);
    e.add('m', 0, 'hand');
    e.add('m', 0, 'hand');
    assert.equal(e.script(prim({ p: 'discard', sel: sel('hand', 'self', 1) })), 'wait');
    const open = e.state.prompt;

    const bad = respond(e.ex, ['nonsense']);
    assert.equal('error' in bad, true);
    assert.equal(e.state.prompt?.id, open?.id);

    const openPrompt = e.state.prompt;
    assert.ok(openPrompt);
    const tooMany = respond(e.ex, [openPrompt.cards[0], openPrompt.cards[1]]);
    assert.equal('error' in tooMany, true);

    const fine = respond(e.ex, [openPrompt.cards[0]]);
    assert.equal('error' in fine, false);
    assert.equal(e.state.prompt, null);
});

test('prompt ids keep growing and a second script resumes where it stopped', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    const effect: Effect = seq(prim({ p: 'draw', count: 1 }), { e: 'optional', effect: prim({ p: 'takeExtraTurn' }) });
    assert.equal(e.script(effect), 'wait');
    const first = e.state.prompt?.id ?? 0;
    e.answer(true);
    assert.equal(e.state.turn.extraTurns, 1);
    assert.equal(e.state.exec.length, 0);

    e.add('u', 0, 'deck');
    assert.equal(e.script({ e: 'optional', effect: prim({ p: 'draw', count: 1 }) }), 'wait');
    assert.equal((e.state.prompt?.id ?? 0) > first, true);
});

test('run reports waiting versus finished', () => {
    const e = env([unicorn()]);
    e.add('u', 0, 'deck');
    assert.equal(run(e.ex), 'done');
    assert.equal(e.script(prim({ p: 'draw', count: 1 })), 'done');
});

test('the affected player orders two replacement effects', () => {
    const strict = (id: string, copies: number): CardDef => ({
        id,
        kind: 'upgrade',
        replacements: [{
            r: 'replace' as const,
            when: 'destroy' as const,
            filter: { f: 'not' as const, not: { f: 'type' as const, type: 'magic' as const } },
            effect: prim({ p: 'draw', count: copies })
        }]
    });
    const e = env([unicorn('u'), magic(), strict('keepA', 1), strict('keepB', 2)]);
    const first = e.add('keepA', 0, 'stable');
    const second = e.add('keepB', 1, 'stable');
    const target = e.add('u', 1, 'stable');

    const out = e.script(prim({ p: 'destroy', sel: { zone: 'stable', owner: 'other', count: 1 } }), 0);
    assert.equal(out, 'wait');
    assert.equal(e.state.prompt?.kind, 'cards');

    const asked = e.answer([target]);
    assert.equal(asked, 'wait');
    const prompt = e.state.prompt;
    assert.ok(prompt);
    assert.equal(prompt.kind, 'order');
    assert.equal(prompt.player, 1);
    assert.deepEqual([...prompt.cards].sort(), [first, second].sort());

    const plans = findReplacements({ state: e.state, defOf: e.ex.defOf }, target,
        { type: 'destroy', card: target, player: 1 });
    const planOf = (source: string) => plans.find(plan => plan.kind === 'effect' && plan.source === source);

    const chosen = planOf(second);
    assert.ok(chosen && chosen.kind === 'effect');

    assert.equal(e.answer([second, first]), 'done');
    assert.equal(e.queued[0], chosen.effect.id);
    assertInvariant(e.state);
});

test('fetchFromDiscard asks the controller which discard card to take', () => {
    const e = env([unicorn(), magic()]);
    const first = e.add('u', 0, 'discard');
    const second = e.add('m', 0, 'discard');

    assert.equal(e.script(prim({ p: 'fetchFromDiscard', count: 1 })), 'wait');
    const prompt = e.state.prompt;
    assert.ok(prompt);
    assert.equal(prompt.kind, 'cards');
    assert.deepEqual([...prompt.cards].sort(), [first, second].sort());

    assert.equal(e.answer([first]), 'done');
    assert.equal(e.state.players[0].hand.includes(first), true);
    assert.equal(e.state.discard.includes(second), true);
    assertInvariant(e.state);
});

test('a single replacement effect resolves without an order prompt', () => {
    const keeper = (id: string): CardDef => ({
        id,
        kind: 'upgrade',
        replacements: [{
            r: 'replace',
            when: 'destroy',
            effect: prim({ p: 'draw', count: 1 })
        }]
    });
    const e = env([unicorn('u'), magic(), keeper('keep')]);
    e.add('keep', 0, 'stable');
    const target = e.add('u', 1, 'stable');

    assert.equal(e.script(prim({ p: 'destroy', sel: { zone: 'stable', owner: 'other', count: 1 } }), 0), 'done');
    assert.equal(e.state.prompt, null);
    assert.equal(e.state.cards[target].zone, 'stable');
    assert.equal(e.queued.length, 1);
});
