import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Modifier } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { emptyState, createCard } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState } from '../../client/unstable_unicorns/js/engine/state.js';
import {
    actionsPerTurn, drawsPerTurn, handLimit, stableLimit, unicornCount, isUnicorn, unicornType,
    protectedFrom, blocksPlay, handVisible
} from '../../client/unstable_unicorns/js/engine/query/modifiers.js';
import type { World } from '../../client/unstable_unicorns/js/engine/query/modifiers.js';
import { findReplacements } from '../../client/unstable_unicorns/js/engine/query/replacements.js';
import { countZone, condCtx } from '../../client/unstable_unicorns/js/engine/query/active.js';
import { ACTIONS_PER_TURN, DRAWS_PER_TURN, HAND_LIMIT } from '../../client/unstable_unicorns/js/vars.js';

interface Fixture {
    world: World;
    state: GameState;
    add(defId: string, owner: number, zone: 'hand' | 'stable'): string;
}

function fixture(defs: Array<CardDef>, playerCount = 3): Fixture {
    const state = emptyState(playerCount, 7);
    const byId = new Map(defs.map(def => [def.id, def]));
    let next = 0;
    const world: World = { state, defOf: iid => byId.get(state.cards[iid].defId) };
    return {
        world,
        state,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        }
    };
}

const upgrade = (id: string, modifiers: Array<Modifier>): CardDef => ({ id, kind: 'upgrade', modifiers });
const basic = (id: string, type?: CardDef['unicornType']): CardDef => ({ id, kind: 'basic', unicornType: type });

test('modifier folding per kind', () => {
    const f = fixture([
        upgrade('a', [{ m: 'actionsPerTurn', value: 1 }, { m: 'drawsPerTurn', value: 2 }, { m: 'handLimit', value: 2 }]),
        upgrade('s', [{ m: 'stableLimit', value: 3 }]),
        upgrade('v', [{ m: 'handVisible' }]),
        upgrade('b', [{ m: 'blockPlay', kind: 'magic' }])
    ]);
    f.add('a', 0, 'stable');
    f.add('s', 0, 'stable');
    f.add('v', 0, 'stable');
    f.add('b', 0, 'stable');

    assert.equal(actionsPerTurn(f.world, 0), ACTIONS_PER_TURN + 1);
    assert.equal(actionsPerTurn(f.world, 1), ACTIONS_PER_TURN);
    assert.equal(drawsPerTurn(f.world, 0), DRAWS_PER_TURN + 2);
    assert.equal(drawsPerTurn(f.world, 1), DRAWS_PER_TURN);
    assert.equal(handLimit(f.world, 0), HAND_LIMIT + 2);
    assert.equal(stableLimit(f.world, 1), Infinity);
    assert.equal(stableLimit(f.world, 0), 3);
    assert.equal(handVisible(f.world, 0), true);
    assert.equal(handVisible(f.world, 1), false);
    assert.equal(blocksPlay(f.world, 0, 'magic'), true);
    assert.equal(blocksPlay(f.world, 0, 'upgrade'), false);
});

test('modifiers stop applying when the card leaves the stable', () => {
    const f = fixture([upgrade('a', [{ m: 'actionsPerTurn', value: 1 }])]);
    const iid = f.add('a', 0, 'hand');
    assert.equal(actionsPerTurn(f.world, 0), ACTIONS_PER_TURN);
    f.state.players[0].hand.pop();
    f.state.players[0].stable.push(iid);
    f.state.cards[iid].zone = 'stable';
    assert.equal(actionsPerTurn(f.world, 0), ACTIONS_PER_TURN + 1);
});

test('unicorn type is changed by modifiers, pandas count as pandas', () => {
    const f = fixture([
        basic('u'),
        basic('baby', 'baby'),
        upgrade('panda', [{ m: 'unicornType', type: 'panda' }]),
        upgrade('weird', [{ m: 'unicornType', type: 'special', filter: { f: 'type', type: 'magic' } }]),
        { id: 'spell', kind: 'magic' }
    ]);
    const u = f.add('u', 0, 'stable');
    const baby = f.add('baby', 0, 'stable');
    const panda = f.add('panda', 0, 'stable');
    const magic = f.add('spell', 1, 'stable');
    f.add('weird', 1, 'stable');

    assert.equal(unicornType(f.world, u), 'panda');
    assert.equal(isUnicorn(f.world, u, 'panda'), true);
    assert.equal(isUnicorn(f.world, u, 'basic'), false);
    assert.equal(unicornType(f.world, baby), 'panda');
    assert.equal(isUnicorn(f.world, panda), false);
    assert.equal(unicornType(f.world, magic), 'special');
    assert.equal(isUnicorn(f.world, magic), true);
});

test('unicornCount adds weight from count modifiers', () => {
    const f = fixture([basic('u'), basic('big'), upgrade('dbl', [{ m: 'unicornCount', value: 2 }])]);
    f.add('u', 0, 'stable');
    f.add('big', 1, 'stable');
    assert.equal(unicornCount(f.world, 0), 1);
    assert.equal(unicornCount(f.world, 1), 1);

    const f2 = fixture([basic('u'), upgrade('dbl', [{ m: 'unicornCount', value: 2 }])]);
    f2.add('u', 0, 'stable');
    f2.add('dbl', 0, 'stable');
    assert.equal(unicornCount(f2.world, 0), 1);

    const f3 = fixture([basic('u'), { id: 'dbl', kind: 'upgrade', modifiers: [{ m: 'unicornCount', value: 2 }] }]);
    const u = f3.add('u', 0, 'stable');
    const dbl = f3.add('dbl', 0, 'stable');
    assert.equal(unicornCount(f3.world, 0), 1);

    const f4 = fixture([{ id: 'twice', kind: 'basic', modifiers: [{ m: 'unicornCount', value: 2 }] }]);
    f4.add('twice', 0, 'stable');
    assert.equal(unicornCount(f4.world, 0), 2);
    assert.equal(u.length > 0 && dbl.length > 0, true);
});

test('protection covers the listed actions only', () => {
    const f = fixture([
        basic('u'),
        upgrade('shield', [{ m: 'protect', against: 'destroy' }, { m: 'protect', against: 'neigh' }])
    ]);
    const u = f.add('u', 0, 'stable');
    f.add('shield', 0, 'stable');
    assert.equal(protectedFrom(f.world, u, 'destroy'), true);
    assert.equal(protectedFrom(f.world, u, 'neigh'), true);
    assert.equal(protectedFrom(f.world, u, 'sacrifice'), false);
});

test('replacement order: default redirect, then owner, then next seats', () => {
    const f = fixture([
        { id: 'baby', kind: 'baby' },
        {
            id: 'saver', kind: 'upgrade',
            replacements: [{ r: 'replace', when: 'destroy', effect: { e: 'prim', prim: { p: 'takeExtraTurn' } } }]
        }
    ], 3);
    const baby = f.add('baby', 1, 'stable');
    f.add('saver', 1, 'stable');
    f.add('saver', 2, 'stable');
    f.add('saver', 0, 'stable');

    const plans = findReplacements(f.world, baby, { type: 'destroy', card: baby, player: 0 });
    assert.equal(plans.length, 4);
    assert.deepEqual(plans[0], { kind: 'redirect', zone: 'nursery' });
    assert.equal(plans[1].kind, 'effect');
    assert.equal(plans[1].kind === 'effect' && plans[1].player, 1);
    assert.equal(plans[2].kind === 'effect' && plans[2].player, 2);
    assert.equal(plans[3].kind === 'effect' && plans[3].player, 0);
});

test('unless and filter narrow the replacement set', () => {
    const f = fixture([
        basic('u'),
        {
            id: 'saver', kind: 'upgrade',
            replacements: [{
                r: 'replace', when: 'destroy',
                filter: { f: 'type', type: 'basic' },
                unless: { c: 'count', zone: 'hand', owner: 'self', cmp: 'gte', n: 1 },
                effect: { e: 'prim', prim: { p: 'takeExtraTurn' } }
            }]
        }
    ]);
    const u = f.add('u', 0, 'stable');
    f.add('saver', 0, 'stable');
    f.add('u', 0, 'hand');

    assert.equal(findReplacements(f.world, u, { type: 'destroy' }).length, 0);
    f.state.players[0].hand.pop();
    assert.equal(findReplacements(f.world, u, { type: 'discard' }).length, 0);
    assert.equal(findReplacements(f.world, u, { type: 'destroy' }).length, 1);
});

test('countZone counts matching cards per owner', () => {
    const f = fixture([basic('u'), { id: 'm', kind: 'magic' }]);
    f.add('u', 0, 'stable');
    f.add('m', 0, 'stable');
    f.add('u', 1, 'stable');
    f.add('m', 0, 'hand');
    f.add('m', 1, 'hand');

    assert.equal(countZone(f.world, 0, 'stable', 'self', { f: 'type', type: 'basic' }), 1);
    assert.equal(countZone(f.world, 0, 'stable', 'other', { f: 'type', type: 'basic' }), 1);
    assert.equal(countZone(f.world, 0, 'stable', 'any', { f: 'type', type: 'basic' }), 2);
    assert.equal(countZone(f.world, 0, 'hand', 'self', undefined), 1);
    assert.equal(countZone(f.world, 0, 'hand', 'any', undefined), 2);
    assert.equal(condCtx(f.world, 0, null).countZone('stable', 'any'), 3);
});

test('Pandas are not Unicorn targets or winning Unicorns, and transformation stays in the stable', () => {
    const f = fixture([
        basic('u'), basic('magical', 'special'),
        upgrade('panda', [{ m: 'unicornType', type: 'panda' }])
    ]);
    const stable = f.add('u', 0, 'stable');
    const hand = f.add('magical', 0, 'hand');
    f.add('panda', 0, 'stable');
    assert.equal(isUnicorn(f.world, stable), false);
    assert.equal(isUnicorn(f.world, stable, 'panda'), true);
    assert.equal(unicornCount(f.world, 0), 0);
    assert.equal(countZone(f.world, 0, 'stable', 'self', { f: 'unicorn' }), 0);
    assert.equal(unicornType(f.world, hand), 'special');
    assert.equal(isUnicorn(f.world, hand), true);
    assert.equal(isUnicorn(f.world, hand, 'basic'), false);
});
