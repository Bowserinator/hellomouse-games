import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cardScene } from './scenarios.js';

test('DESTROY only targets other players, so Unicorn Poison cannot be played on your own Unicorns', () => {
    const { engine, add } = cardScene();
    add('basic-unicorn-blue', 0, 'stable');
    const poison = add('unicorn-poison');
    assert.ok(!engine.view(0).playable.includes(poison));
    add('basic-unicorn-green', 1, 'stable');
    assert.ok(engine.view(0).playable.includes(poison));
});

test('Unicorn Poison never offers the caster\u2019s own Unicorns', () => {
    const { engine, add, act } = cardScene();
    const own = add('basic-unicorn-blue', 0, 'stable');
    const first = add('basic-unicorn-green', 1, 'stable');
    const second = add('basic-unicorn-orange', 2, 'stable');
    act({ type: 'PLAY_CARD', iid: add('unicorn-poison') });
    assert.deepEqual(engine.state.prompt?.cards, [first, second]);
    assert.ok(!engine.state.prompt?.cards.includes(own));
});

test('Tiny Stable counts Ginormous Unicorn as two Unicorns', () => {
    const { engine, add, act } = cardScene();
    add('tiny-stable', 0, 'stable');
    for (let i = 0; i < 3; i++) add('basic-unicorn-blue', 0, 'stable');
    add('basic-unicorn-green', 0, 'stable');
    const ginormous = add('ginormous-unicorn');
    act({ type: 'PLAY_CARD', iid: ginormous });
    assert.equal(engine.state.prompt?.kind, 'cards');
    assert.equal(engine.state.prompt?.player, 0);
    assert.equal(engine.state.cards[engine.state.prompt!.source!].defId, 'tiny-stable');
});
