import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import type { Iid } from '../../client/unstable_unicorns/js/engine/ids.js';
import { canPlay, effectlessPlay, playable } from '../../client/unstable_unicorns/js/engine/legality.js';
import type { LegalityDeps } from '../../client/unstable_unicorns/js/engine/legality.js';
import { viewFor } from '../../client/unstable_unicorns/js/engine/view.js';
import { prim, sel, seq } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';

interface Env {
    state: GameState;
    deps: LegalityDeps;
    add(defId: string, owner: number, zone: Zone): Iid;
    playableAt(seat: number): Array<Iid>;
}

function env(defs: Array<CardDef>, playerCount = 3): Env {
    const state = emptyState(playerCount, 7);
    state.phase = 'ACTION';
    const catalog: Record<string, CardDef> = {};
    const nodes: NodeMap = {};
    for (const def of defs) {
        catalog[def.id] = def;
        compileCard(def, nodes);
    }
    let next = 0;
    return {
        state,
        deps: { catalog, nodes },
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        },
        playableAt(seat) {
            return playable(this.deps, viewFor(state, seat), seat, 1);
        }
    };
}

const unicorn = (id: string): CardDef => ({ id, kind: 'basic' });
const magic = (id: string, onPlay: Effect): CardDef => ({ id, kind: 'magic', onPlay });

const killStable = (owner: 'self' | 'other'): Effect =>
    prim({ p: 'destroy', sel: sel('stable', owner, 1) });
const killHand = (owner: 'self' | 'other'): Effect =>
    prim({ p: 'destroy', sel: sel('hand', owner, 1) });

test('only cards in the active hand are playable in the action phase', () => {
    const e = env([unicorn('u'), unicorn('v')]);
    const mine = e.add('u', 0, 'hand');
    const theirs = e.add('v', 1, 'hand');

    assert.deepEqual(e.playableAt(0), [mine]);
    assert.deepEqual(e.playableAt(1), []);

    e.state.turn.player = 1;
    assert.deepEqual(e.playableAt(0), []);
    assert.equal(canPlay(e.deps, viewFor(e.state, 1), 1, theirs, 1), true);

    e.state.phase = 'AWAIT_BEGIN';
    assert.deepEqual(e.playableAt(1), []);
});

test('instants and blocked kinds are not playable', () => {
    const e = env([
        { id: 'n', kind: 'magic', instant: { neigh: true } },
        { id: 'b', kind: 'magic' },
        { id: 'blocker', kind: 'upgrade', modifiers: [{ m: 'blockPlay', kind: 'magic' }] }
    ]);
    e.add('n', 0, 'hand');
    const plain = e.add('b', 0, 'hand');
    e.add('blocker', 1, 'stable');

    assert.deepEqual(e.playableAt(0), [plain]);
});

test('a shortfall the player can see makes the card unplayable', () => {
    const e = env([magic('killer', killStable('self'))]);
    const card = e.add('killer', 0, 'hand');

    assert.deepEqual(e.playableAt(0), []);

    e.add('u', 0, 'stable');
    assert.deepEqual(e.playableAt(0), [card]);
});

test('a shortfall behind hidden information still counts as playable', () => {
    const e = env([magic('pickpocket', killHand('other'))]);
    const card = e.add('pickpocket', 0, 'hand');

    assert.deepEqual(e.playableAt(0), []);

    e.add('u', 1, 'hand');
    e.add('v', 2, 'hand');
    assert.deepEqual(e.playableAt(0), [card]);
});

test('a protected-only destruction target is not playable', () => {
    const e = env([
        magic('killer', killStable('other')),
        unicorn('u'),
        { id: 'aura', kind: 'upgrade', modifiers: [{ m: 'protect', against: 'destroy' }] }
    ]);
    const card = e.add('killer', 0, 'hand');
    e.add('aura', 1, 'stable');
    e.add('u', 1, 'stable');

    assert.deepEqual(e.playableAt(0), []);
    assert.equal(canPlay(e.deps, viewFor(e.state, 0), 0, card, 1), false);
});

test('a later step without candidates makes the card unplayable', () => {
    const e = env([
        magic('greedy', seq(killStable('self'), killStable('self'))),
        unicorn('u')
    ]);
    const card = e.add('greedy', 0, 'hand');
    e.add('u', 0, 'stable');

    assert.deepEqual(e.playableAt(0), []);

    e.add('v', 0, 'stable');
    assert.deepEqual(e.playableAt(0), [card]);
});

test('hidden cards never reach another player view', () => {
    const e = env([unicorn('open'), unicorn('secretA'), unicorn('secretB')]);
    e.add('open', 0, 'hand');
    e.add('secretA', 1, 'hand');
    e.add('secretB', 0, 'deck');

    const seenByZero = JSON.stringify(viewFor(e.state, 0));
    assert.equal(seenByZero.includes('secretA'), false);
    assert.equal(seenByZero.includes('secretB'), false);
    assert.equal(seenByZero.includes('open'), true);

    const seenByOne = JSON.stringify(viewFor(e.state, 1));
    assert.equal(seenByOne.includes('open'), false);
    assert.equal(seenByOne.includes('secretA'), true);
});

test('playable does not change when hidden contents are permuted', () => {
    const build = (opponentCard: string, deckOrder: Array<string>) => {
        const e = env([
            magic('pickpocket', killHand('other')),
            unicorn('u'),
            unicorn('s1'),
            unicorn('s2')
        ]);
        e.add('pickpocket', 0, 'hand');
        e.add(opponentCard, 1, 'hand');
        for (const defId of deckOrder) e.add(defId, 0, 'deck');
        return e.playableAt(0);
    };

    const first = build('s1', ['u', 's2']);
    const second = build('s2', ['s2', 'u']);
    assert.deepEqual(first, second);
    assert.equal(first.length, 1);
});

test('an open prompt is only visible to its target', () => {
    const e = env([unicorn('u')]);
    const card = e.add('u', 1, 'hand');
    e.state.prompt = {
        id: 1,
        player: 1,
        kind: 'cards',
        reason: 'test',
        source: null,
        cards: [card],
        players: [],
        min: 1,
        max: 1
    };

    assert.equal(viewFor(e.state, 0).prompt, null);
    assert.ok(viewFor(e.state, 1).prompt);
});

test('a legal play that cannot change anything is effectless', () => {
    const e = env([
        magic('recycle', prim({ p: 'fetchFromDiscard', count: 1 })),
        magic('gift', prim({ p: 'draw', count: 1 })),
        unicorn('u')
    ]);
    const recycle = e.add('recycle', 0, 'hand');
    const gift = e.add('gift', 0, 'hand');
    e.add('u', 0, 'deck');

    assert.deepEqual(e.playableAt(0), [recycle, gift]);
    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, recycle, 1), true);
    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, gift, 1), false);

    e.add('u', 0, 'discard');
    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, recycle, 1), false);
});

test('unplayable or effectless-free cards are never flagged effectless', () => {
    const e = env([
        magic('killer', killStable('self')),
        { id: 'plain', kind: 'upgrade', modifiers: [{ m: 'handVisible' }] }
    ]);
    const killer = e.add('killer', 0, 'hand');
    const plain = e.add('plain', 0, 'hand');

    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, killer, 1), false);
    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, plain, 1), false);
    assert.equal(effectlessPlay(e.deps, viewFor(e.state, 0), 0, 'missing', 1), false);
});
