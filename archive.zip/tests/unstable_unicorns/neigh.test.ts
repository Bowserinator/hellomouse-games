import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import type { Iid } from '../../client/unstable_unicorns/js/engine/ids.js';
import { EventLog } from '../../client/unstable_unicorns/js/engine/events.js';
import { seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { ExecCtx } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { PlayStack } from '../../client/unstable_unicorns/js/engine/stack.js';
import { commitChain, neigh, playCard } from '../../client/unstable_unicorns/js/engine/play.js';
import { drawAction } from '../../client/unstable_unicorns/js/engine/turn.js';
import type { Result, Table } from '../../client/unstable_unicorns/js/engine/play.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';
import { prim, sel } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';

interface Env {
    table: Table;
    state: GameState;
    add(defId: string, owner: number, zone: Zone): Iid;
    play(player: number, iid: Iid): Result;
    neigh(player: number, iid: Iid, entryId: number): Result;
    entryId(): number;
}

function env(defs: Array<CardDef>, playerCount = 3): Env {
    const state = emptyState(playerCount, 7);
    state.phase = 'ACTION';
    const catalog = new Map(defs.map(def => [def.id, def]));
    const nodes: NodeMap = {};
    for (const def of defs) compileCard(def, nodes);
    const ex: ExecCtx = {
        state,
        nodes,
        log: new EventLog(),
        rng: seedFrom('neigh'),
        defOf: iid => catalog.get(state.cards[iid].defId),
        prompts: { n: 0 },
        custom: {},
        queue: pending => {
            state.links.next.push(pending);
        }
    };
    const table: Table = { state, stack: new PlayStack(), ex };
    let next = 0;
    return {
        table,
        state,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        },
        play(player, iid) {
            return playCard(table, player, iid);
        },
        neigh(player, iid, entryId) {
            return neigh(table, player, iid, entryId);
        },
        entryId() {
            const top = table.stack.top();
            assert.ok(top);
            return top.id;
        }
    };
}

const drawOne: Effect = prim({ p: 'draw', count: 1 });
const destroyOwn: Effect = prim({ p: 'destroy', sel: sel('stable', 'self', 1) });

const unicorn = (id: string): CardDef => ({ id, kind: 'basic' });
const spell = (id: string, onPlay: Effect): CardDef => ({ id, kind: 'magic', onPlay });
const nope = (id: string, extra: Partial<CardDef> = {}): CardDef => ({
    id, kind: 'magic', instant: { neigh: true }, ...extra
});

test('a Super Neigh event records that it should use the super warning', () => {
    const e = env([spell('drawer', drawOne), nope('super', { instant: { neigh: true, superNeigh: true } })]);
    const played = e.add('drawer', 0, 'hand');
    const counter = e.add('super', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.table.ex.log.history.find(event => event.type === 'neigh')?.superNeigh, true);
});

test('a neigh rolls back the play and keeps the action spent', () => {
    const e = env([spell('drawer', drawOne), nope('n'), unicorn('u'), unicorn('v')]);
    const played = e.add('drawer', 0, 'hand');
    const drawn = e.add('u', 0, 'deck');
    e.add('v', 0, 'deck');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.deepEqual(e.state.players[0].hand, [drawn]);
    assert.equal(e.state.turn.actionsUsed, 1);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);

    assert.equal(e.state.turn.actionsUsed, 1);
    assert.deepEqual(e.state.players[0].hand, []);
    assert.equal(e.state.deck.length, 2);
    assert.deepEqual([...e.state.discard].sort(), [played, counter].sort());
    assert.equal(e.table.ex.log.history.find(event => event.type === 'neigh')?.superNeigh, false);
    assertInvariant(e.state);
});

test('neighing a Unicorn reverses its Stable entry and on-enter effect', () => {
    const e = env([
        { id: 'greedy', kind: 'basic', unicornType: 'special',
            triggers: [{ on: 'enterStable', scope: 'source', effect: drawOne }] },
        nope('n'), unicorn('deck-card')
    ]);
    const played = e.add('greedy', 0, 'hand');
    const drawn = e.add('deck-card', 0, 'deck');
    const counter = e.add('n', 1, 'hand');
    const deck = [...e.state.deck];

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.cards[played].zone, 'stable');
    assert.equal(e.state.players[0].hand.includes(drawn), true);
    assert.ok(e.table.ex.log.history.some(event => event.type === 'enterStable' && event.card === played));

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.players[0].stable.includes(played), false);
    assert.equal(e.state.cards[played].zone, 'discard');
    assert.equal(e.state.players[0].hand.includes(drawn), false);
    assert.deepEqual(e.state.deck, deck);
    assert.equal(e.state.turn.actionsUsed, 1);
    const event = e.table.ex.log.history.find(item => item.type === 'neigh' && item.card === counter);
    assert.equal(event?.targetCard, played);
    assert.equal(event?.targetPlayer, 0);
    assertInvariant(e.state);
});

test('only the most recent play can be neighed', () => {
    const e = env([
        unicorn('u'),
        unicorn('v'),
        nope('n'),
        { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }
    ]);
    e.add('hustle', 0, 'stable');
    const first = e.add('u', 0, 'hand');
    const second = e.add('v', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, first).error, undefined);
    const firstEntry = e.entryId();
    assert.equal(e.play(0, second).error, undefined);
    const secondEntry = e.entryId();

    assert.equal(e.neigh(1, counter, firstEntry).error, 'That play is no longer the latest');
    assert.equal(e.neigh(1, counter, secondEntry).error, undefined);
    assertInvariant(e.state);
});

test('a player cannot neigh their own play', () => {
    const e = env([unicorn('u'), nope('n')]);
    const played = e.add('u', 0, 'hand');
    const counter = e.add('n', 0, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(0, counter, e.entryId()).error, 'You cannot neigh your own card');
});

test('an immune play cannot be neighed', () => {
    const e = env([{ id: 'rock', kind: 'basic', unneighable: true }, nope('n')]);
    const played = e.add('rock', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(1, counter, e.entryId()).error, 'That card cannot be neighed');
});

test('a super neigh cannot be neighed back', () => {
    const e = env([unicorn('u'), nope('n'), nope('super', { instant: { neigh: true, superNeigh: true } })], 4);
    const played = e.add('u', 0, 'hand');
    const first = e.add('n', 1, 'hand');
    const second = e.add('n', 2, 'hand');
    const counter = e.add('super', 3, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(1, first, e.entryId()).error, undefined);
    assert.equal(e.neigh(3, counter, e.entryId()).error, undefined);
    assert.equal(e.neigh(2, second, e.entryId()).error, 'That card cannot be neighed');
});

test('neighing a neigh puts the original play back', () => {
    const e = env([spell('drawer', drawOne), nope('n'), unicorn('u'), unicorn('v')], 4);
    const played = e.add('drawer', 0, 'hand');
    const drawn = e.add('u', 0, 'deck');
    e.add('v', 0, 'deck');
    const first = e.add('n', 1, 'hand');
    const second = e.add('n', 2, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(1, first, e.entryId()).error, undefined);
    assert.deepEqual(e.state.players[0].hand, []);

    assert.equal(e.neigh(2, second, e.entryId()).error, undefined);
    assert.deepEqual(e.state.players[0].hand, [drawn]);
    assert.equal(e.state.turn.actionsUsed, 1);
    assertInvariant(e.state);
});

test('three deep neighbours return to the rolled back state', () => {
    const e = env([spell('drawer', drawOne), nope('n'), unicorn('u'), unicorn('v')], 4);
    const played = e.add('drawer', 0, 'hand');
    e.add('u', 0, 'deck');
    e.add('v', 0, 'deck');
    const first = e.add('n', 1, 'hand');
    const second = e.add('n', 2, 'hand');
    const third = e.add('n', 3, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.neigh(1, first, e.entryId()).error, undefined);
    assert.equal(e.neigh(2, second, e.entryId()).error, undefined);
    assert.equal(e.neigh(3, third, e.entryId()).error, undefined);

    assert.deepEqual(e.state.players[0].hand, []);
    assert.equal(e.state.turn.actionsUsed, 1);
    assertInvariant(e.state);
});

test('a neigh cancels an open prompt', () => {
    const e = env([spell('chooser', destroyOwn), nope('n'), unicorn('u'), unicorn('v')]);
    const played = e.add('chooser', 0, 'hand');
    const one = e.add('u', 0, 'stable');
    const two = e.add('v', 0, 'stable');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.ok(e.state.prompt);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.prompt, null);
    assert.deepEqual([...e.state.players[0].stable].sort(), [one, two].sort());
    assertInvariant(e.state);
});

test('a rollback does not rewind the rng', () => {
    const e = env([spell('reshuffle', drawOne), nope('n'), unicorn('u'), unicorn('w')]);
    const played = e.add('reshuffle', 0, 'hand');
    e.add('u', 0, 'discard');
    e.add('w', 0, 'discard');
    const counter = e.add('n', 1, 'hand');

    const before = e.table.ex.rng.s;
    assert.equal(e.play(0, played).error, undefined);
    const after = e.table.ex.rng.s;
    assert.notEqual(after, before);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.table.ex.rng.s, after);
});

test('commit confirms a pending winner and clears the stack', () => {
    const e = env([unicorn('u'), { ...unicorn('v') }]);
    e.state.winTarget = 1;
    e.add('u', 0, 'stable');
    e.state.pendingWinner = 0;
    e.table.stack.push({
        card: 'c0',
        by: 0,
        kind: 'play',
        actionCost: 1,
        immune: false,
        before: e.state
    });

    commitChain(e.table);

    assert.equal(e.state.winner, 0);
    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.table.stack.size, 0);
});

test('commit without a pending winner leaves the game running', () => {
    const e = env([unicorn('u')]);
    e.add('u', 0, 'stable');
    e.table.stack.push({
        card: 'c0',
        by: 0,
        kind: 'play',
        actionCost: 1,
        immune: false,
        before: e.state
    });

    commitChain(e.table);

    assert.equal(e.state.winner, null);
    assert.equal(e.state.phase, 'ACTION');
    assert.equal(e.table.stack.size, 0);
});

test('neighing the second unicorn of a turn leaves the first in place', () => {
    const e = env([
        unicorn('u'),
        unicorn('m'),
        nope('n'),
        { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }
    ]);
    e.add('hustle', 0, 'stable');
    const first = e.add('u', 0, 'hand');
    const second = e.add('m', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, first).error, undefined);
    const firstEntry = e.entryId();
    assert.equal(e.play(0, second).error, undefined);
    e.play(0, second);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.cards[first].zone, 'stable');
    assert.equal(e.state.cards[second].zone, 'discard');
    assert.equal(e.state.players[0].stable.includes(first), true);
    assert.equal(e.state.players[0].stable.includes(second), false);
    assert.equal(e.neigh(1, counter, firstEntry).error, 'That play is no longer the latest');
    assertInvariant(e.state);
});

test('a neighed winning play does not win the game', () => {
    const e = env([unicorn('u'), nope('n')]);
    e.state.winTarget = 2;
    e.state.turn.actionsUsed = 0;
    e.add('u', 0, 'stable');
    const played = e.add('u', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.pendingWinner, 0);
    assert.equal(e.state.winner, null);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.pendingWinner, null);
    assert.equal(e.state.winner, null);
    assert.equal(e.state.phase, 'ACTION');
    assertInvariant(e.state);
});

test('a rollback keeps the cards the neighed play revealed', () => {
    const e = env([
        spell('snatch', prim({ p: 'stealRandom', sel: sel('hand', 'other', 1) })),
        nope('n'),
        unicorn('u')
    ]);
    const played = e.add('snatch', 0, 'hand');
    const victim = e.add('u', 1, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.cards[victim].revealedTo.includes(0), true);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.cards[victim].zone, 'hand');
    assert.equal(e.state.cards[victim].revealedTo.includes(0), true);
    assertInvariant(e.state);
});

test('a neigh after ending a turn restores the action and lets it be redone', () => {
    const e = env([unicorn('u'), nope('n'), { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }]);
    e.add('hustle', 0, 'stable');
    const first = e.add('u', 0, 'hand');
    const second = e.add('u', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, first).error, undefined);
    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);

    assert.equal(e.state.phase, 'ACTION');
    assert.equal(e.state.turn.actionsUsed, 1);
    assert.equal(e.play(0, second).error, undefined);
    assert.equal(e.state.cards[second].zone, 'stable');
    assertInvariant(e.state);
});

test('playing a second card commits the first play', () => {
    const e = env([
        unicorn('u'),
        unicorn('m'),
        nope('n'),
        { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }
    ]);
    e.add('hustle', 0, 'stable');
    const first = e.add('u', 0, 'hand');
    const second = e.add('m', 0, 'hand');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, first).error, undefined);
    assert.equal(e.table.stack.size, 1);
    assert.equal(e.play(0, second).error, undefined);
    assert.equal(e.table.stack.size, 1);
    assert.equal(e.table.stack.top()?.card, second);

    assert.equal(e.neigh(1, counter, e.entryId()).error, undefined);
    assert.equal(e.state.cards[first].zone, 'stable');
    assert.equal(e.state.cards[second].zone, 'discard');
    assertInvariant(e.state);
});

test('a bonus card play does not permit an extra draw', () => {
    const e = env([
        unicorn('u'),
        nope('n'),
        unicorn('w'),
        { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }
    ]);
    e.add('hustle', 0, 'stable');
    const played = e.add('u', 0, 'hand');
    e.add('w', 0, 'deck');
    const counter = e.add('n', 1, 'hand');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.table.stack.size, 1);

    assert.equal(drawAction(e.table, 0).error, 'You have no draws left');
    assert.equal(e.table.stack.size, 1);
    assert.equal(e.neigh(1, counter, 1).error, undefined);
    assertInvariant(e.state);
});

test('a draw waits for a pending winner to resolve', () => {
    const e = env([
        unicorn('u'),
        unicorn('w'),
        { id: 'hustle', kind: 'upgrade', modifiers: [{ m: 'actionsPerTurn', value: 1 }] }
    ]);
    e.state.winTarget = 1;
    e.add('hustle', 0, 'stable');
    const played = e.add('u', 0, 'hand');
    e.add('w', 0, 'deck');

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.pendingWinner, 0);

    assert.equal(drawAction(e.table, 0).error, 'Let the current play resolve first');
    assert.equal(e.state.winner, null);
    assert.equal(e.state.phase, 'ACTION');
    commitChain(e.table);
    assert.equal(e.state.winner, 0);
    assert.equal(e.state.phase, 'OVER');
    assertInvariant(e.state);
});
