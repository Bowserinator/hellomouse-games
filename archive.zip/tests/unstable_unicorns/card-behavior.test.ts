import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BASE_CATALOG } from '../../client/unstable_unicorns/js/catalog/base.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import { moveCtxOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';
import { unicornCount } from '../../client/unstable_unicorns/js/engine/query/modifiers.js';
import { cardScene } from './scenarios.js';

function babiesScene() {
    const scene = cardScene();
    for (let seat = 0; seat < 3; seat++) scene.add('baby-unicorn-blue', seat, 'stable');
    return scene;
}

for (const card of BASE_CATALOG.filter(card => card.kind === 'baby')) {
    for (const cause of ['destroy', 'sacrifice', 'return'] as const) {
        test(`${card.id} returns only itself to the Nursery on ${cause}`, () => {
            const { engine, add } = cardScene();
            const baby = add(card.id, 0, 'stable');
            const unrelated = add('slowdown', 1, 'stable');
            const destination = cause === 'return' ? 'hand' : 'discard';
            assert.equal(moveCard(moveCtxOf(engine.ex), unrelated, destination, cause).moved, true);
            resolveLinks(engine.ex);
            assert.equal(engine.state.cards[unrelated].zone, destination);
            assert.equal(engine.state.cards[baby].zone, 'stable');
            assert.equal(moveCard(moveCtxOf(engine.ex), baby, destination, cause).moved, true);
            resolveLinks(engine.ex);
            assert.equal(engine.state.cards[baby].zone, 'nursery');
            assert.ok(engine.state.nursery.includes(baby));
            assert.equal(engine.state.prompt, null);
        });
    }
}

for (const card of BASE_CATALOG.filter(card => card.kind === 'basic' && card.unicornType !== 'special')) {
    test(`${card.id} can be played into its owners starting Stable`, () => {
        const { engine, add, act } = babiesScene();
        const basic = add(card.id);
        assert.ok(engine.view(0).playable.includes(basic));
        act({ type: 'PLAY_CARD', iid: basic });
        assert.equal(engine.state.cards[basic].zone, 'stable');
        assert.equal(engine.state.cards[basic].owner, 0);
        assert.equal(engine.state.players[0].stable.length, 2);
        assert.equal(engine.state.prompt, null);
    });
}

test('Starting Babies do not intercept Narwhal Torpedos Downgrade sacrifice', () => {
    const { engine, add, act } = babiesScene();
    const babies = engine.state.players.map(player => player.stable[0]);
    const downgrade = add('slowdown', 0, 'stable');
    const torpedo = add('narwhal-torpedo');
    act({ type: 'PLAY_CARD', iid: torpedo });
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.cards[downgrade].zone, 'discard');
    for (const baby of babies) assert.equal(engine.state.cards[baby].zone, 'stable');
});

test('Stabby can also destroy a Unicorn after being sacrificed for Two-for-one', () => {
    const { engine, add, act, answer } = cardScene();
    const stabby = add('stabby-the-unicorn', 0, 'stable');
    const victims = Array.from({ length: 3 }, () => add('basic-unicorn-blue', 1, 'stable'));
    const spell = add('two-for-one');
    act({ type: 'PLAY_CARD', iid: spell });
    assert.equal(engine.state.prompt?.kind, 'cards');
    answer(victims.slice(0, 2));
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.cards[stabby].zone, 'discard');
    for (const victim of victims) assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.prompt, null);
});

for (const [source, target] of [
    ['classy-narwhal', 'double-dutch'],
    ['shabby-the-narwhal', 'slowdown'],
    ['the-great-narwhal', 'narwhal-torpedo']
] as const) {
    test(`${source} searches only matching cards and shuffles after choosing`, () => {
        const { engine, add, act, answer } = babiesScene();
        const chosen = add(target, 0, 'deck');
        const alternative = add(target, 0, 'deck');
        const decoy = add('basic-unicorn-blue', 0, 'deck');
        const card = add(source);
        const before = engine.ex.rng.s;
        act({ type: 'PLAY_CARD', iid: card });
        answer(true);
        assert.equal(engine.state.prompt?.kind, 'cards');
        assert.deepEqual(new Set(engine.state.prompt!.cards), new Set([chosen, alternative]));
        answer([chosen]);
        assert.equal(engine.state.cards[chosen].zone, 'hand');
        assert.equal(engine.state.cards[alternative].zone, 'deck');
        assert.equal(engine.state.cards[decoy].zone, 'deck');
        assert.notEqual(engine.ex.rng.s, before);
        assert.equal(engine.state.prompt, null);
    });
}

test('Alluring Narwhal steals an Upgrade without taking an opposing Downgrade', () => {
    const { engine, add, act, answer } = babiesScene();
    const upgrade = add('double-dutch', 1, 'stable');
    const downgrade = add('slowdown', 1, 'stable');
    const alluring = add('alluring-narwhal');
    act({ type: 'PLAY_CARD', iid: alluring });
    answer(true);
    assert.equal(engine.state.cards[upgrade].owner, 0);
    assert.equal(engine.state.cards[upgrade].zone, 'stable');
    assert.equal(engine.state.cards[downgrade].owner, 1);
    assert.equal(engine.state.prompt, null);
});

for (const source of ['annoying-flying-unicorn', 'greedy-flying-unicorn', 'magical-flying-unicorn',
    'majestic-flying-unicorn', 'swift-flying-unicorn']) {
    for (const cause of ['destroy', 'sacrifice'] as const) {
        test(`${source} returns to its owners hand on ${cause}`, () => {
            const { engine, add } = babiesScene();
            const flying = add(source, 0, 'stable');
            moveCard(moveCtxOf(engine.ex), flying, 'discard', cause);
            resolveLinks(engine.ex);
            assert.equal(engine.state.cards[flying].zone, 'hand');
            assert.equal(engine.state.cards[flying].owner, 0);
            assert.equal(engine.state.prompt, null);
        });
    }
}

test('Rainbow Mane brings a Basic Unicorn from hand at the beginning of its owners turn', () => {
    const { engine, add, act, answer } = babiesScene();
    add('basic-unicorn-blue', 0, 'stable');
    add('rainbow-mane', 0, 'stable');
    const basic = add('basic-unicorn-green');
    const special = add('narwhal-torpedo');
    add('neigh', 0, 'deck');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    assert.equal(engine.state.prompt?.kind, 'yesno');
    answer(true);
    assert.equal(engine.state.cards[basic].zone, 'stable');
    assert.equal(engine.state.cards[special].zone, 'hand');
    assert.equal(engine.state.phase, 'ACTION');
});

for (const seat of [0, 1, 2]) {
    test(`Puppicorn moves to the player beginning turn ${seat}`, () => {
        const { engine, add, act } = babiesScene();
        const puppicorn = add('puppicorn', 0, 'stable');
        add('neigh', 0, 'deck');
        engine.state.turn.player = seat;
        engine.state.phase = 'AWAIT_BEGIN';
        act({ type: 'BEGIN_TURN' });
        assert.equal(engine.state.cards[puppicorn].owner, seat);
        assert.ok(engine.state.players[seat].stable.includes(puppicorn));
        assert.equal(engine.state.prompt, null);
    });
}

test('Rhinocorn skips the normal draw and Action phase after successful destruction', () => {
    const { engine, add, act, answer } = babiesScene();
    add('rhinocorn', 0, 'stable');
    const victim = add('basic-unicorn-blue', 1, 'stable');
    const undrawn = add('neigh', 0, 'deck');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    answer(true);
    answer([victim]);
    assert.equal(engine.state.cards[victim].zone, 'discard');
    assert.equal(engine.state.cards[undrawn].zone, 'deck');
    assert.equal(engine.state.turn.player, 1);
    assert.equal(engine.state.phase, 'AWAIT_BEGIN');
});

test('Unicorn Lassos end-turn return continues after Barbed Wire discard', () => {
    const { engine, add, act, answer } = babiesScene();
    add('unicorn-lasso', 0, 'stable');
    add('barbed-wire', 0, 'stable');
    const victim = add('basic-unicorn-green', 1, 'stable');
    const hand = Array.from({ length: 3 }, () => add('neigh'));
    add('neigh', 0, 'deck');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    answer(true);
    answer([victim]);
    answer([hand[0]]);
    assert.equal(engine.state.phase, 'ACTION');
    act({ type: 'END_TURN' });
    assert.equal(engine.state.cards[victim].owner, 1);
    assert.equal(engine.state.prompt?.kind, 'cards');
    answer([hand[1]]);
    assert.equal(engine.state.turn.player, 1);
    assert.equal(engine.state.phase, 'AWAIT_BEGIN');
});

test('Multiple Unicorn Lasso returns survive separate end-turn discard prompts', () => {
    const { engine, add, act, answer } = babiesScene();
    const lassos = [add('unicorn-lasso', 0, 'stable'), add('unicorn-lasso', 0, 'stable')];
    const wire = add('barbed-wire', 0, 'stable');
    const victims = [add('basic-unicorn-green', 1, 'stable'), add('basic-unicorn-blue', 2, 'stable')];
    const hand = Array.from({ length: 6 }, () => add('neigh'));
    add('neigh', 0, 'deck');
    engine.state.phase = 'AWAIT_BEGIN';
    act({ type: 'BEGIN_TURN' });
    let discarded = 0;
    for (let step = 0; step < 8 && engine.state.prompt; step++) {
        const prompt = engine.state.prompt;
        if (prompt.kind === 'yesno') answer(true);
        else if (prompt.source && lassos.includes(prompt.source)) {
            const victim = victims.find(iid => engine.state.cards[iid].owner !== 0);
            assert.ok(victim);
            answer([victim]);
        } else {
            assert.equal(prompt.source, wire);
            answer([hand[discarded++]]);
        }
    }
    for (const victim of victims) assert.equal(engine.state.cards[victim].owner, 0);
    act({ type: 'END_TURN' });
    for (let index = 0; index < 2; index++) {
        assert.equal(engine.state.prompt?.source, wire);
        answer([hand[discarded++]]);
    }
    assert.equal(engine.state.cards[victims[0]].owner, 1);
    assert.equal(engine.state.cards[victims[1]].owner, 2);
    assert.equal(engine.state.prompt, null);
    assert.equal(engine.state.turn.player, 1);
});

for (const source of ['slowdown', 'ginormous-unicorn']) {
    for (const instant of ['neigh', 'super-neigh']) {
        test(`${source} prevents its owner from playing ${instant}`, () => {
            const { engine, add, act } = babiesScene();
            add(source, 1, 'stable');
            const response = add(instant, 1);
            const basic = add('basic-unicorn-blue');
            act({ type: 'PLAY_CARD', iid: basic });
            assert.equal(engine.view(1).chain.canNeigh, false);
            assert.equal(engine.dispatch(1, { type: 'NEIGH', iid: response,
                targetEntryId: engine.stack.top()!.id }).ok, false);
            if (source === 'ginormous-unicorn')
                assert.equal(unicornCount({ state: engine.state, defOf: engine.ex.defOf }, 1), 3);
        });
    }
}

test('Broken Stable blocks an Upgrade but does not block a Basic Unicorn', () => {
    const { engine, add, act } = babiesScene();
    add('broken-stable', 0, 'stable');
    const upgrade = add('double-dutch');
    const basic = add('basic-unicorn-blue');
    assert.equal(engine.view(0).playable.includes(upgrade), false);
    assert.equal(engine.dispatch(0, { type: 'PLAY_CARD', iid: upgrade }).ok, false);
    assert.ok(engine.view(0).playable.includes(basic));
    act({ type: 'PLAY_CARD', iid: basic });
    assert.equal(engine.state.cards[basic].zone, 'stable');
});

test('Nanny Cam reveals only its owners hand to the other seats', () => {
    const { engine, add } = babiesScene();
    const visible = add('neigh', 0);
    const hidden = add('super-neigh', 2);
    assert.notEqual(engine.view(1).cards[visible]?.defId, 'neigh');
    add('nanny-cam', 0, 'stable');
    assert.equal(engine.view(1).cards[visible].defId, 'neigh');
    assert.notEqual(engine.view(1).cards[hidden]?.defId, 'super-neigh');
});

for (const instant of ['neigh', 'super-neigh']) {
    test(`${instant} cancels a played Basic Unicorn without moving starting Babies`, () => {
        const { engine, add, act } = babiesScene();
        const babies = engine.state.players.map(player => player.stable[0]);
        const basic = add('basic-unicorn-blue');
        const response = add(instant, 1);
        const counter = add('neigh');
        act({ type: 'PLAY_CARD', iid: basic });
        act({ type: 'NEIGH', iid: response, targetEntryId: engine.stack.top()!.id }, 1);
        assert.equal(engine.state.cards[basic].zone, 'discard');
        assert.equal(engine.state.cards[response].zone, 'discard');
        for (const baby of babies) assert.equal(engine.state.cards[baby].zone, 'stable');
        const result = engine.dispatch(0, { type: 'NEIGH', iid: counter, targetEntryId: engine.stack.top()!.id });
        assert.equal(result.ok, instant === 'neigh');
        if (result.ok) assert.equal(engine.state.cards[basic].zone, 'stable');
    });
}
