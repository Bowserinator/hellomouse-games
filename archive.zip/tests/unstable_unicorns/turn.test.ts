import { test } from 'node:test';
import assert from 'node:assert/strict';

import type { CardDef, Effect } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';
import { compileCard } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import type { NodeMap } from '../../client/unstable_unicorns/js/engine/dsl/compile.js';
import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import type { Iid } from '../../client/unstable_unicorns/js/engine/ids.js';
import { EventLog } from '../../client/unstable_unicorns/js/engine/events.js';
import { seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';
import type { ExecCtx } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { worldOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { PlayStack } from '../../client/unstable_unicorns/js/engine/stack.js';
import { playCard } from '../../client/unstable_unicorns/js/engine/play.js';
import type { Result, Table } from '../../client/unstable_unicorns/js/engine/play.js';
import { endByDeckOut } from '../../client/unstable_unicorns/js/engine/win.js';
import {
    actionsLeft, afterAction, beginTurn, discardCards, drawAction, drawsLeft, endTurn
} from '../../client/unstable_unicorns/js/engine/turn.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';
import { prim } from '../../client/unstable_unicorns/js/engine/dsl/builders.js';

interface Env {
    table: Table;
    state: GameState;
    add(defId: string, owner: number, zone: Zone): Iid;
    begin(player: number): Result;
    draw(player: number): Result;
    end(player: number): Result;
    play(player: number, iid: Iid): Result;
}

function env(
    defs: Array<CardDef>,
    playerCount = 3,
    winTarget = 7,
    names: Record<string, string> = {}
): Env {
    const state = emptyState(playerCount, winTarget);
    state.phase = 'AWAIT_BEGIN';
    const catalog = new Map(defs.map(def => [def.id, def]));
    const nodes: NodeMap = {};
    for (const def of defs) compileCard(def, nodes);
    const log = new EventLog();
    const stack = new PlayStack();
    const ex: ExecCtx = {
        state,
        nodes,
        log,
        rng: seedFrom('turn'),
        defOf: iid => catalog.get(state.cards[iid].defId),
        prompts: { n: 0 },
        custom: {},
        queue: pending => {
            state.links.next.push(pending);
        },
        deckOut: () => {
            endByDeckOut(state, worldOf(ex), defId => names[defId] ?? '', log);
            stack.clear();
        }
    };
    const table: Table = { state, stack, ex };
    let next = 0;
    const wrap = (result: Result): Result => {
        afterAction(table);
        assertInvariant(state);
        return result;
    };
    return {
        table,
        state,
        add(defId, owner, zone) {
            const iid = `c${next++}`;
            createCard(state, iid, defId, owner, zone);
            return iid;
        },
        begin(player) {
            return beginTurn(table, player);
        },
        draw(player) {
            return wrap(drawAction(table, player));
        },
        end(player) {
            return endTurn(table, player);
        },
        play(player, iid) {
            return wrap(playCard(table, player, iid));
        }
    };
}

const unicorn = (id: string): CardDef => ({ id, kind: 'basic' });
const spell = (id: string, onPlay: Effect): CardDef => ({ id, kind: 'magic', onPlay });

test('beginning a turn resets the actions and auto-draws one card', () => {
    const e = env([unicorn('u')]);
    e.add('u', 0, 'deck');
    e.state.turn.actionsUsed = 1;
    e.state.turn.drawsUsed = 1;

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.phase, 'ACTION');
    assert.deepEqual(e.state.players[0].hand.length, 1);
    assert.equal(e.state.turn.actionsUsed, 0);
    assert.equal(e.state.turn.drawsUsed, 0);
    assert.equal(actionsLeft(e.table, 0), 1);
    assert.equal(drawsLeft(e.table, 0), 1);
});

test('beginning a turn confirms the winner of the previous play', () => {
    const e = env([unicorn('u')], 3, 1);
    e.add('u', 0, 'stable');
    e.state.pendingWinner = 0;
    e.state.turn.player = 1;
    e.table.stack.push({
        card: 'c0',
        by: 0,
        kind: 'play',
        actionCost: 1,
        immune: false,
        before: e.state
    });

    assert.equal(e.begin(1).error, undefined);

    assert.equal(e.state.winner, 0);
    assert.equal(e.state.winReason, 'unicorns');
    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.table.stack.size, 0);
});

test('the action-phase draw spends the action', () => {
    const e = env([unicorn('u')]);
    e.add('u', 0, 'deck');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.state.players[0].hand.length, 1);
    assert.equal(e.draw(0).error, undefined);
    assert.equal(e.state.players[0].hand.length, 2);
    assert.equal(e.state.turn.actionsUsed, 1);
    assert.equal(e.state.turn.drawsUsed, 1);
    assert.equal(actionsLeft(e.table, 0), 0);
    assert.equal(drawsLeft(e.table, 0), 0);
    assert.equal(e.draw(0).error, 'You have no draws left');
});

test('the draw is unavailable once the action card is played', () => {
    const e = env([unicorn('u')]);
    const card = e.add('u', 0, 'hand');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.play(0, card).error, undefined);
    assert.equal(e.state.turn.actionsUsed, 1);
    assert.equal(drawsLeft(e.table, 0), 0);
    assert.equal(e.draw(0).error, 'You have no draws left');
    assert.equal(e.end(0).error, undefined);
});

test('playing after drawing fails because the action is spent', () => {
    const e = env([unicorn('u')]);
    const card = e.add('u', 0, 'hand');
    e.add('u', 0, 'deck');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.draw(0).error, undefined);
    assert.equal(e.play(0, card).error, 'You have no actions left');
    assert.equal(e.state.players[0].stable.length, 0);
});

test('a required draw from an exhausted deck ends the game by unicorn count', () => {
    const e = env([unicorn('u')]);
    e.add('u', 0, 'stable');
    e.add('u', 0, 'stable');
    e.add('u', 1, 'stable');
    e.add('u', 2, 'stable');

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.state.winner, 0);
    assert.equal(e.state.winReason, 'most');
    assert.equal(e.table.stack.size, 0);
});

test('a deck-out tie is broken by unicorn name letters', () => {
    const e = env([unicorn('tiny'), unicorn('lengthy')], 3, 7, {
        tiny: 'Tiny Unicorn',
        lengthy: 'Extremely Long Named Unicorn'
    });
    e.add('tiny', 0, 'stable');
    e.add('lengthy', 1, 'stable');
    e.add('u', 2, 'stable');

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.state.winner, 1);
    assert.equal(e.state.winReason, 'letters');
});

test('a deck-out letter tie means everyone loses', () => {
    const e = env([unicorn('tiny'), unicorn('tinier')], 3, 7, {
        tiny: 'Tiny Unicorn',
        tinier: 'Unicorn Tiny'
    });
    e.add('tiny', 0, 'stable');
    e.add('tinier', 1, 'stable');
    e.add('tinier', 2, 'stable');

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.state.winner, null);
    assert.equal(e.state.winReason, 'allLose');
});

test('a deck-out honors a pending winner', () => {
    const e = env([unicorn('u')], 3, 7);
    e.add('u', 0, 'stable');
    e.state.pendingWinner = 1;
    e.state.turn.player = 0;

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.phase, 'OVER');
    assert.equal(e.state.winner, 1);
    assert.equal(e.state.winReason, 'unicorns');
    assert.equal(e.state.pendingWinner, null);
});

test('a second card cannot be played without another action', () => {
    const e = env([unicorn('u'), unicorn('v')]);
    const first = e.add('u', 0, 'hand');
    const second = e.add('v', 0, 'hand');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.play(0, first).error, undefined);
    assert.equal(e.play(0, second).error, 'You have no actions left');
});

test('a full hand has to be discarded before the next turn starts', () => {
    const e = env([unicorn('u')]);
    const cards: Array<Iid> = [];
    for (let i = 0; i < 8; i++) cards.push(e.add('u', 0, 'hand'));
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.state.players[0].hand.length, 9);
    assert.equal(e.end(0).error, undefined);
    assert.equal(e.state.phase, 'DISCARD_LIMIT');

    assert.equal(discardCards(e.table, 0, [cards[0], cards[1]]).error, undefined);
    assert.equal(e.state.phase, 'AWAIT_BEGIN');
    assert.equal(e.state.turn.player, 1);
    assert.equal(e.state.players[0].hand.length, 7);
});

test('discarding is checked against the hand', () => {
    const e = env([unicorn('u')]);
    const cards: Array<Iid> = [];
    for (let i = 0; i < 8; i++) cards.push(e.add('u', 0, 'hand'));
    e.add('u', 0, 'deck');
    e.begin(0);
    e.end(0);

    assert.equal(discardCards(e.table, 0, []).error, 'Pick at least one card');
    assert.equal(discardCards(e.table, 0, ['nope']).error, 'That card is not in your hand');
    assert.equal(discardCards(e.table, 0, [cards[0]]).error, undefined);
    assert.equal(e.state.phase, 'DISCARD_LIMIT');
    assert.equal(discardCards(e.table, 1, [cards[0]]).error, 'It is not your turn');
    assert.equal(discardCards(e.table, 0, [cards[1]]).error, undefined);
    assert.equal(e.state.phase, 'AWAIT_BEGIN');
});

test('an extra turn returns to the same player', () => {
    const e = env([spell('again', prim({ p: 'takeExtraTurn' })), unicorn('u')]);
    const played = e.add('again', 0, 'hand');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.turn.extraTurns, 1);

    assert.equal(e.end(0).error, undefined);
    assert.equal(e.state.turn.player, 0);
    assert.equal(e.state.phase, 'AWAIT_BEGIN');
});

test('ending the turn now skips the rest of the action loop', () => {
    const e = env([spell('stop', prim({ p: 'endTurnNow' })), unicorn('u')]);
    const played = e.add('stop', 0, 'hand');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.play(0, played).error, undefined);

    assert.equal(e.state.phase, 'AWAIT_BEGIN');
    assert.equal(e.state.turn.player, 1);
});

test('turn start triggers draw their own cards', () => {
    const e = env([
        {
            id: 'watcher',
            kind: 'upgrade',
            triggers: [{ on: 'turnStart', when: { c: 'count', zone: 'hand', owner: 'self', cmp: 'lt', n: 1 }, effect: prim({ p: 'draw', count: 2 }) }]
        },
        unicorn('u')
    ]);
    e.add('watcher', 0, 'stable');
    for (let i = 0; i < 3; i++) e.add('u', 0, 'deck');

    assert.equal(e.begin(0).error, undefined);

    assert.equal(e.state.players[0].hand.length, 3);
});

test('a lingering effect runs at the end of the turn', () => {
    const e = env([spell('leech', prim({ p: 'addLingering', effect: prim({ p: 'draw', count: 1 }), until: 'endOfTurn' })), unicorn('u')]);
    const played = e.add('leech', 0, 'hand');
    e.add('u', 0, 'deck');
    e.add('u', 0, 'deck');
    e.begin(0);

    assert.equal(e.play(0, played).error, undefined);
    assert.equal(e.state.lingering.length, 1);

    assert.equal(e.end(0).error, undefined);
    assert.equal(e.state.lingering.length, 0);
    assert.equal(e.state.players[0].hand.length, 2);
});
