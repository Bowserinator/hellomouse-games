import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cardScene } from './scenarios.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import { moveCtxOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';
import { FLIGHT_MS, planFlights } from '../../client/unstable_unicorns/js/ui/flight-plan.js';
import type { LoggedEvent } from '../../client/unstable_unicorns/js/engine/events.js';
import type { Place } from '../../client/unstable_unicorns/js/engine/dsl/ast.js';

function movesOf(engine: ReturnType<typeof cardScene>['engine'], iid: string) {
    return engine.eventsSince(0).filter(event => event.card === iid && event.from && event.to);
}

test('moving a card records where it came from and where it went', () => {
    const { engine, add } = cardScene();
    const card = add('neigh', 1);
    moveCard(moveCtxOf(engine.ex), card, 'discard', 'discard');
    const [event] = movesOf(engine, card);
    assert.deepEqual(event.from, { zone: 'hand', owner: 1 });
    assert.deepEqual(event.to, { zone: 'discard' });
});

test('a temporary steal moves the card from the victim stable to the thief stable', () => {
    const { engine, add, act } = cardScene();
    const seductive = add('seductive-unicorn');
    const stolen = add('basic-unicorn-blue', 1, 'stable');
    act({ type: 'PLAY_CARD', iid: seductive });
    const steal = movesOf(engine, stolen).find(event => event.to?.zone === 'stable');
    assert.deepEqual(steal?.from, { zone: 'stable', owner: 1 });
    assert.deepEqual(steal?.to, { zone: 'stable', owner: 0 });

    moveCard(moveCtxOf(engine.ex), seductive, 'discard', 'destroy');
    resolveLinks(engine.ex);
    const back = movesOf(engine, stolen).at(-1);
    assert.deepEqual(back?.from, { zone: 'stable', owner: 0 });
    assert.deepEqual(back?.to, { zone: 'stable', owner: 1 });
});

test('swapping hands records every card crossing in both directions', () => {
    const { engine, add, act, answer } = cardScene();
    const own = add('neigh', 0);
    const other = add('super-neigh', 1);
    const bargain = add('unfair-bargain');
    act({ type: 'PLAY_CARD', iid: bargain });
    answer([1]);
    assert.deepEqual(movesOf(engine, own).at(-1)?.from, { zone: 'hand', owner: 0 });
    assert.deepEqual(movesOf(engine, own).at(-1)?.to, { zone: 'hand', owner: 1 });
    assert.deepEqual(movesOf(engine, other).at(-1)?.from, { zone: 'hand', owner: 1 });
    assert.deepEqual(movesOf(engine, other).at(-1)?.to, { zone: 'hand', owner: 0 });
});

test('Shake Up records the hand and discard going into the deck and the draws coming out', () => {
    const { engine, add, act } = cardScene();
    const oldHand = add('basic-unicorn-blue');
    const oldDiscard = add('basic-unicorn-green', 0, 'discard');
    const shake = add('shake-up');
    for (let i = 0; i < 6; i++) add('basic-unicorn-orange', 0, 'deck');
    act({ type: 'PLAY_CARD', iid: shake });

    assert.deepEqual(movesOf(engine, oldHand)[0].to, { zone: 'deck' });
    assert.deepEqual(movesOf(engine, oldDiscard)[0].from, { zone: 'discard' });
    assert.deepEqual(movesOf(engine, oldDiscard)[0].to, { zone: 'deck' });
    const draws = engine.eventsSince(0).filter(event => event.type === 'draw');
    assert.equal(draws.length, 5);
    for (const draw of draws) {
        assert.deepEqual(draw.from, { zone: 'deck' });
        assert.deepEqual(draw.to, { zone: 'hand', owner: 0 });
    }
});

test('a played magic card is recorded entering and leaving the play area', () => {
    const { engine, add, act } = cardScene();
    const card = add('good-deal');
    for (let i = 0; i < 4; i++) add('basic-unicorn-orange', 0, 'deck');
    act({ type: 'PLAY_CARD', iid: card });
    const [entering] = movesOf(engine, card);
    assert.deepEqual(entering.from, { zone: 'hand', owner: 0 });
    assert.deepEqual(entering.to, { zone: 'limbo' });
});

function step(iid: string, from: Place, to: Place, seq: number): LoggedEvent {
    return { type: 'move', card: iid, from, to, seq };
}

const HAND0: Place = { zone: 'hand', owner: 0 };
const HAND1: Place = { zone: 'hand', owner: 1 };
const DECK: Place = { zone: 'deck' };
const DISCARD: Place = { zone: 'discard' };

test('flight plan: ignores events without movement and moves that stay in place', () => {
    const plan = planFlights([
        { type: 'turnStart', player: 0, seq: 1 },
        { type: 'play', card: 'a', player: 0, seq: 2 },
        step('b', HAND0, HAND0, 3),
        step('c', HAND0, DISCARD, 4)
    ]);
    assert.deepEqual(plan.map(item => item.iid), ['c']);
});

test('flight plan: cards that move at the same time are staggered', () => {
    const plan = planFlights([step('a', DECK, HAND0, 1), step('b', DECK, HAND0, 2), step('c', DECK, HAND1, 3)]);
    assert.equal(plan[0].delay, 0);
    assert.ok(plan[1].delay > plan[0].delay);
    assert.ok(plan[2].delay > plan[1].delay);
});

test('flight plan: a card that moves twice flies each leg after the previous one lands', () => {
    const plan = planFlights([step('a', HAND0, DECK, 1), step('a', DECK, HAND0, 2), step('b', HAND1, DISCARD, 3)]);
    const legs = plan.filter(item => item.iid === 'a');
    assert.deepEqual(legs.map(item => [item.first, item.last]), [[true, false], [false, true]]);
    assert.ok(legs[1].delay >= legs[0].delay + FLIGHT_MS);
    const single = plan.find(item => item.iid === 'b');
    assert.deepEqual([single?.first, single?.last], [true, true]);
});

test('flight plan: large shuffles are capped instead of flooding the table', () => {
    const events = Array.from({ length: 60 }, (_, index) => step(`c${index}`, DISCARD, DECK, index + 1));
    const plan = planFlights(events);
    assert.ok(plan.length > 0);
    assert.ok(plan.length < 20);
    assert.ok(plan[plan.length - 1].delay <= 1800);
});

test('flight plan: a busy sync keeps every flight inside a bounded window', () => {
    const events = Array.from({ length: 30 }, (_, index) =>
        step(`c${index}`, DECK, index % 2 ? HAND0 : HAND1, index + 1));
    const plan = planFlights(events);
    assert.equal(plan.length, 24);
    assert.ok(plan[plan.length - 1].delay <= 1800);
});

test('dealing the opening hands records each card leaving the deck', async () => {
    const { Engine } = await import('../../client/unstable_unicorns/js/engine/engine.js');
    const { registry } = await import('./scenarios.js');
    const engine = new Engine({ registry, playerCount: 3, seed: 'deal-events' });
    const deals = engine.eventsSince(0).filter(event => event.type === 'move' &&
        event.from?.zone === 'deck' && event.to?.zone === 'hand');
    assert.equal(deals.length, engine.state.players.reduce((total, player) => total + player.hand.length, 0));
});
