import { test } from 'node:test';
import assert from 'node:assert/strict';

import { FakeElement, host, installDom } from './fake_dom.js';
import { ChainBanner } from '../../client/unstable_unicorns/js/ui/chain-banner.js';
import { showNeighWarning } from '../../client/unstable_unicorns/js/ui/flight.js';
import { CenterView } from '../../client/unstable_unicorns/js/ui/center.js';
import { ConfirmModal } from '../../client/unstable_unicorns/js/ui/confirm.js';
import { bindEffectToast, effectToast } from '../../client/unstable_unicorns/js/ui/effect-toast.js';
import { HandView, describeBlocker } from '../../client/unstable_unicorns/js/ui/hand.js';
import { PromptModal } from '../../client/unstable_unicorns/js/ui/prompt.js';
import { TargetModal, targetWarning } from '../../client/unstable_unicorns/js/ui/target-modal.js';
import type { Answer } from '../../client/unstable_unicorns/js/ui/prompt.js';
import { applyHint, hints } from '../../client/unstable_unicorns/js/ui/indicators.js';
import { seatElement, StatusTooltip } from '../../client/unstable_unicorns/js/ui/seat.js';
import { describeEvent } from '../../client/unstable_unicorns/js/ui/log.js';
import { cardEntry, cardFace, cardName } from '../../client/unstable_unicorns/js/ui/card.js';
import { config } from '../../client/unstable_unicorns/js/config.js';
import { mockView } from '../../client/unstable_unicorns/js/ui/mock.js';
import { catalogFor, packNames } from '../../client/unstable_unicorns/js/catalog/index.js';
import { WILDCARD } from '../../client/unstable_unicorns/js/vars.js';
import type { CardView, PromptView, ViewModel } from '../../client/unstable_unicorns/js/engine/view.js';

installDom();

const NAMES = ['alice', 'bob', 'carol'];

function view(overrides: Partial<ViewModel> = {}): ViewModel {
    const cards: Record<string, CardView> = {
        h1: { defId: 'neigh', owner: 0, zone: 'hand', revealed: false, neighable: true },
        h2: { defId: 'basic-unicorn-blue', owner: 0, zone: 'hand', revealed: false, neighable: false },
        s1: { defId: 'baby-unicorn-blue', owner: 0, zone: 'stable', revealed: true, neighable: false },
        t1: { defId: 'rainbow-aura', owner: 1, zone: 'stable', revealed: true, neighable: false },
        d1: { defId: 'good-deal', owner: 1, zone: 'discard', revealed: true, neighable: false },
        n1: { defId: 'baby-unicorn-blue', owner: -1, zone: 'nursery', revealed: true, neighable: false }
    };

    const base: ViewModel = {
        seat: 0,
        phase: 'ACTION',
        turn: { player: 0, actionsUsed: 0, actionsLeft: 1, drawsUsed: 0, drawsLeft: 1 },
        winTarget: 7,
        winner: null,
        winReason: null,
        over: false,
        pendingWinner: null,
        players: [
            { id: 0, handCount: 2, hand: ['h1', 'h2'], stable: ['s1'], babyChosen: true, unicorns: 1 },
            { id: 1, handCount: 3, hand: null, stable: ['t1'], babyChosen: true, unicorns: 1 },
            { id: 2, handCount: 0, hand: null, stable: [], babyChosen: true, unicorns: 0 }
        ],
        cards,
        deckCount: 42,
        discard: ['d1'],
        nursery: ['n1'],
        handLimit: 7,
        prompt: null,
        promptOpen: false,
        waitingOn: [0],
        chain: { top: null, canNeigh: false },
        playable: [],
        needsTarget: [],
        blockers: {},
        targets: {},
        futile: {},
        ...overrides
    };
    base.promptOpen = overrides.promptOpen ?? (overrides.prompt !== null && overrides.prompt !== undefined);
    return base;
}

function cardsPrompt(overrides: Partial<PromptView> = {}): PromptView {
    return {
        id: 1,
        player: 0,
        kind: 'cards',
        reason: 'Choose a card to discard',
        source: null,
        cards: ['h1', 'h2'],
        players: [],
        min: 1,
        max: 1,
        ...overrides
    } as PromptView;
}

function promptModal(): {
    modal: PromptModal;
    root: FakeElement;
    answers: Array<Answer>;
} {
    const overlay = new FakeElement('div');
    overlay.className = 'modal-darken';
    const body = new FakeElement('div');
    body.className = 'prompt-modal';
    overlay.append(body);
    const answers: Array<Answer> = [];
    const modal = new PromptModal(
        body as unknown as HTMLElement,
        answer => answers.push(answer),
        () => NAMES
    );
    return { modal, root: body, answers };
}

test('chain banner names the player and the card that is on the chain', () => {
    const root = host();
    const banner = new ChainBanner(root as unknown as HTMLElement);
    banner.render(
        view({ chain: { top: { id: 3, card: 't1', by: 1, kind: 'play' }, canNeigh: true }, pendingWinner: 1 }),
        NAMES
    );
    assert.equal(root.dataset.state, 'chain');
    assert.equal(root.byClass('banner-title')?.textContent, 'bob played');
    assert.equal(root.byClass('banner-card')?.textContent, 'Rainbow Aura');
    assert.equal(root.byClass('banner-card')?.dataset.iid, 't1');
    assert.equal(root.byClass('banner-card')?.dataset.defId, 'rainbow-aura');
    assert.equal(root.byClass('banner-hint')?.textContent, 'Neigh to undo it');
    assert.equal(root.byClass('banner-warn')?.textContent, 'bob wins unless neighed');
});

test('a hidden chain card does not offer a face preview', () => {
    const root = host();
    const cards = view().cards;
    new ChainBanner(root as unknown as HTMLElement).render(view({
        cards: { ...cards, t1: { ...cards.t1, defId: WILDCARD } },
        chain: { top: { id: 4, card: 't1', by: 1, kind: 'play' }, canNeigh: true }
    }), NAMES);
    assert.equal(root.byClass('banner-card')?.dataset.iid, undefined);
});

test('a played card remains named and previewable after entering the hidden deck', () => {
    const root = host();
    new ChainBanner(root as unknown as HTMLElement).render(view({
        cards: {},
        chain: { top: { id: 5, card: 't1', by: 1, kind: 'play', publicDefId: 'rainbow-aura' },
            canNeigh: true }
    }), NAMES);
    assert.equal(root.byClass('banner-card')?.textContent, 'Rainbow Aura');
    assert.equal(root.byClass('banner-card')?.dataset.defId, 'rainbow-aura');
    assert.equal(root.byClass('banner-card')?.dataset.iid, 't1');
});

test('Neigh warning names both players and the original card', () => {
    const root = host();
    showNeighWarning(root as unknown as HTMLElement, 'alice', 'bob', 'Rainbow Aura');
    const warning = root.byClass('neigh-warning');
    assert.equal(warning?.getAttribute('role'), 'alert');
    assert.equal(warning?.children[0]?.textContent, 'NEIGH!');
    assert.equal(warning?.children[1]?.textContent, "alice NEIGHED bob's Rainbow Aura");
    showNeighWarning(root as unknown as HTMLElement, 'carol', 'alice', 'Baby Unicorn', true);
    assert.equal(root.byClass('neigh-warning')?.children[0]?.textContent, 'SUPER NEIGH!');
    showNeighWarning(root as unknown as HTMLElement, 'carol', 'alice', 'Baby Unicorn');
    assert.equal(root.all(node => node.classList.contains('neigh-warning')).length, 1);
});

test('chain banner is silent about neighing when the chain cannot be neighed', () => {
    const root = host();
    const banner = new ChainBanner(root as unknown as HTMLElement);
    banner.render(view({ chain: { top: { id: 4, card: 't1', by: 1, kind: 'play' }, canNeigh: false } }), NAMES);
    assert.equal(root.byClass('banner-hint'), null);
});

test('chain banner shows the phase, who we wait for, and the actions left', () => {
    const root = host();
    const banner = new ChainBanner(root as unknown as HTMLElement);
    banner.render(view({ waitingOn: [0, 1, 2] }), NAMES);
    assert.equal(root.dataset.state, 'plain');
    assert.equal(root.byClass('banner-title')?.textContent, 'Action phase');
    assert.equal(root.byClass('banner-hint')?.textContent, 'Waiting on bob, carol');
    const waiting = view({ waitingOn: [0],
        turn: { player: 0, actionsUsed: 1, actionsLeft: 0, drawsUsed: 0, drawsLeft: 1 } });
    banner.render(waiting, NAMES);
    assert.equal(root.byClass('banner-hint')?.textContent, '0 actions left');
});

test('chain banner announces the winner', () => {
    const root = host();
    const banner = new ChainBanner(root as unknown as HTMLElement);
    banner.render(view({ winner: 2 }), NAMES);
    assert.equal(root.dataset.state, 'over');
    assert.equal(root.byClass('banner-title')?.textContent, 'carol wins!');
});

test('center piles show their counts and let you begin your turn', () => {
    const root = host();
    const center = new CenterView(root as unknown as HTMLElement);
    center.render(view({ phase: 'AWAIT_BEGIN' }));
    const counts = root.all(node => node.classList.contains('pile-count')).map(node => node.textContent);
    assert.deepEqual(counts, ['42', '1', '1']);
    assert.equal(center.deck.classList.contains('empty'), false);

    assert.equal(root.all(node => node.classList.contains('deck-card')).length, 1);
    assert.equal(root.all(node => node.classList.contains('deck-layer')).length, 0);
    assert.equal((center.deck.style as unknown as Record<string, string>)['--layer-max'], '41');

    center.render(view({ phase: 'ACTION', deckCount: 0 }));
    assert.equal(center.deck.classList.contains('empty'), true);
    assert.equal(root.all(node => node.classList.contains('deck-card')).length, 1);
    assert.equal((center.deck.style as unknown as Record<string, string>)['--layer-max'], '0');

    center.render(view({ deckCount: 1 }));
    assert.equal((center.deck.style as unknown as Record<string, string>)['--layer-max'], '0');
    center.render(view({ deckCount: 100 }));
    assert.equal((center.deck.style as unknown as Record<string, string>)['--layer-max'], '47');

    center.setDrawCue(true);
    assert.equal(center.deck.dataset.draw, 'true');
    assert.equal(root.byClass('draw-cue')?.hidden, false);
    assert.equal(root.byClass('draw-cue-label')?.textContent, 'DRAW A CARD');
    assert.equal(root.byClass('draw-bar'), null);
    center.setDrawCue(false);
    assert.equal(center.deck.dataset.draw, 'false');
    assert.equal(root.byClass('draw-cue')?.hidden, true);

    center.setDrawAvailable(false);
    assert.equal(center.deck.dataset.available, 'false');
    assert.equal(center.deck.getAttribute('aria-disabled'), 'true');
    center.setDrawAvailable(true);
    assert.equal(center.deck.dataset.available, 'true');
    assert.equal(center.deck.getAttribute('aria-disabled'), 'false');

    const stacked = view({ discard: ['d1', 'd2', 'd3'] });
    stacked.cards.d2 = { defId: 'neigh', owner: 1, zone: 'discard', revealed: true, neighable: false };
    stacked.cards.d3 = { defId: 'basic-unicorn-blue', owner: 2, zone: 'discard', revealed: true, neighable: false };
    center.render(stacked);
    const discard = root.byClass('discard');
    assert.equal((discard?.style as unknown as Record<string, string>)['--layer-max'], '2');
    assert.equal(root.all(node => node.classList.contains('discard-layer') && !node.hidden).length, 2);
});

test('center shows the top card of the discard pile and the nursery', () => {
    const root = host();
    const center = new CenterView(root as unknown as HTMLElement);
    center.render(view({ phase: 'PICK_BABY' }));
    const nursery = root.byClass('nursery');
    assert.ok(nursery);
    assert.equal(nursery.byClass('card-slot')?.dataset.iid, 'n1');
    const discard = root.byClass('discard');
    assert.ok(discard);
    assert.ok(discard.byIid('d1'));
});

test('Nanny Cam exposes an opponents card faces in their seat hand', () => {
    const shown = view();
    shown.players[1].hand = ['o1'];
    shown.players[1].handCount = 1;
    shown.cards.o1 = { defId: 'neigh', owner: 1, zone: 'hand', revealed: true, neighable: true };
    const node = seatElement({
        view: shown, names: NAMES, connected: [true, true, true], selectedTarget: null,
        radius: 360, cardW: 130
    }, 1, { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never) as unknown as FakeElement;
    const hand = node.byClass('seat-hand');
    assert.equal(hand?.getAttribute('aria-hidden'), null);
    assert.equal(hand?.byIid('o1')?.byClass('card-name')?.textContent, 'Neigh');
    assert.equal(hand?.all(child => child.classList.contains('card-back')).length, 0);
});

test('the mock table reveals the hand of its Nanny Cam player', () => {
    const mocked = mockView(4, 0);
    const nannyCamSeat = mocked.players[3];
    const nannyCam = nannyCamSeat.stable.find(iid => mocked.cards[iid]?.defId === 'nanny-cam');
    assert.ok(nannyCam);
    const revealedCard = nannyCamSeat.hand?.[0];
    assert.ok(revealedCard);

    const info = {
        view: mocked, names: [...NAMES, 'dave'], connected: [true, true, true, true], selectedTarget: null,
        radius: 360, cardW: 130
    };
    const shown = seatElement(info, 3, { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never) as unknown as FakeElement;
    assert.equal(shown.byClass('seat-hand')?.getAttribute('aria-hidden'), null);
    assert.ok(shown.byClass('seat-hand')?.byIid(revealedCard));

    const hidden = seatElement(info, 2, { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never) as unknown as FakeElement;
    assert.equal(hidden.byClass('seat-hand')?.getAttribute('aria-hidden'), 'true');
});

test('mock Stable totals use the same Panda rule as live games', () => {
    const mocked = mockView(5, 0);
    assert.equal(mocked.players[0].unicorns, 3);
    assert.ok(mocked.players[4].stable.some(iid => mocked.cards[iid]?.defId === 'pandamonium'));
    assert.equal(mocked.players[4].unicorns, 0);
    const panel = seatElement({
        view: mocked, names: [...NAMES, 'dave', 'erin'], connected: Array(5).fill(true),
        selectedTarget: null, radius: 360, cardW: 130
    }, 4, { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never) as unknown as FakeElement;
    assert.equal(panel.byClass('seat-unicorns')?.textContent, `0/${mocked.winTarget}`);
});

test('a seat panel shows its name, unicorns, hand size and turn badge', () => {
    const node = seatElement(
        {
            view: view(), names: NAMES, connected: [true, false, true], selectedTarget: null,
            radius: 360, cardW: 130
        },
        1,
        { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never
    ) as unknown as FakeElement;
    assert.equal(node.classList.contains('active'), false);
    assert.equal(node.classList.contains('bottom'), false);
    assert.equal(node.byClass('seat-name')?.textContent, 'bob');
    assert.equal(node.byClass('seat-unicorns')?.textContent, '1/7');
    assert.equal(node.byClass('seat-hand-count')?.textContent, '3 in hand');
    assert.equal(node.byClass('seat-badge')?.textContent, 'Offline');
    assert.equal(node.dataset.hand, '3');
    const hand = node.byClass('seat-hand');
    assert.equal(hand?.getAttribute('aria-hidden'), 'true');
    assert.equal(hand?.dataset.count, '3');
    assert.equal(hand?.all(child => child.classList.contains('card-back')).length, 3);
});

test('the turn player and the picked target are marked on their seat', () => {
    const node = seatElement(
        {
            view: view(), names: NAMES, connected: [true, true, true], selectedTarget: 0,
            radius: 360, cardW: 130
        },
        0,
        { anchor: { x: 0, y: 300 }, rotationDeg: 0 } as never
    ) as unknown as FakeElement;
    assert.equal(node.classList.contains('active'), true);
    assert.equal(node.classList.contains('targeted'), true);
    assert.equal(node.classList.contains('bottom'), true);
    assert.equal(node.classList.contains('mine'), true);
    assert.equal(node.byClass('seat-badge')?.textContent, 'Turn');
});

function statusView(): ViewModel {
    return view({
        cards: {
            ...view().cards,
            u1: { defId: 'rainbow-aura', owner: 2, zone: 'stable', revealed: true, neighable: false },
            g1: { defId: 'slowdown', owner: 2, zone: 'stable', revealed: true, neighable: false }
        },
        players: [
            { id: 0, handCount: 2, hand: ['h1', 'h2'], stable: ['s1'], babyChosen: true, unicorns: 1 },
            { id: 1, handCount: 3, hand: null, stable: ['t1'], babyChosen: true, unicorns: 1 },
            { id: 2, handCount: 0, hand: null, stable: ['u1', 'g1'], babyChosen: true, unicorns: 2 }
        ]
    });
}

test('a seat lists upgrade and downgrade effects under the name with tooltips', () => {
    const node = seatElement(
        {
            view: statusView(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            radius: 360, cardW: 130
        },
        2,
        { anchor: { x: 0, y: 300 }, rotationDeg: 0 } as never
    ) as unknown as FakeElement;
    const plateHost = node.byClass('seat-plate-host');
    assert.ok(plateHost);
    assert.equal(plateHost.children[0].classList.contains('seat-plate'), true);
    assert.equal(plateHost.children[1].classList.contains('seat-status'), true);
    const items = plateHost.children[1].all(child => child.tagName === 'li');
    assert.equal(items.length, 2);
    assert.equal(items[0].textContent, '▲ Rainbow Aura');
    assert.equal(items[0].className, 'upgrade');
    assert.equal(items[0].dataset.tip, 'Your Unicorn cards cannot be destroyed.');
    assert.equal(items[1].textContent, '▼ Slowdown');
    assert.equal(items[1].className, 'downgrade');
    assert.equal(items[1].dataset.tip, 'You cannot play Instant cards.');
});

test('an upside-down seat flips its plate and keeps the status furthest from the table', () => {
    const node = seatElement(
        {
            view: statusView(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            radius: 360, cardW: 130
        },
        2,
        { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never
    ) as unknown as FakeElement;
    const plateHost = node.byClass('seat-plate-host');
    assert.ok(plateHost);
    assert.equal(plateHost.style.transform, 'rotate(180deg)');
    assert.equal(plateHost.children[0].classList.contains('seat-status'), true);
    assert.equal(plateHost.children[1].classList.contains('seat-plate'), true);
    const vertical = seatElement(
        {
            view: statusView(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            radius: 360, cardW: 130
        },
        2,
        { anchor: { x: 300, y: 0 }, rotationDeg: 90 } as never
    ) as unknown as FakeElement;
    const verticalHost = vertical.byClass('seat-plate-host');
    assert.ok(verticalHost);
    assert.equal(verticalHost.style.transform, undefined);
    assert.equal(verticalHost.children[0].classList.contains('seat-plate'), true);
    assert.equal(verticalHost.children[1].classList.contains('seat-status'), true);

    const angled = seatElement(
        {
            view: statusView(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            radius: 360, cardW: 130
        },
        2,
        { anchor: { x: 300, y: -200 }, rotationDeg: 120 } as never
    ) as unknown as FakeElement;
    const angledHost = angled.byClass('seat-plate-host');
    assert.ok(angledHost);
    assert.equal(angledHost.style.transform, 'rotate(180deg)');
});

test('the status tooltip puts its top-left corner at the pointer', () => {
    const root = host();
    const tooltip = new StatusTooltip(root as unknown as HTMLElement);
    const node = root.byClass('status-tooltip');
    assert.ok(node);
    assert.equal(node.hidden, true);

    tooltip.show('Your unicorns cannot be destroyed.', 123, 45);
    assert.equal(node.textContent, 'Your unicorns cannot be destroyed.');
    assert.equal(node.style.left, '123px');
    assert.equal(node.style.top, '45px');
    assert.equal(node.style.transform, undefined);
    assert.equal(node.hidden, false);

    tooltip.hide();
    assert.equal(node.hidden, true);
});

test('effect notifications show Magical Unicorn entry text without duplicating its play event', () => {
    const root = host();
    const model = view();
    model.cards.greedy = {
        defId: 'greedy-flying-unicorn', owner: 0, zone: 'stable', revealed: true, neighable: false
    };
    bindEffectToast(root as unknown as HTMLElement);
    effectToast({ seq: 1, type: 'enterStable', card: 'greedy', player: 0 }, model, NAMES);
    assert.equal(root.hidden, false);
    assert.equal(root.children[0]?.textContent, "Greedy Flying Unicorn entered alice's Stable");
    assert.equal(root.children[1]?.textContent, cardEntry('greedy-flying-unicorn')?.text);

    effectToast({ seq: 2, type: 'play', card: 'greedy', player: 0 }, model, NAMES);
    effectToast({ seq: 3, type: 'enterStable', card: 'h2', player: 0 }, model, NAMES);
    assert.equal(root.children[0]?.textContent, "Greedy Flying Unicorn entered alice's Stable");
    effectToast({ seq: 4, type: 'play', card: 'hidden', publicDefId: 'good-deal', player: 1 }, model, NAMES);
    assert.equal(root.children[0]?.textContent, 'bob played Good Deal');
});

test('the hand fans the own cards out and marks the legal ones', () => {
    const root = host();
    const hand = new HandView(root as unknown as HTMLElement);
    hand.render(view({ playable: ['h2'] }), { selected: 'h1', picks: [], noActions: false });
    assert.equal(root.dataset.count, '2');
    const first = root.byIid('h1');
    const second = root.byIid('h2');
    assert.ok(first && second);
    assert.equal(first.classList.contains('hand-card'), true);
    assert.equal(first.classList.contains('selected'), true);
    assert.equal(second.classList.contains('playable'), true);
    assert.equal(first.style['--fan-deg'], '-2.00deg');
    assert.equal(second.style['--fan-deg'], '2.00deg');

    hand.render(view({ playable: [], players: [
        { id: 0, handCount: 1, hand: ['h2'], stable: ['s1'], babyChosen: true, unicorns: 1 },
        { id: 1, handCount: 3, hand: null, stable: ['t1'], babyChosen: true, unicorns: 1 },
        { id: 2, handCount: 0, hand: null, stable: [], babyChosen: true, unicorns: 0 }
    ] }), { selected: null, picks: [], noActions: false });
    assert.equal(root.dataset.count, '1');
    assert.equal(root.byIid('h1'), null);
});

test('the hand grays out when no action remains', () => {
    const root = host();
    const hand = new HandView(root as unknown as HTMLElement);
    hand.render(view({ playable: [] }), { selected: null, picks: [], noActions: false });
    assert.equal(root.classList.contains('no-actions'), false);
    hand.render(view({ playable: [] }), { selected: null, picks: [], noActions: true });
    assert.equal(root.classList.contains('no-actions'), true);
});

test('the hand dims while a prompt is open and marks neighable cards', () => {
    const root = host();
    const hand = new HandView(root as unknown as HTMLElement);
    hand.render(view({ chain: { top: { id: 9, card: 't1', by: 1, kind: 'play' }, canNeigh: true } }), { selected: null, picks: [], noActions: false });
    assert.equal(root.classList.contains('dimmed'), false);
    assert.equal(root.byIid('h1')?.classList.contains('neigh-ready'), true);

    hand.render(view({
        prompt: cardsPrompt(),
        chain: { top: { id: 9, card: 't1', by: 1, kind: 'play' }, canNeigh: true }
    }), { selected: null, picks: [], noActions: false });
    assert.equal(root.classList.contains('dimmed'), true);
    assert.equal(root.byIid('h1')?.classList.contains('neigh-ready'), true);
    assert.equal(root.byIid('h2')?.classList.contains('neigh-ready'), false);
});

test('blocked hand cards share click and hover reasons and clear stale tips', () => {
    const root = host();
    const hand = new HandView(root as unknown as HTMLElement);
    const model = view({ playable: ['h2'], blockers: { h1: 'That card can only be played in response' } });
    hand.render(model, { selected: null, picks: [], noActions: false });
    assert.equal(root.byIid('h1')?.classList.contains('blocked'), true);
    assert.equal(root.byIid('h1')?.dataset.tip, describeBlocker(model, 'h1'));
    assert.equal(root.byIid('h1')?.dataset.tip, model.blockers.h1);
    assert.equal(root.byIid('h2')?.classList.contains('blocked'), false);
    assert.equal(root.byIid('h2')?.dataset.tip, undefined);

    hand.render(view({ prompt: cardsPrompt() }), { selected: null, picks: [], noActions: false });
    assert.equal(root.byIid('h2')?.dataset.tip, 'Answer the open prompt first.');
    hand.render(view({ playable: ['h2'] }), { selected: null, picks: [], noActions: false });
    assert.equal(root.byIid('h2')?.dataset.tip, undefined);
});

test('blocked hand reasons explain turn, phase, and Neigh restrictions', () => {
    assert.equal(describeBlocker(view({ turn: { ...view().turn, player: 1 } }), 'h2'), 'It is not your turn.');
    assert.equal(describeBlocker(view({ phase: 'AWAIT_BEGIN' }), 'h2'), 'You cannot play that card now.');
    assert.equal(describeBlocker(view({
        chain: { top: { id: 9, card: 't1', by: 1, kind: 'play' }, canNeigh: false }
    }), 'h1'), 'That play cannot be neighed by you.');
});

test('the discard note counts the cards still to discard', () => {
    const hud = new FakeElement('div');
    hud.id = 'hud';
    const note = new FakeElement('span');
    note.className = 'hand-note';
    note.hidden = true;
    const hand = host();
    hud.append(hand, note);

    const view8 = view({
        phase: 'DISCARD_LIMIT',
        handLimit: 7,
        players: [
            { id: 0, handCount: 9, hand: ['h1', 'h2'], stable: ['s1'], babyChosen: true, unicorns: 1 },
            { id: 1, handCount: 3, hand: null, stable: ['t1'], babyChosen: true, unicorns: 1 },
            { id: 2, handCount: 0, hand: null, stable: [], babyChosen: true, unicorns: 0 }
        ]
    });
    new HandView(hand as unknown as HTMLElement).render(view8, { selected: null, picks: ['h1'], noActions: false });
    assert.equal(note.hidden, false);
    assert.equal(note.textContent, 'Discard 2 cards · 1 chosen');
});

test('hints tell the player the next step and highlight the deck or the end turn button', () => {
    assert.deepEqual(hints(view({ phase: 'AWAIT_BEGIN' })),
        {
            deck: 'animate', deckAvailable: true, endTurn: null,
            drawCue: true,
            noActions: false, banner: null
        });
    assert.deepEqual(hints(view({ playable: [] })),
        {
            deck: 'animate', deckAvailable: true, endTurn: 'animate',
            drawCue: true,
            noActions: false, banner: null
        });
    assert.deepEqual(hints(view({ playable: ['h1'] })),
        {
            deck: 'highlight', deckAvailable: true, endTurn: 'animate',
            drawCue: true,
            noActions: false, banner: null
        });
    assert.deepEqual(hints(view({ turn: { player: 1, actionsUsed: 0, actionsLeft: 1, drawsUsed: 0, drawsLeft: 1 } })),
        {
            deck: null, deckAvailable: false, endTurn: null,
            drawCue: false,
            noActions: false, banner: null
        });
});

test('hints announce exhausted actions and deck availability', () => {
    const spent = hints(view({
        turn: { player: 0, actionsUsed: 1, actionsLeft: 0, drawsUsed: 1, drawsLeft: 0 }
    }));
    assert.deepEqual(spent, {
        deck: null, deckAvailable: false, endTurn: 'animate',
        drawCue: false,
        noActions: true, banner: 'ALL ACTIONS USED UP'
    });

    const afterActionCard = hints(view({
        playable: [],
        turn: { player: 0, actionsUsed: 1, actionsLeft: 0, drawsUsed: 0, drawsLeft: 0 }
    }));
    assert.deepEqual(afterActionCard, {
        deck: null, deckAvailable: false, endTurn: 'animate',
        drawCue: false,
        noActions: true, banner: 'ALL ACTIONS USED UP'
    });

    const over = hints(view({ over: true, winner: null }));
    assert.equal(over.deck, null);
    assert.equal(over.deckAvailable, false);
    assert.equal(over.endTurn, null);
    assert.equal(over.drawCue, false);
    assert.equal(over.banner, null);

    const prompted = hints(view({ promptOpen: true, prompt: null, waitingOn: [1] }));
    assert.equal(prompted.endTurn, null);
    assert.equal(prompted.deckAvailable, false);
    assert.equal(prompted.drawCue, false);
    assert.equal(prompted.banner, null);

    const empty = hints(view({ deckCount: 0, discard: [], playable: [] }));
    assert.equal(empty.deckAvailable, false);
    assert.equal(empty.drawCue, false);
});

test('applying a hint sets and clears the data attribute', () => {
    const node = new FakeElement('button');
    applyHint(node as unknown as HTMLElement, 'animate');
    assert.equal(node.dataset.hint, 'animate');
    applyHint(node as unknown as HTMLElement, null);
    assert.equal(node.dataset.hint, undefined);
});

test('a card prompt groups the candidates and submits the picked cards', () => {
    const { modal, root, answers } = promptModal();
    modal.render(cardsPrompt(), view().cards);
    assert.equal(modal.isOpen, true);
    assert.equal(root.byClass('prompt-reason')?.textContent, 'Choose a card to discard');
    assert.equal(root.byIid('h1')?.getAttribute('role'), 'button');
    assert.equal(root.byIid('h1')?.getAttribute('tabindex'), '0');
    assert.equal(root.byIid('h1')?.getAttribute('aria-pressed'), 'false');
    const titles = root.all(node => node.classList.contains('prompt-player-title'))
        .map(node => node.textContent);
    assert.deepEqual(titles, ['alice']);
    assert.equal(root.byStep('confirm')?.disabled, true);

    root.byIid('h2')?.click();
    assert.equal(root.byIid('h2')?.classList.contains('selected'), true);
    const confirm = root.byStep('confirm');
    assert.equal(confirm?.disabled, false);
    confirm?.click();
    assert.deepEqual(answers, [['h2']]);
});

test('card candidates activate from the keyboard and focus starts in the prompt', () => {
    const { modal, root } = promptModal();
    modal.render(cardsPrompt(), view().cards);
    assert.equal(root.byStep('confirm')?.focused, true);

    root.byIid('h2')?.keydown('Enter');
    assert.equal(root.byIid('h2')?.classList.contains('selected'), true);
    root.byIid('h2')?.keydown(' ');
    assert.equal(root.byIid('h2')?.classList.contains('selected'), false);
});

test('a new prompt id clears the previous picks', () => {
    const { modal, root } = promptModal();
    modal.render(cardsPrompt(), view().cards);
    root.byIid('h1')?.click();
    assert.equal(root.byIid('h1')?.classList.contains('selected'), true);

    modal.render(cardsPrompt({ id: 2 }), view().cards);
    assert.equal(root.byIid('h1')?.classList.contains('selected'), false);
    assert.equal(root.byStep('confirm')?.disabled, true);
});

test('a card prompt that allows nothing offers a skip button', () => {
    const { modal, root, answers } = promptModal();
    modal.render(cardsPrompt({ min: 0 }), view().cards);
    assert.equal(root.byStep('confirm')?.disabled, false);
    root.byStep('skip')?.click();
    assert.deepEqual(answers, [[]]);
});

test('an order prompt shows numbered draggable cards and submits the order', () => {
    const { modal, root, answers } = promptModal();
    modal.render(cardsPrompt({ kind: 'order' } as never), view().cards);
    const cards = root.all(node => node.classList.contains('prompt-order-card'));
    assert.deepEqual(cards.map(node => node.dataset.iid), ['h1', 'h2']);
    assert.deepEqual(cards.map(node => node.byClass('prompt-order-badge')?.textContent), ['1', '2']);
    assert.equal(root.byStep('order-up:h1'), null);
    assert.equal(root.byStep('order-down:h1'), null);
    root.byStep('confirm')?.click();
    assert.deepEqual(answers, [['h1', 'h2']]);
});

test('a player prompt submits the picked seat and a yes/no prompt submits a boolean', () => {
    const first = promptModal();
    first.modal.render(cardsPrompt({ kind: 'player', cards: [], players: [0, 2], min: 1, max: 1 } as never),
        view().cards);
    assert.deepEqual(first.root.all(node => node.dataset.step !== undefined).map(node => node.dataset.step),
        ['player:0', 'player:2']);
    first.root.byStep('player:2')?.click();
    assert.deepEqual(first.answers, [[2]]);

    const second = promptModal();
    second.modal.render(cardsPrompt({ kind: 'yesno', cards: [], min: 0, max: 1 } as never), view().cards);
    second.root.byStep('yes')?.click();
    assert.deepEqual(second.answers, [true]);
});

test('optional effect prompts show the effect and distinguish declining from undoing placement', () => {
    const { modal, root, answers } = promptModal();
    const faces = view().cards;
    faces.effect = { defId: 'classy-narwhal', owner: 0, zone: 'stable', revealed: true, neighable: false };
    modal.render(cardsPrompt({ kind: 'yesno', reason: 'Use this effect?', source: 'effect', cards: [] }), faces);
    assert.equal(root.byClass('prompt-header')?.byClass('prompt-source')?.textContent, 'Classy Narwhal');
    assert.equal(root.byClass('prompt-effect')?.textContent, cardEntry('classy-narwhal')?.text);
    assert.match(root.byClass('prompt-body')?.textContent ?? '', /does not cancel the card's placement/);
    root.byStep('no')?.click();
    assert.deepEqual(answers, [false]);

    modal.render(cardsPrompt({ id: 2, source: 'effect', canCancel: true }), faces);
    assert.equal(root.byClass('prompt-effect'), null);
    assert.doesNotMatch(root.textContent, /does not cancel the card's placement/);
    root.byStep('cancel')?.click();
    assert.deepEqual(answers, [false, 'cancel']);
});

test('player choices follow the table counterclockwise from the local seat', () => {
    const first = promptModal();
    first.modal.render(cardsPrompt({ player: 1, kind: 'player', cards: [], players: [2, 0, 1] }), view().cards);
    assert.deepEqual(first.root.all(node => node.dataset.step?.startsWith('player:'))
        .map(node => node.dataset.step), ['player:1', 'player:0', 'player:2']);

    const root = host();
    const target = new TargetModal(root as unknown as HTMLElement, () => NAMES, () => {}, () => {});
    target.open(view({ seat: 1, targets: { h1: [2, 0, 1] } }), 'h1');
    const options = root.all(node => node.dataset.seat !== undefined);
    assert.deepEqual(options.map(node => node.dataset.seat), ['1', '0', '2', 'cancel']);
    assert.deepEqual(options.slice(0, 3).map(node => node.textContent), [
        'bob\u00a0\u00a0(3 in hand) [YOURSELF!!]', 'alice\u00a0\u00a0(2 in hand)', 'carol\u00a0\u00a0(0 in hand)'
    ]);
    assert.equal(root.all(node => node.classList.contains('prompt-yourself')).length, 1);
    assert.equal(options[0].byClass('prompt-yourself')?.textContent, ' [YOURSELF!!]');
    assert.equal(root.byClass('prompt-stable-preview'), null);
    assert.equal(root.all(node => node.classList.contains('card-slot')).length, 0);
});

test('a targeted play warns about a harmful upgrade or downgrade', () => {
    assert.equal(targetWarning('downgrade', true), 'You are applying a downgrade card to yourself. Confirm?');
    assert.equal(targetWarning('upgrade', false), 'You are applying an upgrade card to another player. Confirm?');
    assert.equal(targetWarning('downgrade', false), '');
    assert.equal(targetWarning('upgrade', true), '');
});

test('required prompts have no local cancel control', () => {
    const cards = promptModal();
    cards.modal.render(cardsPrompt(), view().cards);
    assert.equal(cards.root.byStep('cancel'), null);

    const order = promptModal();
    order.modal.render(cardsPrompt({ kind: 'order' } as never), view().cards);
    assert.equal(order.root.byStep('cancel'), null);
});

test('safe required choices offer Cancel but No and Skip do not duplicate it', () => {
    for (const kind of ['cards', 'order', 'player', 'option']) {
        const { modal, root, answers } = promptModal();
        modal.render(cardsPrompt({ kind, canCancel: true }), view().cards);
        root.byStep('cancel')?.click();
        assert.deepEqual(answers, ['cancel']);
    }
    const yesno = promptModal();
    yesno.modal.render(cardsPrompt({ kind: 'yesno', canCancel: true }), view().cards);
    assert.equal(yesno.root.byStep('cancel'), null);
    yesno.root.byStep('no')?.click();
    assert.deepEqual(yesno.answers, [false]);
    const skip = promptModal();
    skip.modal.render(cardsPrompt({ min: 0, canCancel: true }), view().cards);
    assert.equal(skip.root.byStep('cancel'), null);
    skip.root.byStep('skip')?.click();
    assert.deepEqual(skip.answers, [[]]);
});

test('closing the prompt modal empties it', () => {
    const { modal, root } = promptModal();
    modal.render(cardsPrompt(), view().cards);
    modal.close();
    assert.equal(modal.isOpen, false);
    assert.equal(root.children.length, 0);
});

test('log lines name the actor and the card, and stay silent for quiet events', () => {
    const faces = view().cards;
    assert.equal(describeEvent({ seq: 1, type: 'draw', player: 1 }, faces, NAMES), 'bob drew a card');
    assert.equal(describeEvent({ seq: 2, type: 'neigh', player: 0 }, faces, NAMES), 'alice neighed');
    assert.equal(describeEvent({ seq: 2, type: 'cancel', player: 0 }, faces, NAMES), 'alice canceled an action');
    assert.equal(describeEvent({ seq: 3, type: 'turnStart', player: 2 }, faces, NAMES), 'carol started their turn');
    assert.equal(describeEvent({ seq: 3, type: 'play', player: 1, card: 't1' }, faces, NAMES),
        'bob played Rainbow Aura');
    assert.equal(describeEvent({ seq: 3, type: 'play', player: 1, card: 'hidden' }, faces, NAMES),
        'bob played a card');
    assert.equal(describeEvent({ seq: 3, type: 'play', player: 1, card: 'hidden',
        publicDefId: 'rainbow-aura' }, {}, NAMES), 'bob played Rainbow Aura');
    assert.equal(
        describeEvent({ seq: 4, type: 'destroy', player: 1, card: 's1' }, faces, NAMES),
        'bob destroyed Baby Unicorn'
    );
    assert.equal(describeEvent({ seq: 5, type: 'enterStable', player: 1 }, faces, NAMES), '');
    assert.equal(describeEvent({ seq: 6, type: 'draw' }, faces, NAMES), 'Someone drew a card');
    assert.equal(cardName('__wildcard'), 'a face-down card');
});

test('the log describes the deck-out ending', () => {
    const faces = view().cards;
    assert.equal(
        describeEvent({ seq: 7, type: 'deckOut', player: 1 }, faces, NAMES),
        'The deck ran out. bob wins'
    );
    assert.equal(
        describeEvent({ seq: 8, type: 'deckOut' }, faces, NAMES),
        'The deck ran out and it is a perfect tie. Everyone loses.'
    );
});

test('a legal target seat is marked as targetable', () => {
    const node = seatElement(
        {
            view: view(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            targetable: [0, 2], radius: 360, cardW: 130
        },
        2,
        { anchor: { x: 0, y: 300 }, rotationDeg: 0 } as never
    ) as unknown as FakeElement;
    assert.equal(node.classList.contains('targetable'), true);

    const other = seatElement(
        {
            view: view(), names: NAMES, connected: [true, true, true], selectedTarget: null,
            targetable: [0, 2], radius: 360, cardW: 130
        },
        1,
        { anchor: { x: 0, y: -300 }, rotationDeg: 180 } as never
    ) as unknown as FakeElement;
    assert.equal(other.classList.contains('targetable'), false);
});

test('the confirm modal asks before a useless play', () => {
    const overlay = new FakeElement('div');
    overlay.className = 'modal-darken';
    const body = new FakeElement('div');
    overlay.append(body);
    const confirmed: Array<boolean> = [];
    const modal = new ConfirmModal(body as unknown as HTMLElement, () => confirmed.push(true));

    assert.equal(modal.isOpen, false);

    modal.open('This card currently can have no effect. Continue?');
    assert.equal(modal.isOpen, true);
    assert.equal(body.byClass('prompt-reason')?.textContent,
        'This card currently can have no effect. Continue?');

    body.byStep('cancel')?.click();
    assert.equal(modal.isOpen, false);
    assert.deepEqual(confirmed, []);

    modal.open('This card currently can have no effect. Continue?');
    body.byStep('yes')?.click();
    assert.equal(modal.isOpen, false);
    assert.deepEqual(confirmed, [true]);
});

test('card image URLs use the configured theme and leave plain URLs unchanged', () => {
    const entry = cardEntry('neigh');
    assert.ok(entry);
    const originalTheme = config.theme;
    const originalImage = entry.image;
    try {
        config.theme = 'test_theme';
        let face = cardFace('neigh') as unknown as FakeElement;
        assert.equal((face.byClass('card-art')?.children[0] as unknown as { src: string }).src,
            '/unstable_unicorns/images/cards/test_theme/base/neigh.jpg');

        entry.image = '/custom-art/neigh.png';
        face = cardFace('neigh') as unknown as FakeElement;
        assert.equal((face.byClass('card-art')?.children[0] as unknown as { src: string }).src,
            '/custom-art/neigh.png');
    } finally {
        config.theme = originalTheme;
        entry.image = originalImage;
    }
});

test('a card face shows its kind badge and catalog art', () => {
    const face = cardFace('basic-unicorn-blue') as unknown as FakeElement;
    const badge = face.byClass('card-kind');
    assert.ok(badge);
    assert.equal(badge.textContent, 'Unicorn (Basic)');
    assert.equal((cardFace('baby-unicorn-blue') as unknown as FakeElement)
        .byClass('card-kind')?.textContent, 'Unicorn (Baby)');
    assert.equal((cardFace('magical-flying-unicorn') as unknown as FakeElement)
        .byClass('card-kind')?.textContent, 'Unicorn (Magical)');

    const art = face.byClass('card-art');
    assert.ok(art);
    assert.equal((art.children[0] as unknown as { src: string }).src,
        '/unstable_unicorns/images/cards/base_game/base/basicblue.jpg');

    const hidden = cardFace(WILDCARD) as unknown as FakeElement;
    const down = hidden.byClass('card-art');
    assert.ok(down);
    assert.equal((down.children[0] as unknown as { src: string }).src,
        '/unstable_unicorns/img/placeholders/down.svg');
});

test('the gallery shows every physical card copy with its name and full text', async () => {
    const gallery = host();
    const dom = document as Document & { getElementById: (id: string) => HTMLElement | null };
    dom.getElementById = id => id === 'gallery' ? gallery as unknown as HTMLElement : null;
    try {
        await import('../../client/unstable_unicorns/js/gallery.js');
    } finally {
        delete (dom as unknown as { getElementById?: unknown }).getElementById;
    }

    const entries = catalogFor(packNames());
    const cards = gallery.children.filter(child => child.classList.contains('card-face'));
    const headings = gallery.children.filter(child => child.classList.contains('gallery-pack-title'));
    assert.deepEqual(headings.map(heading => heading.textContent), packNames());
    assert.ok(headings.every(heading => heading.tagName === 'h2'));
    let position = 0;
    for (const pack of packNames()) {
        assert.equal(gallery.children[position].textContent, pack);
        position += 1 + catalogFor([pack]).reduce((total, entry) => total + entry.copies, 0);
    }
    assert.equal(cards.length, entries.reduce((total, entry) => total + entry.copies, 0));
    let index = 0;
    for (const entry of entries) {
        for (let copy = 0; copy < entry.copies; copy++) {
            assert.equal(cards[index].byClass('card-name')?.textContent, entry.name);
            assert.equal(cards[index].byClass('card-text')?.textContent, entry.text);
            index++;
        }
    }
    assert.equal(cards.filter(card =>
        card.byClass('card-name')?.textContent === 'Baby Unicorn').length, 10);
});

test('a neigh card face shows an Instant badge and instant art', () => {
    const face = cardFace('neigh') as unknown as FakeElement;
    assert.equal(face.byClass('card-kind')?.textContent, 'Instant');
    const art = face.byClass('card-art');
    assert.ok(art);
    assert.equal((art.children[0] as unknown as { src: string }).src,
        '/unstable_unicorns/images/cards/base_game/base/neigh.jpg');

    const superNope = cardFace('super-neigh') as unknown as FakeElement;
    assert.equal(superNope.byClass('card-kind')?.textContent, 'Instant');
});

test('log lines say who a played card was put on', () => {
    const faces = view().cards;
    assert.equal(describeEvent({ seq: 1, type: 'play', player: 1, targetPlayer: 0, card: 't1' }, faces, NAMES),
        'bob played Rainbow Aura on alice');
    assert.equal(describeEvent({ seq: 2, type: 'play', player: 1, targetPlayer: 1, card: 't1' }, faces, NAMES),
        'bob played Rainbow Aura');
});
