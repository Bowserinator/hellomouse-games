import { test } from 'node:test';
import assert from 'node:assert/strict';

import { seedFrom, nextFloat, nextInt, shuffle } from '../../client/unstable_unicorns/js/engine/rng.js';
import { makeIdGen, nextIid } from '../../client/unstable_unicorns/js/engine/ids.js';
import { emptyState, createCard } from '../../client/unstable_unicorns/js/engine/state.js';
import { snapshot, restoreInto } from '../../client/unstable_unicorns/js/engine/snapshot.js';
import { assertInvariant, iidsIn } from '../../client/unstable_unicorns/js/engine/zones.js';

test('rng is deterministic per seed', () => {
    const a = seedFrom('table-1');
    const b = seedFrom('table-1');
    const c = seedFrom('table-2');
    const rollA = Array.from({ length: 20 }, () => nextFloat(a));
    const rollB = Array.from({ length: 20 }, () => nextFloat(b));
    const rollC = Array.from({ length: 20 }, () => nextFloat(c));
    assert.deepEqual(rollA, rollB);
    assert.notDeepEqual(rollA, rollC);
    assert.ok(rollA.every(x => x >= 0 && x < 1));
});

test('rng integers stay in range and shuffle is a permutation', () => {
    const rng = seedFrom('s');
    for (let i = 0; i < 200; i++) {
        const n = nextInt(rng, 7);
        assert.ok(n >= 0 && n < 7);
    }
    const items = ['a', 'b', 'c', 'd', 'e'];
    const out = shuffle(rng, [...items]);
    assert.deepEqual([...out].sort(), [...items].sort());
});

test('id generator never repeats', () => {
    const ids = makeIdGen();
    assert.equal(nextIid(ids), 'c1');
    assert.equal(nextIid(ids), 'c2');
    assert.notEqual(nextIid(ids), 'c2');
});

test('snapshot restore round trip is equal', () => {
    const state = emptyState(3, 7);
    const ids = makeIdGen();
    createCard(state, nextIid(ids), 'baby', 0, 'hand');
    createCard(state, nextIid(ids), 'basic', 1, 'stable');
    createCard(state, nextIid(ids), 'basic', 2, 'deck');
    state.turn.player = 2;
    state.links.current.push({ source: 'c1', player: 0, effect: 'n0' });

    const snap = snapshot(state);
    state.turn.player = 0;
    state.discard.push('c2');
    state.players[1].stable = [];
    state.cards.c2.zone = 'discard';
    state.links.current = [];

    restoreInto(state, snap);
    assert.deepEqual(state, snap);
    assert.equal(state.turn.player, 2);
    assert.equal(state.cards.c2.zone, 'stable');
    assertInvariant(state);
});

test('zone invariant accepts a consistent state', () => {
    const state = emptyState(2, 7);
    const ids = makeIdGen();
    createCard(state, nextIid(ids), 'baby', 0, 'stable');
    createCard(state, nextIid(ids), 'magic', 1, 'hand');
    createCard(state, nextIid(ids), 'magic', 0, 'deck');
    assertInvariant(state);
    assert.deepEqual(iidsIn(state, 'stable'), ['c1']);
    assert.deepEqual(iidsIn(state, 'hand', 1), ['c2']);
});

test('zone invariant rejects a card in two zones', () => {
    const state = emptyState(2, 7);
    const ids = makeIdGen();
    createCard(state, nextIid(ids), 'magic', 0, 'deck');
    state.players[0].hand.push('c1');
    assert.throws(() => assertInvariant(state), /more than one zone/);
});

test('zone invariant rejects a card in no zone', () => {
    const state = emptyState(2, 7);
    const ids = makeIdGen();
    createCard(state, nextIid(ids), 'magic', 0, 'deck');
    state.deck = [];
    assert.throws(() => assertInvariant(state), /in no zone/);
});
