import { test } from 'node:test';
import assert from 'node:assert/strict';

import { createCard, emptyState } from '../../client/unstable_unicorns/js/engine/state.js';
import type { GameState, Zone } from '../../client/unstable_unicorns/js/engine/state.js';
import type { Iid } from '../../client/unstable_unicorns/js/engine/ids.js';
import { isPublicZone, viewModel } from '../../client/unstable_unicorns/js/engine/view.js';
import type { ChainView } from '../../client/unstable_unicorns/js/engine/view.js';
import { nextFloat, nextInt, pick, seedFrom } from '../../client/unstable_unicorns/js/engine/rng.js';

const emptyChain: ChainView = { top: null, canNeigh: false };

function payload(
    state: GameState,
    seat: number,
    chain: ChainView = emptyChain,
    visible: (owner: number) => boolean = () => false
) {
    return viewModel(state, seat, [], chain, [], visible, 1, 1, 7);
}

test('own hand is shown in full and other hands as counts', () => {
    const state = emptyState(3, 7);
    createCard(state, 'i0', 'mine', 0, 'hand');
    createCard(state, 'i1', 'theirs', 1, 'hand');

    const me = payload(state, 0);
    assert.deepEqual(me.players[0].hand, ['i0']);
    assert.equal(me.players[1].hand, null);
    assert.equal(me.players[1].handCount, 1);
    assert.equal(me.cards.i0.defId, 'mine');
    assert.equal(me.cards.i1, undefined);
});

test('a hand visible modifier shows the faces and the order', () => {
    const state = emptyState(3, 7);
    createCard(state, 'i0', 'theirs', 1, 'hand');

    const me = payload(state, 0, emptyChain, owner => owner === 1);
    assert.deepEqual(me.players[1].hand, ['i0']);
    assert.equal(me.cards.i0.defId, 'theirs');
});

test('a single revealed card arrives without its position', () => {
    const state = emptyState(3, 7);
    createCard(state, 'i0', 'shown', 1, 'hand');
    createCard(state, 'i1', 'unknown', 1, 'hand');
    state.cards.i0.revealedTo = [0];

    const me = payload(state, 0);
    assert.equal(me.cards.i0.defId, 'shown');
    assert.equal(me.cards.i1, undefined);
    assert.equal(me.players[1].hand, null);
});

test('the prompt is only sent to its target', () => {
    const state = emptyState(3, 7);
    createCard(state, 'i0', 'played', 0, 'stable');
    state.prompt = {
        id: 4,
        player: 1,
        kind: 'cards',
        reason: 'destroyOne',
        source: 'i0',
        cards: ['i0'],
        players: [],
        min: 1,
        max: 1
    };

    assert.equal(payload(state, 0).prompt, null);
    assert.deepEqual(payload(state, 0).waitingOn, [1]);
    assert.equal(payload(state, 1).prompt?.id, 4);
    assert.deepEqual(payload(state, 1).waitingOn, [1]);
});

test('a prompt blocks the game for seats that cannot see it', () => {
    const state = emptyState(3, 7);
    state.prompt = {
        id: 4,
        player: 1,
        kind: 'yesno',
        reason: 'neigh?',
        source: null,
        cards: [],
        players: [],
        min: 0,
        max: 1
    };

    const other = payload(state, 0);
    assert.equal(other.prompt, null);
    assert.equal(other.promptOpen, true);
});

test('the chain summary names the latest play', () => {
    const state = emptyState(3, 7);
    createCard(state, 'i0', 'played', 0, 'stable');
    const chain: ChainView = { top: { id: 2, card: 'i0', by: 0, kind: 'play' }, canNeigh: true };

    const seatOne = payload(state, 1, chain);
    assert.deepEqual(seatOne.chain.top, chain.top);
    assert.equal(seatOne.chain.canNeigh, true);
});

test('a finished game waits on nobody', () => {
    const state = emptyState(3, 7);
    state.winner = 2;
    assert.deepEqual(payload(state, 0).waitingOn, []);
});

test('counts stay public while faces do not', () => {
    const state = emptyState(3, 7);
    for (let i = 0; i < 5; i++) createCard(state, `i${i}`, `aaa${i}`, 1, 'hand');
    for (let i = 5; i < 8; i++) createCard(state, `i${i}`, `aaa${i}`, 0, 'deck');

    const me = payload(state, 0);
    assert.equal(me.players[1].handCount, 5);
    assert.equal(me.deckCount, 3);
    const json = JSON.stringify(me);
    for (let i = 0; i < 8; i++) assert.equal(json.includes(`"aaa${i}"`), false);
});

test('random states never leak a hidden card face', () => {
    const rng = seedFrom('redaction');
    const zones: Array<Zone> = ['hand', 'stable', 'deck', 'discard', 'nursery', 'limbo'];

    for (let round = 0; round < 40; round++) {
        const state = emptyState(3, 7);
        const faces = new Map<Iid, string>();
        for (let i = 0; i < 8; i++) {
            const defId = `aaa${i}`;
            const zone = pick(rng, zones) as Zone;
            const owner = nextInt(rng, 3);
            const iid = `i${i}`;
            createCard(state, iid, defId, owner, zone);
            if (nextFloat(rng) < 0.2) state.cards[iid].revealedTo = [0];
            faces.set(iid, defId);
        }

        for (let seat = 0; seat < 3; seat++) {
            const json = JSON.stringify(payload(state, seat));
            for (const [iid, defId] of faces) {
                const card = state.cards[iid];
                const hidden = !isPublicZone(card.zone) && card.owner !== seat && !card.revealedTo.includes(seat);
                if (hidden) assert.equal(json.includes(`"${defId}"`), false, `round ${round} seat ${seat}`);
            }
        }
    }
});
