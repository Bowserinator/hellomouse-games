import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BASE_CATALOG } from '../../client/unstable_unicorns/js/catalog/base.js';
import { BASE_DEFS } from '../../client/unstable_unicorns/js/engine/cards/index.js';
import { cardScene, registry } from './scenarios.js';
import { moveCard } from '../../client/unstable_unicorns/js/engine/move.js';
import { moveCtxOf } from '../../client/unstable_unicorns/js/engine/exec/context.js';
import { resolveLinks } from '../../client/unstable_unicorns/js/engine/chain.js';
import { assertInvariant } from '../../client/unstable_unicorns/js/engine/zones.js';

function settle(scene: ReturnType<typeof cardScene>) {
    for (let i = 0; i < 64 && scene.engine.state.prompt; i++) {
        const prompt = scene.engine.state.prompt;
        let selection: boolean | number | Array<string> | Array<number>;
        switch (prompt.kind) {
            case 'yesno':
                selection = false;
                break;
            case 'option':
                selection = prompt.min;
                break;
            case 'player':
                selection = prompt.players.slice(0, prompt.min);
                break;
            case 'order':
                selection = prompt.cards;
                break;
            case 'cards':
                selection = prompt.cards.slice(0, prompt.min);
                break;
        }
        const result = scene.engine.dispatch(prompt.player, {
            type: 'RESPOND',
            promptId: prompt.id,
            selection
        });
        assert.ok(result.ok, `${prompt.reason}: ${result.ok ? '' : result.error}`);
        assertInvariant(scene.engine.state);
    }
    assert.equal(scene.engine.state.prompt, null, 'card effect left an unresolved prompt');
}

function setupScene() {
    const scene = cardScene();
    scene.add('basic-unicorn-blue', 0, 'stable');
    scene.add('basic-unicorn-green', 0, 'stable');
    scene.add('basic-unicorn-orange', 1, 'stable');
    scene.add('basic-unicorn-purple', 1, 'stable');
    scene.add('double-dutch', 0, 'stable');
    scene.add('slowdown', 1, 'stable');
    for (let i = 0; i < 10; i++) scene.add('basic-unicorn-indigo', 0, 'deck');
    for (let i = 0; i < 3; i++) scene.add('basic-unicorn-yellow', 1);
    for (let i = 0; i < 3; i++) scene.add('basic-unicorn-red', 2);
    scene.add('double-dutch', 1, 'discard');
    scene.add('slowdown', 1, 'discard');
    for (let i = 0; i < 3; i++) scene.add('baby-unicorn-blue', 0, 'nursery');
    return scene;
}

test('every current catalog card has a matching executable definition and smoke scenario', () => {
    assert.equal(BASE_CATALOG.length, 76);
    assert.equal(BASE_DEFS.length, BASE_CATALOG.length);
    const defs = new Map(BASE_DEFS.map(def => [def.id, def]));

    for (const card of BASE_CATALOG) {
        const def = defs.get(card.id);
        assert.ok(def, `${card.id} has no engine definition`);
        assert.equal(registry.byId[card.id], def, `${card.id} is not registered`);
        assert.equal(def.kind, card.kind, `${card.id} kind drifted from catalog`);
        if (card.kind === 'basic' || card.kind === 'baby') assert.ok(def.unicornType, `${card.id} lacks Unicorn identity`);
        else assert.equal(def.unicornType, undefined, `${card.id} has unexpected Unicorn identity`);

        if (card.kind === 'instant') continue;
        const scene = setupScene();
        const iid = scene.add(card.id);
        if (card.kind === 'basic' || card.kind === 'baby') {
            const result = moveCard(moveCtxOf(scene.engine.ex), iid, { zone: 'stable', owner: 0 }, 'play');
            assert.equal(result.moved, true, `${card.id} could not enter a legal own Stable`);
            resolveLinks(scene.engine.ex);
        } else {
            const result = scene.engine.dispatch(0, { type: 'PLAY_CARD', iid });
            assert.ok(result.ok, `${card.id} could not execute: ${result.ok ? '' : result.error}`);
        }
        settle(scene);
    }
});
