type FakeEvent = {
    type: string;
    target: FakeElement | null;
    key?: string;
    preventDefault?: () => void;
};
type Listener = (event: FakeEvent) => void;

class FakeStyle {
    [name: string]: unknown;

    setProperty(name: string, value: string) {
        this[name] = value;
    }
}

export class FakeElement {
    tagName: string;
    id = '';
    className = '';
    dataset: Record<string, string> = {};
    attributes: Record<string, string> = {};
    style: FakeStyle = new FakeStyle();
    children: Array<FakeElement> = [];
    parent: FakeElement | null = null;
    disabled = false;
    hidden = false;
    focused = false;
    private text = '';
    private listeners: Array<{ type: string; fn: Listener }> = [];

    constructor(tagName: string) {
        this.tagName = tagName;
    }

    get parentElement(): FakeElement | null {
        return this.parent;
    }

    get classList() {
        const names = () => (this.className ? this.className.split(' ') : []);
        const write = (list: Array<string>) => {
            this.className = list.join(' ');
        };
        return {
            add: (...added: Array<string>) => {
                const current = names();
                for (const name of added) if (!current.includes(name)) current.push(name);
                write(current);
            },
            remove: (...removed: Array<string>) => {
                write(names().filter(name => !removed.includes(name)));
            },
            toggle: (name: string, force?: boolean) => {
                const on = force ?? !names().includes(name);
                if (on) this.classList.add(name);
                else this.classList.remove(name);
                return on;
            },
            contains: (name: string) => names().includes(name)
        };
    }

    setAttribute(name: string, value: string) {
        this.attributes[name] = value;
    }

    getAttribute(name: string): string | null {
        return this.attributes[name] ?? null;
    }

    remove() {
        if (this.parent) this.parent.children = this.parent.children.filter(child => child !== this);
        this.parent = null;
    }

    get textContent(): string {
        return this.text + this.children.map(child => child.textContent).join('');
    }

    set textContent(value: string) {
        this.text = value;
        this.children = [];
    }

    append(...nodes: Array<FakeElement | string>) {
        for (const node of nodes) {
            if (typeof node === 'string') {
                this.text += node;
                continue;
            }
            node.parent = this;
            this.children.push(node);
        }
    }

    replaceChildren(...nodes: Array<FakeElement | string>) {
        this.children = [];
        this.text = '';
        this.append(...nodes);
    }

    addEventListener(type: string, fn: Listener) {
        this.listeners.push({ type, fn });
    }

    click() {
        this.bubble({ type: 'click', target: this });
    }

    keydown(key: string) {
        this.bubble({ type: 'keydown', target: this, key, preventDefault() {} });
    }

    focus() {
        this.focused = true;
    }

    private bubble(event: FakeEvent) {
        for (const listener of this.listeners) if (listener.type === event.type) listener.fn(event);
        this.parent?.bubble(event);
    }

    closest(selector: string): FakeElement | null {
        if (matches(this, selector)) return this;
        return this.parent ? this.parent.closest(selector) : null;
    }

    find(predicate: (node: FakeElement) => boolean): FakeElement | null {
        for (const child of this.children) {
            if (predicate(child)) return child;
            const nested = child.find(predicate);
            if (nested) return nested;
        }
        return null;
    }

    all(predicate: (node: FakeElement) => boolean): Array<FakeElement> {
        const found: Array<FakeElement> = [];
        for (const child of this.children) {
            if (predicate(child)) found.push(child);
            found.push(...child.all(predicate));
        }
        return found;
    }

    byClass(name: string): FakeElement | null {
        return this.find(node => node.classList.contains(name));
    }

    byAction(action: string): FakeElement | null {
        return this.find(node => node.dataset.action === action);
    }

    byStep(step: string): FakeElement | null {
        return this.find(node => node.dataset.step === step);
    }

    byIid(iid: string): FakeElement | null {
        return this.find(node => node.dataset.iid === iid);
    }

    querySelector(selector: string): FakeElement | null {
        return this.find(node => matches(node, selector));
    }
}

function matches(node: FakeElement, selector: string): boolean {
    const button = /^button\[data-(step|seat)\]$/.exec(selector);
    if (button) return node.tagName === 'button' && node.dataset[button[1]] !== undefined;
    if (selector.startsWith('#')) return node.id === selector.slice(1);
    if (selector.startsWith('.')) return node.classList.contains(selector.slice(1));
    return node.tagName === selector;
}

export function installDom(): void {
    (globalThis as { document?: unknown }).document = {
        createElement(tag: string) {
            return new FakeElement(tag);
        },
        addEventListener() {
            return undefined;
        }
    };
}

export function host(): FakeElement {
    return new FakeElement('div');
}
