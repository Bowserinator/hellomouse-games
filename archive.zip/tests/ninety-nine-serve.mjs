import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import config from '../build/server/config.js';
config.port = 8126;
const root = path.resolve('build/client');
process.chdir('build');
await import('../build/server/server.js');
http.createServer(async (request, response) => {
    const url = new URL(request.url, 'http://localhost');
    const file = path.resolve(root, `.${decodeURIComponent(url.pathname)}`, url.pathname.endsWith('/') ? 'index.html' : '');
    if (!file.startsWith(`${root}/`)) { response.writeHead(403).end(); return; }
    try {
        let data = await fs.readFile(file);
        if (url.pathname === '/shared/js/index.js') data = Buffer.from(data.toString().replaceAll('8124', '8126'));
        const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml' };
        response.writeHead(200, { 'Content-Type': types[path.extname(file)] ?? 'application/octet-stream' });
        response.end(data);
    } catch { response.writeHead(404).end('Not found'); }
}).listen(8125, () => console.log('Test site http://localhost:8125/ninety_nine/'));
