import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import websocket from 'websocket';
const server = spawn(process.execPath, ['--input-type=module', '-e',
    "import config from './server/config.js'; config.port=8127; await import('./server/server.js')"],
{ cwd: new URL('../build/', import.meta.url), stdio: ['ignore', 'pipe', 'pipe'] });
let output = '';
server.stdout.on('data', chunk => { output += chunk; });
server.stderr.on('data', chunk => { output += chunk; });
await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(output)), 10000);
    server.stdout.on('data', () => {
        if (output.includes('Server is listening')) { clearTimeout(timeout); resolve(); }
    });
    server.on('error', reject);
});
const clients = [];
async function connect() {
    const socket = new websocket.w3cwebsocket('ws://localhost:8127');
    const messages = []; const waiters = [];
    socket.onmessage = event => {
        const message = JSON.parse(event.data);
        const index = waiters.findIndex(waiter => waiter.predicate(message));
        if (index < 0) messages.push(message);
        else { const waiter = waiters.splice(index, 1)[0]; clearTimeout(waiter.timer); waiter.resolve(message); }
    };
    await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
    const client = { socket, clear: () => { messages.length = 0; }, send: message => socket.send(JSON.stringify(message)),
        wait: predicate => new Promise((resolve, reject) => {
            const index = messages.findIndex(predicate);
            if (index >= 0) return resolve(messages.splice(index, 1)[0]);
            const origin = new Error('Network expectation timed out');
            const timer = setTimeout(() => { origin.message += '\n' + JSON.stringify(messages.slice(-5)) + '\n' + output; reject(origin); }, 10000);
            waiters.push({ predicate, timer, resolve });
        }) };
    clients.push(client); return client;
}
const sync = predicate => m => m.type === 'SYNC' && predicate(m);
const error = client => client.wait(m => m.type === 'ERROR');
const move = (client, action, rest = {}) => client.send({ type: 'MOVE', action, ...rest });
try {
    // The module loader runs asynchronously after listen.
    const host = await connect();
    host.send({ type: 'CREATE', gameType: 'high_society' });
    const room = (await host.wait(m => m.type === 'UUID')).uuid;
    assert.equal((await host.wait(sync(s => s.isHost))).settings.seats, 4);
    const guest = await connect(); guest.send({ type: 'JOIN', gameID: room });
    await guest.wait(sync(s => s.youAre === 1));
    const third = await connect(); third.send({ type: 'JOIN', gameID: room });
    await third.wait(sync(s => s.youAre === 2));
    move(guest, 'SET_OPTIONS', { seats: 3 }); assert.equal((await error(guest)).code, 'MOVE');
    move(host, 'SET_OPTIONS', { seats: 2 }); assert.equal((await error(host)).code, 'MOVE');
    move(host, 'SET_OPTIONS', { seats: 5 });
    assert.equal((await guest.wait(sync(s => s.settings.seats === 5))).seats[4].ai, true);
    move(host, 'START_GAME'); assert.equal((await error(host)).code, 'MOVE');
    for (const client of [host, guest, third]) client.send({ type: 'READY' });
    await host.wait(sync(s => s.seats.every(seat => seat.ready)));
    move(host, 'START_GAME');
    const started = await host.wait(sync(s => s.started));
    const guestStarted = await guest.wait(sync(s => s.started));
    assert.equal(started.token.length, 48);
    assert.equal(started.view.myHand.length, 11);
    assert.ok(started.view.players.every(p => !('hand' in p) && !('spent' in p)));
    assert.equal(started.view.result, undefined);
    const observer = await connect(); observer.send({ type: 'JOIN', gameID: room });
    const observed = await observer.wait(sync(s => s.started));
    assert.equal(observed.youAre, -1); assert.equal(observed.view.myHand.length, 0);
    assert.equal(observed.token, undefined); assert.equal(observed.view.events.length, 0);
    move(observer, 'BID', { cards: [25] }); assert.equal((await error(observer)).code, 'MOVE');
    guest.socket.close();
    await host.wait(sync(s => !s.seats[1].connected));
    move(observer, 'RESUME', { token: guestStarted.token });
    const resumed = await observer.wait(sync(s => s.youAre === 1));
    assert.deepEqual(resumed.view.myHand, guestStarted.view.myHand);
    assert.equal(resumed.view.events.length, 0);
    move(observer, 'BID', { cards: [999] }); assert.equal((await error(observer)).code, 'MOVE');
    move(third, 'REPLACE_WITH_CPU', { seat: 0 }); assert.equal((await error(third)).code, 'MOVE');
    move(host, 'REPLACE_WITH_CPU', { seat: 1 }); assert.equal((await error(host)).code, 'MOVE');
    host.clear();
    observer.socket.close();
    await host.wait(sync(s => s.started && !s.seats[1].connected));
    const before = started.view.players[1];
    move(host, 'REPLACE_WITH_CPU', { seat: 1 });
    const replaced = await host.wait(sync(s => s.started && s.seats[1].ai));
    assert.equal(replaced.view.players[1].handCount, before.handCount);
    assert.deepEqual(replaced.view.players[1].table, before.table);
    const returner = await connect(); returner.send({ type: 'JOIN', gameID: room });
    await returner.wait(sync(s => s.youAre === -1));
    move(returner, 'RESUME', { token: guestStarted.token });
    assert.match((await error(returner)).error, /CPU/);
    move(returner, 'RESUME', { token: 'forged' }); assert.equal((await error(returner)).code, 'MOVE');
    host.socket.close();
    await third.wait(sync(s => s.started && s.isHost));
    const invalid = await connect(); invalid.send({ type: 'JOIN', gameID: 'garbage' });
    assert.equal((await error(invalid)).code, 'NO_GAME');
    // Observer limit is independent of held seats.
    for (let i = 0; i < 7; i++) {
        const watcher = await connect(); watcher.send({ type: 'JOIN', gameID: room });
        await watcher.wait(sync(s => s.youAre === -1));
    }
    const full = await connect(); full.send({ type: 'JOIN', gameID: room });
    assert.equal((await error(full)).code, 'NOT_ALLOWED');
    console.log('Passed network settings/readiness/privacy/resume/replacement/token/host/observer-limit checks');
} finally {
    for (const client of clients) client.socket.close();
    server.kill();
}
