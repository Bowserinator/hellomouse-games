import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Bullet } from '../../client/galaxy_tanks/js/sim/bullet.js';
import { GameState } from '../../client/galaxy_tanks/js/sim/gamestate.js';
import { generateMap } from '../../client/galaxy_tanks/js/sim/mapgen/index.js';
import { Tank } from '../../client/galaxy_tanks/js/sim/tank.js';
import { vec } from '../../client/galaxy_tanks/js/sim/math/vec3.js';
import { BulletType, GalaxySync } from '../../client/galaxy_tanks/js/types.js';
import { LANDMINE_ARMED_COLOR, LANDMINE_ARM_TIME, LANDMINE_BLAST_RADIUS,
    LANDMINE_FLASH_PERIOD } from '../../client/galaxy_tanks/js/vars.js';

test('Mines stay gray until armed, then alternate gray and player color', () => {
    const source = readFileSync('client/galaxy_tanks/js/render/entities.ts', 'utf8');
    const start = source.indexOf('if (b.type === BulletType.LANDMINE &&');
    const end = source.indexOf('this.bullets.setMatrixAt', start);
    assert.ok(start >= 0 && end > start);
    const tintMine = new Function('b', 'BulletType', 'LANDMINE_ARM_TIME', 'LANDMINE_FLASH_PERIOD',
        'LANDMINE_ARMED_COLOR', source.slice(start, end));
    const playerColor = 0xff0000;
    for (const age of [0, .25, .75, LANDMINE_ARM_TIME - .001]) {
        const tint = { color: playerColor, setHex(color: number) {
            this.color = color;
        } };
        tintMine.call({ tint }, { type: BulletType.LANDMINE, age }, BulletType,
            LANDMINE_ARM_TIME, LANDMINE_FLASH_PERIOD, LANDMINE_ARMED_COLOR);
        assert.equal(tint.color, LANDMINE_ARMED_COLOR);
    }
    const colors = [];
    for (const age of [LANDMINE_ARM_TIME + .05, LANDMINE_ARM_TIME + LANDMINE_FLASH_PERIOD + .05]) {
        const tint = { color: playerColor, setHex(color: number) {
            this.color = color;
        } };
        tintMine.call({ tint }, { type: BulletType.LANDMINE, age }, BulletType,
            LANDMINE_ARM_TIME, LANDMINE_FLASH_PERIOD, LANDMINE_ARMED_COLOR);
        colors.push(tint.color);
    }
    assert.deepEqual(new Set(colors), new Set([playerColor, LANDMINE_ARMED_COLOR]));
});

test('Contact detonates an armed mine for either its owner or another player, but not before arming', () => {
    for (const touching of [0, 1]) {
        const map = generateMap(1);
        for (const planet of map.planets) {
            planet.obstacles = []; planet.holes = [];
        }
        const game = new GameState(map);
        game.inLobby = false;
        game.tanks = [new Tank(0), new Tank(1)];
        for (const tank of game.tanks) {
            tank.planet = 1; tank.iFrames = 0;
        }
        game.tanks[touching].planet = 0;
        const mine = new Bullet(100, 0, 0, vec(0, 1, 0), vec(1, 0, 0), 0, BulletType.LANDMINE, 0);
        mine.age = LANDMINE_ARM_TIME - .02;
        game.bullets.push(mine);
        game.update(.01, 1000);
        assert.ok(game.bullets.includes(mine));
        assert.equal(game.tanks[touching].isDead, false);
        game.update(.02, 1020);
        assert.ok(!game.bullets.includes(mine));
        assert.equal(game.tanks[touching].isDead, true);
        assert.ok(game.events.some(e => e.type === GalaxySync.ADD_EXPLOSIONS && e.radius === LANDMINE_BLAST_RADIUS));
    }
});
