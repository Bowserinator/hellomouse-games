import { test } from 'node:test';
import assert from 'node:assert/strict';
import Client from '../../server/client.js';
import TycoonGame from '../../server/games/tycoon.js';
import { decide } from '../../client/tycoon/js/ai.js';
import { eventDuration } from '../../client/tycoon/js/ui/timing.js';
import type { Engine } from '../../client/tycoon/js/engine.js';
import type { Sync } from '../../client/tycoon/js/types.js';

function client(username: string): Client & { messages: Array<Sync & { error?: string; text?: string }> } {
    const messages: Array<Sync & { error?: string; text?: string }> = [];
    const c = new Client({ sendUTF: (text: string) => messages.push(JSON.parse(text)) });
    c.username = username; return Object.assign(c, { messages });
}
function room(): { g: TycoonGame; a: ReturnType<typeof client> } {
    const g = new TycoonGame(), a = client('Ann'); g.uuid = 'test';
    assert.ok(g.onJoin(a)); return { g, a };
}

function playingRoom(hands: Array<Array<number>>): {
    g: TycoonGame; players: Array<ReturnType<typeof client>>; e: Engine;
} {
    const { g, a } = room();
    const players = [a, client('Bob'), client('Cal'), client('Dee')];
    for (const p of players.slice(1)) assert.ok(g.onJoin(p));
    for (const p of players) p.ready = true;
    g.onMove(a, { action: 'START_GAME' });
    const e = g.engine as Engine, pool = e.hands.flat();
    e.hands = hands.map(values => values.map(value => {
        const index = pool.findIndex(c => c.value === value);
        assert.notEqual(index, -1); return pool.splice(index, 1)[0];
    }));
    e.discard = pool; e.events = []; e.log = []; e.turn = e.leader = 0;
    (g as unknown as { animationUntil: number }).animationUntil = Date.now();
    return { g, players, e };
}

test('Four fixed seats, human joins replace AI, leave restores AI, cap at four humans', () => {
    const { g, a } = room();
    assert.deepEqual(g.globalStateSync(a).seats.map(s => s.ai), [false, true, true, true]);
    const b = client('Bob'); g.onJoin(b); g.onDisconnect(a);
    assert.equal(g.globalStateSync(b).isHost, true);
    for (let i = 0; i < 3; i++) assert.ok(g.onJoin(client(`P${i}`)));
    assert.equal(g.onJoin(client('Overflow')), false); g.onRemove();
});

test('Host options validated live, start requires ready humans, options persist after returning', () => {
    const { g, a } = room(); const b = client('Bob'); g.onJoin(b);
    assert.deepEqual(g.settings, { rounds: 3, jokers: true });
    g.onMove(b, { action: 'SET_OPTIONS', rounds: 1, jokers: false }); assert.equal(g.settings.rounds, 3);
    for (const rounds of [0, 21, 1.2, '2', NaN]) {
        g.onMove(a, { action: 'SET_OPTIONS', rounds, jokers: false }); assert.equal(g.settings.rounds, 3);
    }
    g.onMove(a, { action: 'SET_OPTIONS', rounds: 1, jokers: false });
    assert.deepEqual(b.messages.at(-1)?.settings, { rounds: 1, jokers: false });
    g.onMove(a, { action: 'START_GAME' }); assert.equal(g.engine, null);
    a.ready = b.ready = true;
    g.onMove(b, { action: 'START_GAME' }); assert.equal(g.engine, null);
    g.onMove(a, { action: 'START_GAME' }); assert.ok(g.engine);
    assert.ok(a.messages.at(-1)?.view?.events.some(e => e.group === 'deal'));
    g.onMove(a, { action: 'SET_OPTIONS', rounds: 2, jokers: true }); assert.equal(g.settings.rounds, 1);
    g.onMove(a, { action: 'RETURN_TO_LOBBY' }); assert.ok(g.engine);
    const e = g.engine as Engine | null;
    while (e && e.phase !== 'gameEnd') assert.equal(e.dispatch(e.turn, decide(e.view(e.turn, Infinity))), null);
    g.onMove(b, { action: 'RETURN_TO_LOBBY' }); assert.equal(g.engine, null);
    assert.deepEqual(g.settings, { rounds: 1, jokers: false }); assert.equal(a.ready, false);
    assert.equal(g.config.holdEmptySeats, false); g.onRemove();
});

test('Solo play, held human seats never become AI, observer privacy and private resume token', () => {
    const { g, a } = room(); a.ready = true; g.onMove(a, { action: 'START_GAME' });
    const token = g.globalStateSync(a).token;
    const ids = g.engine?.hands[0].map(c => c.iid);
    g.onDisconnect(a); assert.equal(g.config.holdEmptySeats, true);
    assert.equal(g.players[0], null);
    const watcher = client('Watcher'); assert.ok(g.onJoin(watcher));
    const sync = g.globalStateSync(watcher);
    assert.equal(sync.youAre, -1); assert.equal(sync.seats[0].ai, false);
    assert.ok(sync.view?.hands.flat().every(c => c.value === null)); assert.equal(sync.view?.events.length, 0);
    g.onMove(watcher, { action: 'RESUME', token: 'wrong' }); assert.equal(g.players[0], null);
    g.onMove(watcher, { action: 'RESUME', token }); assert.equal(g.players[0], watcher);
    assert.equal(watcher.username, 'Ann'); assert.deepEqual(g.engine?.hands[0].map(c => c.iid), ids);
    assert.equal(g.globalStateSync(watcher).view?.events.length, 0);
    g.onRemove(); assert.equal(g.engine, null);
});

test('AI and summary timers clear on disconnect/removal and resume with connected humans only', () => {
    const { g, a } = room(); a.ready = true; g.onMove(a, { action: 'START_GAME' });
    // Inspect timer ownership without exposing it as a public game API.
    const timers = (g as unknown as { timers: Set<unknown> }).timers;
    assert.ok(timers.size <= 1);
    g.onDisconnect(a); assert.equal(timers.size, 0);
    const observer = client('Observer'); g.onJoin(observer); assert.equal(timers.size, 0);
    g.onRemove(); assert.equal(timers.size, 0);
});

test('Forced passes wait for animations plus 2500 ms, notify once, and stop after the trick clears', t => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1000 });
    const { g, players, e } = playingRoom([[2, 4], [3, 5], [1, 6], [13, 7]]);
    try {
        g.onMove(players[0], { action: 'PLAY', iids: [e.hands[0][0].iid] });
        const animation = eventDuration(e.events);
        t.mock.timers.tick(animation + 2499);
        assert.equal(e.turn, 1); assert.equal(e.passed.size, 0);
        t.mock.timers.tick(1);
        assert.equal(e.turn, 2); assert.ok(e.passed.has(1));
        assert.equal(players[1].messages.filter(m => m.text === 'Auto-passed.').length, 1);
        assert.equal(players[0].messages.filter(m => m.text).length, 0);
        t.mock.timers.tick(2500); assert.equal(e.turn, 3);
        t.mock.timers.tick(2500); assert.equal(e.turn, 0); assert.equal(e.table, null);
        t.mock.timers.tick(5000); assert.equal(e.turn, 0);
        for (const p of players.slice(1)) assert.equal(p.messages.filter(m => m.text === 'Auto-passed.').length, 1);
    } finally { g.onRemove(); }
});

test('A legal full set prevents auto-pass; an unmatched strong singleton does not', t => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1000 });
    for (const blocked of [false, true]) {
        const { g, players, e } = playingRoom([[12, 12, 4], blocked ? [2, 5] : [13, 13], [1, 6], [3, 7]]);
        try {
            g.onReady(); t.mock.timers.tick(5000);
            assert.equal(e.turn, 0); assert.equal(e.table, null);
            g.onMove(players[0], { action: 'PLAY', iids: e.hands[0].slice(0, 2).map(c => c.iid) });
            t.mock.timers.tick(eventDuration(e.events) + 2500);
            assert.equal(e.passed.has(1), blocked);
            assert.equal(players[1].messages.filter(m => m.text === 'Auto-passed.').length, blocked ? 1 : 0);
        } finally { g.onRemove(); }
    }
});

test('Manual pass cancels the pending forced pass and reschedules for the next seat', t => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1000 });
    const { g, players, e } = playingRoom([[2, 4], [3, 5], [1, 6], [13, 7]]);
    try {
        g.onMove(players[0], { action: 'PLAY', iids: [e.hands[0][0].iid] });
        const animation = eventDuration(e.events);
        t.mock.timers.tick(200); g.onMove(players[1], { action: 'PASS' });
        assert.equal(e.turn, 2);
        t.mock.timers.tick(animation + 2299); assert.equal(e.turn, 2);
        t.mock.timers.tick(1); assert.equal(e.turn, 3);
        assert.equal(players[1].messages.filter(m => m.text).length, 0);
        assert.equal(players[2].messages.filter(m => m.text === 'Auto-passed.').length, 1);
        assert.equal(e.log.filter(line => line === 'Player 2 passes').length, 1);
    } finally { g.onRemove(); }
});

test('Forced pass uses revolution order and cancels when all humans disconnect', t => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1000 });
    const { g, players, e } = playingRoom([[3, 4], [2, 5], [1, 6], [13, 7]]);
    try {
        e.revolution = true;
        g.onMove(players[0], { action: 'PLAY', iids: [e.hands[0][0].iid] });
        t.mock.timers.tick(eventDuration(e.events) + 2500);
        assert.ok(e.passed.has(1)); assert.equal(e.turn, 2);
        for (const p of players) g.onDisconnect(p);
        t.mock.timers.tick(5000); assert.equal(e.turn, 2);
        const observer = client('Observer'); assert.ok(g.onJoin(observer));
        t.mock.timers.tick(5000); assert.equal(e.turn, 2);
        assert.equal(players[2].messages.filter(m => m.text).length, 0);
    } finally { g.onRemove(); }
});

test('Removal and a stale phase prevent a queued forced pass from firing', t => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1000 });
    for (const remove of [false, true]) {
        const { g, players, e } = playingRoom([[2, 4], [3, 5], [1, 6], [13, 7]]);
        try {
            g.onMove(players[0], { action: 'PLAY', iids: [e.hands[0][0].iid] });
            if (remove) g.onRemove(); else e.phase = 'gameEnd';
            t.mock.timers.tick(5000);
            assert.equal(e.turn, 1); assert.equal(e.passed.size, 0);
            assert.equal(players[1].messages.filter(m => m.text).length, 0);
        } finally { g.onRemove(); }
    }
});
