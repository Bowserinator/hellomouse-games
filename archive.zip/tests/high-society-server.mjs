import assert from 'node:assert/strict';
import { test } from 'node:test';
import Game from '../build/server/games/high_society.js';
import Client from '../build/server/client.js';
import { decide } from '../build/client/high_society/js/ai.js';
function client() {
    const messages = [];
    const c = new Client({ sendUTF: text => messages.push(JSON.parse(text)) });
    c.messages = messages; c.ready = true; return c;
}
test('Replacement preserves active bids, cards and status; disconnect never auto-passes', () => {
    const g = new Game(); const host = client(); const guest = client(); const third = client();
    try {
        for (const c of [host, guest, third]) assert.ok(g.onJoin(c));
        g.onMove(host, { action: 'SET_OPTIONS', seats: 3 });
        g.onMove(host, { action: 'START_GAME' });
        g.onMove(host, { action: 'BID', cards: [1] });
        g.onMove(guest, { action: 'BID', cards: [2] });
        const token = g.globalStateSync(guest).token;
        const hand = structuredClone(g.engine.hands[1]);
        const table = structuredClone(g.engine.table[1]);
        const status = structuredClone(g.engine.status[1]);
        g.onDisconnect(guest);
        assert.deepEqual(g.engine.table[1], table);
        g.onMove(third, { action: 'REPLACE_WITH_CPU', seat: 1 });
        assert.equal(third.messages.at(-1).type, 'ERROR');
        g.onMove(host, { action: 'REPLACE_WITH_CPU', seat: 1 });
        assert.deepEqual(g.engine.hands[1], hand);
        assert.deepEqual(g.engine.table[1], table);
        assert.deepEqual(g.engine.status[1], status);
        assert.equal(g.globalStateSync(host).seats[1].ai, true);
        const observer = client(); g.onJoin(observer);
        g.onMove(observer, { action: 'RESUME', token });
        assert.equal(observer.messages.at(-1).type, 'ERROR');
        const turn = g.engine.turn;
        g.onDisconnect(host); g.onDisconnect(third);
        assert.equal(g.engine.turn, turn);
        assert.equal(g.timer, null);
        assert.equal(g.config.holdEmptySeats, true);
    } finally { g.onRemove(); }
});
test('Full game reveals hands and return to lobby clears ready, tokens and held seats', () => {
    const g = new Game(); const clients = [client(), client(), client()];
    try {
        for (const c of clients) assert.ok(g.onJoin(c));
        g.onMove(clients[0], { action: 'SET_OPTIONS', seats: 3 });
        g.onMove(clients[0], { action: 'START_GAME' });
        for (let i = 0; i < 1000 && g.engine.phase !== 'gameEnd'; i++) {
            const seat = g.engine.turn;
            g.onMove(clients[seat], decide(g.engine.view(seat, Infinity)));
        }
        assert.equal(g.engine.phase, 'gameEnd');
        assert.equal(g.globalStateSync(clients[0]).view.result.hands.length, 3);
        g.onDisconnect(clients[2]);
        g.onMove(clients[1], { action: 'RETURN_TO_LOBBY' });
        assert.equal(g.engine, null);
        assert.equal(g.playerCount, 2);
        assert.equal(g.config.holdEmptySeats, false);
        assert.ok(clients.slice(0,2).every(c => !c.ready));
        assert.equal(g.globalStateSync(clients[0]).token, undefined);
        assert.equal(g.held.size, 0);
    } finally { g.onRemove(); }
});
