import assert from 'node:assert/strict';
import { test } from 'node:test';
import { Engine } from '../build/client/ninety_nine/js/engine.js';
import { decide } from '../build/client/ninety_nine/js/ai.js';
import { VARIANTS, getVariant } from '../build/client/ninety_nine/js/variants/index.js';
import { validateVariant, resolveCard, RANKS, SUITS } from '../build/client/ninety_nine/js/variants/schema.js';
import { EFFECTS } from '../build/client/ninety_nine/js/effects/index.js';
import NinetyNineGame from '../build/server/games/ninety_nine.js';

export function seeded(seed) {
    return () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
}
function fixture(id = 'standard', seats = 3, hands = [['K'], ['K'], ['K']]) {
    const engine = new Engine({ variant: getVariant(id), seats, tokens: 3, rng: seeded(17) });
    engine.deck.push(...engine.hands.flat(), ...engine.discard);
    engine.hands = Array.from({ length: seats }, () => []); engine.discard = [];
    hands.forEach((ranks, seat) => ranks.forEach(spec => {
        const [rank, suit] = spec.split(':');
        const i = engine.deck.findIndex(card => card.rank === rank && (!suit || card.suit === suit));
        assert.ok(i >= 0, spec);
        engine.hands[seat].push(engine.deck.splice(i, 1)[0]);
    }));
    engine.turn = 0; engine.events = [];
    return engine;
}
function play(engine, index = 0, choice) {
    return engine.dispatch(engine.turn, { action: 'PLAY', iid: engine.hands[engine.turn][index].iid, choice });
}

test('Every shipped rank/suit matches the plan, including suited precedence', () => {
    const base = ['c1,11', 'a2', 'a3s', 'a0r', 'a5', 'a6', 'a7', 'a8', 's99', 'c-10,10', 'a10', 'a10', 'a0'];
    const expected = {
        standard: base,
        alternate: ['c1,11', 'a2', 'a3', 'a0r', 'a5', 'a6', 'a7', 'a8', 'a0', 'a-10', 'a10', 'a10', 's99'],
        chicago: ['c1,11', 'a2', 'a3s', 'a0r', 'a5', 'a6', 'a7', 'a8', 'a0s', 'a-10', 'a10', 'a10', 's99'],
        hawaiian: ['c1,11', 'a2', 'a3s', 'a0r', 'a-5', 'a6', 'a7', 'a8', 's99', 'a-10', 's99', 'a10', 'a0'],
        nepal: ['c1,11', 's99', 'a3', 'a0r', 'a5', 'a6', 'a7', 'a8', 'a0', 'c-10,10', 'a10', 'a10', 'a10'],
        taiwanese: ['a1', 'a2', 'a3', 'a0r', 'a0n', 'a6', 'a7', 'a8', 'a9', 'c-10,10', 'a0', 'c-20,20', 's99'],
        baltimore: ['a1', 'a2', 'a0r', 'a0r', 'a5', 'a6t', 'copy', 'a2', 'a0', 'a-10', 'a10', 'a10', 'a10']
    };
    assert.equal(VARIANTS.length, 7);
    for (const variant of VARIANTS) {
        validateVariant(variant, Object.keys(EFFECTS));
        for (const suit of SUITS) for (const [i, rank] of RANKS.slice(0, 13).entries()) {
            const def = resolveCard(variant, { rank, suit });
            const v = def.value;
            let actual = v.type === 'add' ? `a${v.n}` : v.type === 'set' ? `s${v.total}` :
                v.type === 'choice' ? `c${v.options.join(',')}` : 'copy';
            actual += (def.effects ?? []).map(e => ({ reverse: 'r', skip: 's', chooseNext: 'n', steal: 't' })[e.type]).join('');
            let want = expected[variant.id][i];
            if (variant.id === 'taiwanese' && rank === 'A' && suit === 'Spades') want = 's0';
            if (variant.id === 'baltimore' && rank === 'J' && ['Spades', 'Hearts'].includes(suit)) want = 's99';
            assert.equal(actual, want, `${variant.id} ${rank} ${suit}`);
        }
    }
});
test('Bad definitions fail fast', () => {
    const copy = () => structuredClone(VARIANTS[0]);
    const bad = copy(); bad.cards.push(bad.cards[0]); assert.throws(() => validateVariant(bad, Object.keys(EFFECTS)), /Duplicate/);
    for (const mutate of [v => { v.cards = []; }, v => { v.cards[0].value = { type: 'choice', options: [] }; },
        v => { v.cards[0].value = { type: 'set', total: 100 }; },
        v => { v.cards[0].effects = [{ type: 'unknown' }]; }, v => { v.rules.jokers = 1; },
        v => { v.cards[0].match.suits = ['Unknown']; }]) {
        const v = copy(); mutate(v); assert.throws(() => validateVariant(v, Object.keys(EFFECTS)));
    }
});
test('Values, floor, choices, set99, and wrong-seat/forged-card rejection', () => {
    let e = fixture('standard', 3, [['10'], ['K'], ['K']]); e.total = 5;
    assert.equal(play(e, 0, -10), null); assert.equal(e.total, 0); assert.equal(e.hands[0].length, 1);
    e = fixture('standard', 3, [['A'], ['K'], ['K']]); e.total = 95;
    assert.deepEqual(e.legalPlays(0).map(x => x.choice), [1]);
    assert.ok(play(e, 0, 11)); assert.equal(e.total, 95); assert.equal(play(e, 0, 1), null);
    e = fixture('standard', 3, [['9'], ['K'], ['K']]); e.total = 99;
    assert.ok(e.dispatch(1, { action: 'PLAY', iid: e.hands[0][0].iid }));
    assert.ok(e.dispatch(0, { action: 'PLAY', iid: 'forged' }));
    assert.equal(play(e), null); assert.equal(e.total, 99);
});
test('Reverse, skip, two-player extra turn, and eliminated seats', () => {
    let e = fixture('standard', 3, [['4'], ['K'], ['K']]);
    assert.equal(play(e), null); assert.equal(e.direction, -1); assert.equal(e.turn, 2);
    e = fixture('standard', 3, [['3'], ['K'], ['K']]);
    assert.equal(play(e), null); assert.equal(e.turn, 2); assert.deepEqual(e.skipped, [1]);
    for (const rank of ['4', '3']) {
        e = fixture('standard', 2, [[rank], ['K']]);
        assert.equal(play(e), null); assert.equal(e.turn, 0);
    }
    e = fixture(); e.tokens[1] = 0; e.eliminated[1] = true;
    assert.equal(play(e), null); assert.equal(e.turn, 2);
});
test('Bust, reveal, elimination, winner, dealer rotation/reset, stalemate', () => {
    let e = fixture('standard', 3, [['K'], ['2'], ['K']]); e.total = 99;
    assert.equal(play(e), null); assert.equal(e.phase, 'bust'); assert.equal(e.tokens[1], 2);
    assert.equal(e.events.at(-1).group, 'reveal'); assert.ok(e.view(-1).players[1].hand[0].rank);
    e.direction = -1; assert.equal(e.dispatch(0, { action: 'CONTINUE' }), null);
    assert.equal(e.dealer, 1); assert.equal(e.direction, 1); assert.equal(e.total, 0);
    e = fixture('standard', 2, [['K'], ['2']]); e.total = 99; e.tokens = [1, 1];
    assert.equal(play(e), null); assert.equal(e.phase, 'gameEnd'); assert.equal(e.winner, 0);
    assert.equal(e.eliminated[1], true);
    e = fixture(); e.playsThisHand = 299;
    assert.equal(play(e), null); assert.equal(e.phase, 'bust'); assert.deepEqual(e.tokens, [3, 3, 3]);
});
test('Hand sizes, multiple decks, deck recycling with top retained', () => {
    for (const v of VARIANTS) for (let seats = 2; seats <= 8; seats++) {
        const e = new Engine({ variant: v, seats, tokens: 3, rng: seeded(seats) });
        assert.ok(e.hands.every(h => h.length === v.rules.handSize));
        assert.equal(e.deck.length + e.hands.flat().length, seats > 6 ? 104 : 52);
    }
    const e = fixture();
    e.discard.push(...e.deck.splice(0));
    const retained = e.hands[0][0].iid;
    assert.equal(play(e), null); assert.equal(e.discard.at(-1).iid, retained);
    assert.ok(e.events.some(event => event.group === 'recycle'));
    assert.ok(e.events.some(event => event.group === 'shuffle'));
});
test('Taiwanese prompts, ace of spades reset, and replay rejection', () => {
    let e = fixture('taiwanese', 3, [['5'], ['J'], ['J']]);
    assert.equal(play(e), null); assert.equal(e.pending.kind, 'chooseNext');
    assert.ok(e.dispatch(1, { action: 'CHOOSE', promptId: e.pending.id, value: 2 }));
    const move = { action: 'CHOOSE', promptId: e.pending.id, value: 2 };
    assert.equal(e.dispatch(0, move), null); assert.equal(e.turn, 2); assert.ok(e.dispatch(0, move));
    e = fixture('taiwanese', 3, [['A:Spades'], ['J'], ['J']]); e.total = 99;
    assert.equal(play(e), null); assert.equal(e.total, 0);
});
test('Baltimore copy resolved choice/powers, first copy, steal masking, combine', () => {
    let e = fixture('baltimore', 3, [['7'], ['9'], ['9']]);
    assert.equal(play(e), null); assert.equal(e.total, 0);
    e = fixture('baltimore', 3, [['3'], ['9'], ['7']]);
    assert.equal(play(e), null); assert.equal(e.turn, 2);
    assert.equal(play(e), null); assert.equal(e.direction, 1); assert.equal(e.turn, 0);
    e = fixture('baltimore', 3, [['6'], ['9'], ['9']]);
    assert.equal(play(e), null); assert.equal(e.pending.kind, 'steal');
    assert.equal(e.dispatch(0, { action: 'CHOOSE', promptId: e.pending.id, value: 1 }), null);
    assert.equal(e.hands[0].length, 2); assert.equal(e.hands[1].length, 1);
    for (const seat of [-1, 2]) assert.equal(e.view(seat).events.find(event => event.group === 'steal').card.rank, undefined);
    assert.ok(e.view(0).events.find(event => event.group === 'steal').card.rank);
    assert.ok(e.view(1).events.find(event => event.group === 'steal').card.rank);
    e = fixture('baltimore', 3, [['Q', 'K'], ['9'], ['9']]);
    assert.equal(e.dispatch(0, { action: 'COMBINE', iids: e.hands[0].map(c => c.iid) }), null);
    assert.equal(e.total, 10); assert.equal(e.hands[0].length, 2);
    assert.equal(e.events.filter(ev => ev.group === 'combine').length, 2);
    e = fixture('standard', 3, [['10'], ['K'], ['K']]);
    assert.equal(play(e, 0, -10), null); assert.deepEqual(e.lastPlay.def.value, { type: 'add', n: -10 });
});
test('Every movement replays exactly, conserves cards, and masks unseen ranks', () => {
    for (const variant of VARIANTS) {
        const rng = seeded(912); const e = new Engine({ variant, seats: 5, tokens: 2, rng });
        const zones = { deck: e.deck.map(c => c.iid), discard: [], hands: e.hands.map(h => h.map(c => c.iid)) };
        let since = e.events.length;
        for (let turn = 0; turn < 800 && e.phase !== 'gameEnd'; turn++) {
            const actor = e.pending?.seat ?? e.turn;
            assert.equal(e.dispatch(actor, decide(e.view(actor, Infinity), rng)), null);
            for (const event of e.events.slice(since)) {
                if (event.group === 'reveal') continue;
                const zone = z => typeof z === 'string' ? zones[z] : zones.hands[z.hand];
                const source = zone(event.from); const i = source.indexOf(event.card.iid);
                assert.ok(i >= 0, `${variant.id} source ${event.card.iid}`);
                source.splice(i, 1); zone(event.to).push(event.card.iid);
            }
            since = e.events.length;
            assert.deepEqual(zones.deck, e.deck.map(c => c.iid));
            assert.deepEqual(zones.discard, e.discard.map(c => c.iid));
            assert.deepEqual(zones.hands, e.hands.map(h => h.map(c => c.iid)));
            assert.equal(new Set([...e.deck, ...e.discard, ...e.hands.flat()].map(c => c.iid)).size, 52);
            assert.ok(e.total >= 0 && e.total <= 99);
            for (const player of e.view(-1, Infinity).players) if (!player.revealed)
                assert.ok(player.hand.every(c => Object.keys(c).length === 1));
        }
    }
});
function client(name) {
    const messages = [];
    return { username: name, ready: false, gameID: '', messages,
        connection: { sendUTF: text => messages.push(JSON.parse(text)) } };
}
test('Server lobby, host options, AI fill, observers, held resume and lobby reset', () => {
    const game = new NinetyNineGame(); const a = client('A'); const b = client('B');
    assert.equal(game.onJoin(a), true); assert.equal(game.onJoin(b), true);
    assert.deepEqual(game.globalStateSync(a).seats.map(s => s.ai), [false, false, true, true]);
    game.onMove(b, { action: 'SET_OPTIONS', variantId: 'taiwanese', seats: 2, tokens: 1 });
    assert.equal(game.settings.variantId, 'standard');
    game.onMove(a, { action: 'SET_OPTIONS', variantId: 'taiwanese', seats: 2, tokens: 1 });
    assert.equal(game.settings.variantId, 'taiwanese'); assert.equal(game.onJoin(client('Full')), false);
    for (const change of [{ seats: 9 }, { tokens: 0 }, { variantId: 'unknown' }])
        game.onMove(a, { action: 'SET_OPTIONS', ...game.settings, ...change });
    assert.equal(game.settings.seats, 2); assert.equal(game.settings.tokens, 1);
    game.onMove(a, { action: 'START_GAME' }); assert.equal(game.engine, null);
    a.ready = b.ready = true; game.onMove(a, { action: 'START_GAME' }); assert.ok(game.engine);
    const token = game.globalStateSync(a).token;
    game.onMove(a, { action: 'SET_OPTIONS', variantId: 'standard', seats: 8, tokens: 10 });
    assert.equal(game.settings.variantId, 'taiwanese');
    game.onMove(a, { action: 'RETURN_TO_LOBBY' }); assert.ok(game.engine);
    const observer = client('Observer'); assert.equal(game.onJoin(observer), true);
    assert.equal(game.globalStateSync(observer).youAre, -1);
    assert.equal(game.globalStateSync(observer).view.events.length, 0);
    game.onDisconnect(a); assert.equal(game.players[0], null);
    game.onMove(observer, { action: 'RESUME', token: 'bad' }); assert.equal(game.players[0], null);
    game.onMove(observer, { action: 'RESUME', token }); assert.equal(game.players[0], observer);
    assert.equal(observer.username, 'A'); assert.equal(game.globalStateSync(observer).view.events.length, 0);
    game.engine.phase = 'gameEnd'; game.engine.winner = 0;
    game.onMove(observer, { action: 'RETURN_TO_LOBBY' }); assert.equal(game.engine, null);
    assert.equal(game.settings.variantId, 'taiwanese'); assert.equal(observer.ready, false);
    game.onRemove();
});
test('Lobby disconnect restores AI; host seat clamp; timer pause/resume and cleanup', () => {
    const game = new NinetyNineGame(); const a = client('A'); const b = client('B'); const c = client('C');
    game.onJoin(a); game.onJoin(b); game.onJoin(c);
    game.onMove(a, { action: 'SET_OPTIONS', variantId: 'standard', seats: 2, tokens: 3 });
    assert.equal(game.settings.seats, 3);
    game.onDisconnect(c); assert.equal(game.globalStateSync(a).seats[2].ai, true);
    game.onDisconnect(b); a.ready = true; game.onMove(a, { action: 'START_GAME' });
    assert.ok(game.timer); const token = game.globalStateSync(a).token;
    game.onDisconnect(a); assert.equal(game.timer, null);
    const resume = client('Resume'); game.onJoin(resume);
    assert.equal(game.timer, null); game.onMove(resume, { action: 'RESUME', token }); assert.ok(game.timer);
    game.onRemove(); assert.equal(game.timer, null);
});
