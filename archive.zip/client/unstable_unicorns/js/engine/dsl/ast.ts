import type { Iid } from '../ids.js';
import type { LingeringUntil, Zone } from '../state.js';

export type Kind = 'baby' | 'basic' | 'magic' | 'instant' | 'upgrade' | 'downgrade';

export type UnicornType = 'basic' | 'baby' | 'panda' | 'special';

export const KINDS: Array<Kind> = ['baby', 'basic', 'magic', 'instant', 'upgrade', 'downgrade'];
export const UNICORN_TYPES: Array<UnicornType> = ['basic', 'baby', 'panda', 'special'];

export type OwnerRef = 'self' | 'other' | 'any' | 'active';

export type EventType =
    | 'play'
    | 'enterStable'
    | 'leaveStable'
    | 'destroy'
    | 'discard'
    | 'sacrifice'
    | 'return'
    | 'draw'
    | 'neigh'
    | 'cancel'
    | 'turnStart'
    | 'turnEnd'
    | 'deckOut'
    | 'move';

export const EVENT_TYPES: Array<EventType> = [
    'play', 'enterStable', 'leaveStable', 'destroy', 'discard',
    'sacrifice', 'return', 'draw', 'neigh', 'cancel', 'turnStart', 'turnEnd', 'deckOut', 'move'
];

export type NodeId = string;

export type Cmp = 'lt' | 'lte' | 'eq' | 'gte' | 'gt';
export const CMPS: Array<Cmp> = ['lt', 'lte', 'eq', 'gte', 'gt'];

export type Filter =
    | { f: 'type'; type: Kind }
    | { f: 'tag'; tag: string }
    | { f: 'unicorn'; unicorn?: UnicornType }
    | { f: 'owner'; owner: OwnerRef }
    | { f: 'and'; all: Array<Filter> }
    | { f: 'or'; any: Array<Filter> }
    | { f: 'not'; not: Filter };

export const FILTER_KINDS: Array<Filter['f']> = ['type', 'tag', 'unicorn', 'owner', 'and', 'or', 'not'];

export type Cond =
    | { c: 'event'; type: EventType }
    | { c: 'count'; zone: Zone; owner: OwnerRef; filter?: Filter; cmp: Cmp; n: number }
    | { c: 'selfInStable' }
    | { c: 'and'; all: Array<Cond> }
    | { c: 'or'; any: Array<Cond> }
    | { c: 'not'; not: Cond };

export const COND_KINDS: Array<Cond['c']> = ['event', 'count', 'selfInStable', 'and', 'or', 'not'];

export type CountSpec = number | { min: number; max: number } | { var: string };

export interface Selector {
    zone: Zone | 'any';
    owner: OwnerRef;
    filter?: Filter;
    count: CountSpec;
    mode?: 'choose' | 'random';
    chooser?: 'controller' | 'zoneOwner';
    as?: string;
    reveal?: boolean;
}

export type Primitive =
    | { p: 'draw'; count: CountSpec; who?: 'self' | 'active' }
    | { p: 'discard'; sel: Selector }
    | { p: 'destroy'; sel: Selector }
    | { p: 'sacrifice'; sel: Selector }
    | { p: 'sacrificeSource' }
    | { p: 'returnToHand'; sel: Selector }
    | { p: 'returnToHandAndDiscard'; sel: Selector }
    | { p: 'moveCard'; sel: Selector; zone: Zone; owner: OwnerRef }
    | { p: 'moveStable'; sel: Selector; owner: OwnerRef }
    | { p: 'stealRandom'; sel: Selector }
    | { p: 'pullRandomFromPlayer' }
    | { p: 'stealFromPlayer' }
    | { p: 'discardFromPlayer' }
    | { p: 'returnFromPlayer' }
    | { p: 'stealUntil'; sel: Selector; until: LingeringUntil }
    | { p: 'lookAndSteal'; from: 'deck' | 'discard'; count: number }
    | { p: 'swapHands'; who: OwnerRef }
    | { p: 'tradeUnicorns'; mine: Selector; theirs: Selector }
    | { p: 'swapWithPlayer' }
    | { p: 'search'; from: 'deck' | 'discard'; filter?: Filter; count: CountSpec; as?: string }
    | { p: 'fetchFromDiscard'; filter?: Filter; count: CountSpec; as?: string }
    | { p: 'shuffleInto'; sel: Selector; zone: Zone; owner: OwnerRef }
    | { p: 'shuffleZonesIntoDeck'; zones: Array<Zone>; owner?: OwnerRef }
    | { p: 'replaceUnicornsWithBabies'; sel?: Selector }
    | { p: 'takeExtraTurn' }
    | { p: 'endTurnNow' }
    | { p: 'addLingering'; effect: Effect; until: LingeringUntil }
    | { p: 'returnSourceToNursery' }
    | { p: 'returnSourceToHand' }
    | { p: 'guardUnicorn' }
    | { p: 'custom'; name: string };

export const PRIMITIVE_KINDS: Array<Primitive['p']> = [
    'draw', 'discard', 'destroy', 'sacrifice', 'sacrificeSource', 'returnToHand', 'returnToHandAndDiscard', 'moveCard',
    'moveStable', 'stealRandom', 'pullRandomFromPlayer', 'stealFromPlayer', 'discardFromPlayer', 'returnFromPlayer', 'stealUntil', 'lookAndSteal', 'swapHands', 'tradeUnicorns', 'swapWithPlayer',
    'search', 'fetchFromDiscard', 'shuffleInto', 'shuffleZonesIntoDeck', 'replaceUnicornsWithBabies', 'takeExtraTurn',
    'endTurnNow', 'addLingering', 'returnSourceToNursery', 'returnSourceToHand', 'guardUnicorn', 'custom'
];

export type Effect = ({
    e: 'seq';
    steps: Array<Effect>;
} | {
    e: 'prim';
    prim: Primitive;
} | {
    e: 'optional';
    effect: Effect;
} | {
    e: 'ifYouDo';
    effect: Effect;
} | {
    e: 'choice';
    options: Array<Effect>;
} | {
    e: 'forEachPlayer';
    effect: Effect;
    who?: OwnerRef;
} | {
    e: 'repeat';
    count: CountSpec;
    effect: Effect;
} | {
    e: 'when';
    cond: Cond;
    effect: Effect;
}) & { id?: NodeId };

export const EFFECT_KINDS: Array<Effect['e']> = [
    'seq', 'prim', 'optional', 'ifYouDo', 'choice', 'forEachPlayer', 'repeat', 'when'
];

export type Modifier =
    | { m: 'actionsPerTurn'; value: number }
    | { m: 'drawsPerTurn'; value: number }
    | { m: 'handLimit'; value: number }
    | { m: 'stableLimit'; value: number }
    | { m: 'unicornCount'; value: number; filter?: Filter }
    | { m: 'unicornType'; type: UnicornType; filter?: Filter }
    | { m: 'protect'; against: 'destroy' | 'sacrifice' | 'neigh' | 'play'; filter?: Filter }
    | { m: 'blockPlay'; kind: Kind }
    | { m: 'blockOtherPlay'; kind: Kind; filter?: Filter }
    | { m: 'blockTriggers' }
    | { m: 'handVisible' };

export const MODIFIER_KINDS: Array<Modifier['m']> = [
    'actionsPerTurn', 'drawsPerTurn', 'handLimit', 'stableLimit', 'unicornCount',
    'unicornType', 'protect', 'blockPlay', 'blockOtherPlay', 'blockTriggers', 'handVisible'
];

export type Replacement = {
    r: 'replace';
    when: EventType;
    scope?: 'source' | 'owner';
    filter?: Filter;
    effect: Effect;
    unless?: Cond;
};

export interface Trigger {
    on: EventType;
    scope?: 'source' | 'owner';
    unicorn?: boolean;
    when?: Cond;
    effect: Effect;
}

export interface CardDef {
    id: string;
    kind: Kind;
    unicornType?: UnicornType;
    tags?: Array<string>;
    playIf?: Cond;
    playTarget?: 'self' | 'any' | 'other';
    onPlay?: Effect;
    triggers?: Array<Trigger>;
    modifiers?: Array<Modifier>;
    replacements?: Array<Replacement>;
    instant?: { neigh: true; superNeigh?: boolean };
    unneighable?: boolean;
}

export interface CatalogEntry {
    id: string;
    name: string;
    kind: Kind;
    unicornType?: UnicornType;
    text: string;
    copies: number;
    image?: string;
}

export interface Place {
    zone: Zone;
    owner?: number;
}

export interface CardEvent {
    type: EventType;
    card?: Iid;
    player?: number;
    from?: Place;
    to?: Place;
    targetCard?: Iid;
    targetPlayer?: number;
    publicDefId?: string;
    cause?: string;
    unicorn?: boolean;
    suppressed?: boolean;
    superNeigh?: boolean;
}
